#!/usr/bin/env node
/**
 * verify-rebrand.mjs
 *
 * Asserts that the Ripple rebrand tokens are intact in the Referral Hub web
 * app source files.  Run with: node scripts/verify-rebrand.mjs
 *
 * Checks:
 *  1. Clerk appearance — colorPrimary is sky-blue #0EA5E9
 *  2. Auth shell and hero use the correct three-stop blue gradient
 *  3. Sidebar uses the same three-stop gradient
 *  4. Ripple wordmark uses Nunito font in both home and layout
 *  5. Logo SVG (ripple-wave concentric circles) is present in layout and home
 */

import { readFileSync } from "fs";
import { fileURLToPath } from "url";
import { join, dirname } from "path";

const __dirname = dirname(fileURLToPath(import.meta.url));
const root = join(__dirname, "..");

function read(relPath) {
  return readFileSync(join(root, relPath), "utf8");
}

let failures = 0;

function assert(label, condition) {
  if (condition) {
    console.log(`  ✓  ${label}`);
  } else {
    console.error(`  ✗  FAIL: ${label}`);
    failures++;
  }
}

console.log("\nRipple rebrand verification — Referral Hub web app\n");

/* ── App.tsx — Clerk appearance config ─────────────────────────────────── */
console.log("App.tsx (Clerk appearance):");
const app = read("artifacts/referral-hub/src/App.tsx");

assert(
  'colorPrimary is sky-blue #0EA5E9',
  app.includes('colorPrimary: "#0EA5E9"'),
);
assert(
  'auth-shell uses 3-stop sky-blue gradient (0369A1 → 0284C7 → 0EA5E9)',
  app.includes("#0369A1") && app.includes("#0284C7") && app.includes("#0EA5E9"),
);
assert(
  'Clerk cardBox has rounded-2xl + shadow-lg (branded card style)',
  app.includes("rounded-2xl") && app.includes("shadow-lg"),
);
assert(
  'fontFamily set to Inter in Clerk appearance',
  app.includes("'Inter', sans-serif"),
);

/* ── layout.tsx — sidebar branding ─────────────────────────────────────── */
console.log("\nlayout.tsx (sidebar):");
const layout = read("artifacts/referral-hub/src/components/layout.tsx");

assert(
  'sidebar uses 3-stop sky-blue gradient (0369A1 → 0284C7 → 0EA5E9)',
  layout.includes("#0369A1") && layout.includes("#0284C7") && layout.includes("#0EA5E9"),
);
assert(
  '"Ripple" wordmark uses Nunito font',
  layout.includes("Nunito"),
);
assert(
  'RippleLogo SVG (concentric circles) is defined in layout',
  layout.includes("RippleLogo") && layout.includes("cx=\"14\" cy=\"14\" r=\"4\""),
);
assert(
  'Active nav item uses sky-blue text-[#0284C7]',
  layout.includes("text-[#0284C7]"),
);

/* ── home.tsx — landing page ────────────────────────────────────────────── */
console.log("\nhome.tsx (landing page):");
const home = read("artifacts/referral-hub/src/pages/home.tsx");

assert(
  'hero section uses 3-stop sky-blue gradient',
  home.includes("#0369A1") && home.includes("#0284C7") && home.includes("#0EA5E9"),
);
assert(
  '"Ripple" wordmark uses Nunito font',
  home.includes("Nunito"),
);
assert(
  'RippleMark SVG (ripple-wave) defined for logo in nav',
  home.includes("RippleMark") && home.includes("cx=\"14\" cy=\"14\" r=\"4\""),
);

/* ── Summary ─────────────────────────────────────────────────────────────── */
console.log();
if (failures === 0) {
  console.log("All rebrand checks passed.\n");
  process.exit(0);
} else {
  console.error(`${failures} check(s) failed — rebrand tokens are missing or incorrect.\n`);
  process.exit(1);
}

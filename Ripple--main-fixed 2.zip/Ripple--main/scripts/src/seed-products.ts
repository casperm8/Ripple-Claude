import { getUncachableStripeClient } from "./stripeClient";

async function seedProducts() {
  const stripe = await getUncachableStripeClient();

  const existing = await stripe.products.search({
    query: "name:'Ripple Pro' AND active:'true'",
  });

  if (existing.data.length > 0) {
    console.log("Ripple Pro product already exists — skipping creation.");
    console.log(`Product ID: ${existing.data[0].id}`);
    const prices = await stripe.prices.list({ product: existing.data[0].id, active: true });
    for (const p of prices.data) {
      console.log(`  Price: ${p.id}  ${p.unit_amount}${p.currency} / ${p.recurring?.interval}`);
    }
    return;
  }

  const product = await stripe.products.create({
    name: "Ripple Pro",
    description:
      "Unlimited referral code posts, unlimited daily claims, and priority support.",
  });
  console.log(`Created product: ${product.name} (${product.id})`);

  const monthly = await stripe.prices.create({
    product: product.id,
    unit_amount: 999,
    currency: "usd",
    recurring: { interval: "month" },
  });
  console.log(`Created monthly price: $9.99/mo (${monthly.id})`);

  const yearly = await stripe.prices.create({
    product: product.id,
    unit_amount: 7999,
    currency: "usd",
    recurring: { interval: "year" },
  });
  console.log(`Created yearly price: $79.99/yr (${yearly.id})`);

  console.log("\n✓ Done. Webhooks will sync these to the database automatically.");
  console.log("  Update the UI price IDs or fetch them via GET /api/subscription/plans.");
}

seedProducts().catch((err) => {
  console.error("Seed failed:", err.message);
  process.exit(1);
});

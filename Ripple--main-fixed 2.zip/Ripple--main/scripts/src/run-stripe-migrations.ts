import { runMigrations } from "stripe-replit-sync";

const databaseUrl = process.env.DATABASE_URL;
if (!databaseUrl) throw new Error("DATABASE_URL required");

await runMigrations({ databaseUrl });
console.log("Stripe migrations complete");

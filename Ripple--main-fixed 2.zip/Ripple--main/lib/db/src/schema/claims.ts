import { pgTable, text, integer, timestamp, uniqueIndex } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const claimsTable = pgTable("claims", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  codeId: integer("code_id").notNull(),
  userId: text("user_id").notNull(),
  claimedAt: timestamp("claimed_at").defaultNow().notNull(),
}, (t) => [
  uniqueIndex("claims_code_user_uidx").on(t.codeId, t.userId),
]);

export const insertClaimSchema = createInsertSchema(claimsTable).omit({ claimedAt: true });
export type InsertClaim = z.infer<typeof insertClaimSchema>;
export type Claim = typeof claimsTable.$inferSelect;

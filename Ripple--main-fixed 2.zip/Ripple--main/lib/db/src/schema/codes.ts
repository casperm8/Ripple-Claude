import { pgTable, text, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const codesTable = pgTable("codes", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  userId: text("user_id").notNull(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  code: text("code").notNull(),
  category: text("category").notNull(),
  maxClaims: integer("max_claims").notNull(),
  claimCount: integer("claim_count").notNull().default(0),
  expiresAt: timestamp("expires_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertCodeSchema = createInsertSchema(codesTable).omit({ claimCount: true, createdAt: true });
export type InsertCode = z.infer<typeof insertCodeSchema>;
export type Code = typeof codesTable.$inferSelect;

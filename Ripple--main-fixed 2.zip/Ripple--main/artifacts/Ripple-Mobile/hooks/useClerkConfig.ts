/**
 * Shared Clerk configuration for sign-in and sign-up screens.
 *
 * Centralises every assumption made about the Clerk instance so that a single
 * config change (e.g. swapping the verification strategy or adding a required
 * field) automatically propagates to both the sign-in and sign-up flows.
 */

/** Verification strategy used during sign-up.  Change here to update both flows. */
export const CLERK_VERIFICATION_STRATEGY = "email_code" as const;

/** OAuth providers surfaced in the auth sheet, in display order. */
export const CLERK_OAUTH_PROVIDERS = [
  { strategy: "oauth_google" as const, label: "Google" },
  { strategy: "oauth_apple" as const, label: "Apple" },
] as const;

/** Fields that every email/password sign-up requires. */
export const CLERK_SIGNUP_FIELDS = ["emailAddress", "password"] as const;

/**
 * Extract a human-readable message from a Clerk error or a generic thrown value.
 * Centralised here so both sign-in and sign-up show identical error formatting.
 */
export function extractClerkError(error: unknown, fallback: string): string {
  if (!error) return fallback;
  const e = error as Record<string, any>;
  // Clerk first-class errors surface longMessage > message
  return e.longMessage ?? e.message ?? fallback;
}

/**
 * Extract a human-readable message from a caught exception that may carry a
 * Clerk `errors` array (thrown by most Clerk SDK calls).
 */
export function extractClerkException(error: unknown, fallback: string): string {
  if (!error) return fallback;
  const e = error as Record<string, any>;
  return (
    e.errors?.[0]?.longMessage ??
    e.errors?.[0]?.message ??
    fallback
  );
}

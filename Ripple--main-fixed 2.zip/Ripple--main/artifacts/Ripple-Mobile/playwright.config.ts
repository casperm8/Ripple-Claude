import { defineConfig, devices } from "@playwright/test";

const expoDomain = process.env.REPLIT_EXPO_DEV_DOMAIN ?? "localhost";

export default defineConfig({
  testDir: "./e2e",
  timeout: 45_000,
  retries: 0,
  reporter: "line",
  use: {
    baseURL: `https://${expoDomain}`,
    headless: true,
    screenshot: "only-on-failure",
    launchOptions: {
      executablePath:
        process.env.CHROMIUM_PATH ??
        "/nix/store/qa9cnw4v5xkxyip6mb9kxqfq1z4x2dx1-chromium-138.0.7204.100/bin/chromium-browser",
    },
  },
  projects: [
    {
      name: "chromium",
      use: { ...devices["Desktop Chrome"] },
    },
  ],
});

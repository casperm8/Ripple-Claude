import { useSSO, useSignIn, useSignUp } from "@clerk/expo";
import { Feather, Ionicons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import * as AuthSession from "expo-auth-session";
import { LinearGradient } from "expo-linear-gradient";
import { router } from "expo-router";
import * as WebBrowser from "expo-web-browser";
import React, { useState } from "react";
import {
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useColors } from "@/hooks/useColors";
import {
  CLERK_VERIFICATION_STRATEGY,
  CLERK_OAUTH_PROVIDERS,
  extractClerkError,
  extractClerkException,
} from "@/hooks/useClerkConfig";
import Svg, { Circle } from "react-native-svg";

WebBrowser.maybeCompleteAuthSession();

type Mode = "signin" | "signup" | "verify";

function RippleIconMark({ size = 36, color = "#FFFFFF" }: { size?: number; color?: string }) {
  return (
    <Svg width={size} height={size} viewBox="0 0 40 40" fill="none">
      <Circle cx="20" cy="20" r="5" fill={color} />
      <Circle cx="20" cy="20" r="10" stroke={color} strokeWidth="2.5" opacity="0.7" />
      <Circle cx="20" cy="20" r="16" stroke={color} strokeWidth="2" opacity="0.4" />
      <Circle cx="20" cy="20" r="19" stroke={color} strokeWidth="1.2" opacity="0.2" />
    </Svg>
  );
}

function GoogleIcon() {
  return (
    <View style={gStyles.circle}>
      <Text style={gStyles.letter}>G</Text>
    </View>
  );
}

const gStyles = StyleSheet.create({
  circle: {
    width: 22,
    height: 22,
    borderRadius: 11,
    backgroundColor: "#4285F4",
    alignItems: "center",
    justifyContent: "center",
  },
  letter: {
    fontSize: 13,
    fontFamily: "Inter_700Bold",
    color: "#FFFFFF",
    lineHeight: 16,
  },
});


export default function SignInScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { signIn, fetchStatus: siFetchStatus } = useSignIn();
  const { signUp, fetchStatus: suFetchStatus } = useSignUp();
  const { startSSOFlow } = useSSO();

  const [mode, setMode] = useState<Mode>("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [otp, setOtp] = useState("");
  const [showPw, setShowPw] = useState(false);
  const [loading, setLoading] = useState(false);
  const [googleLoading, setGoogleLoading] = useState(false);
  const [appleLoading, setAppleLoading] = useState(false);
  const [error, setError] = useState("");

  const topPad = Platform.OS === "web" ? 67 : insets.top;
  const botPad = Platform.OS === "web" ? 34 : insets.bottom;
  const anyLoading = loading || googleLoading || appleLoading;

  const handleOAuth = async (
    strategy: (typeof CLERK_OAUTH_PROVIDERS)[number]["strategy"],
    setOAuthLoading: (v: boolean) => void,
    label: string,
  ) => {
    setOAuthLoading(true);
    setError("");
    try {
      const { createdSessionId, setActive } = await startSSOFlow({
        strategy,
        redirectUrl: AuthSession.makeRedirectUri(),
      });
      if (createdSessionId && setActive) {
        await setActive({ session: createdSessionId });
        if (Platform.OS !== "web") Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        router.replace("/(tabs)");
      }
    } catch (e: any) {
      setError(extractClerkException(e, `${label} sign-in failed.`));
    } finally {
      setOAuthLoading(false);
    }
  };

  const onSignIn = async () => {
    if (siFetchStatus === "fetching") return;
    setLoading(true);
    setError("");
    try {
      const { error: createError } = await signIn.create({ identifier: email });
      if (createError) {
        setError(extractClerkError(createError, "Sign in failed."));
        return;
      }
      const { error: pwError } = await signIn.password({ password });
      if (pwError) {
        setError(extractClerkError(pwError, "Sign in failed."));
        return;
      }
      if (signIn.status === "complete") {
        const { error: finalizeError } = await signIn.finalize();
        if (finalizeError) {
          setError(extractClerkError(finalizeError, "Sign in failed."));
          return;
        }
        if (Platform.OS !== "web") Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        router.replace("/(tabs)");
      }
    } catch (e: any) {
      setError(extractClerkException(e, "Sign in failed."));
    } finally {
      setLoading(false);
    }
  };

  const onSignUp = async () => {
    if (suFetchStatus === "fetching") return;
    setLoading(true);
    setError("");
    try {
      const { error: createError } = await signUp.password({ emailAddress: email, password });
      if (createError) {
        setError(extractClerkError(createError, "Sign up failed."));
        return;
      }
      // Verification strategy is driven by CLERK_VERIFICATION_STRATEGY.
      // Changing that constant here is the single place to update both flows.
      const { error: sendError } =
        CLERK_VERIFICATION_STRATEGY === "email_code"
          ? await signUp.verifications.sendEmailCode()
          : { error: new Error(`Unsupported verification strategy: ${CLERK_VERIFICATION_STRATEGY}`) };
      if (sendError) {
        setError(extractClerkError(sendError, "Sign up failed."));
        return;
      }
      setMode("verify");
    } catch (e: any) {
      setError(extractClerkException(e, "Sign up failed."));
    } finally {
      setLoading(false);
    }
  };

  const onVerify = async () => {
    if (suFetchStatus === "fetching") return;
    setLoading(true);
    setError("");
    try {
      // Verify using the same strategy that was used to send the code.
      const { error: verifyError } =
        CLERK_VERIFICATION_STRATEGY === "email_code"
          ? await signUp.verifications.verifyEmailCode({ code: otp })
          : { error: new Error(`Unsupported verification strategy: ${CLERK_VERIFICATION_STRATEGY}`) };
      if (verifyError) {
        setError(extractClerkError(verifyError, "Verification failed."));
        return;
      }
      if (signUp.status === "complete") {
        const { error: finalizeError } = await signUp.finalize();
        if (finalizeError) {
          setError(extractClerkError(finalizeError, "Verification failed."));
          return;
        }
        if (Platform.OS !== "web") Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        router.replace("/(tabs)");
      }
    } catch (e: any) {
      setError(extractClerkException(e, "Verification failed."));
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={[styles.container, { backgroundColor: colors.background }]}
      behavior={Platform.OS === "ios" ? "padding" : "height"}
    >
      <Pressable onPress={() => router.back()} style={[styles.closeBtn, { top: topPad + 12 }]}>
        <Feather name="x" size={20} color="#FFFFFF" />
      </Pressable>

      <ScrollView
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
        contentContainerStyle={{ flexGrow: 1 }}
      >
        {/* Brand header */}
        <LinearGradient
          colors={["#0369A1", "#0284C7", "#0EA5E9"]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={[styles.brand, { paddingTop: topPad + 48 }]}
        >
          <View style={styles.brandIcon}>
            <RippleIconMark size={36} color="#FFFFFF" />
          </View>
          <Text style={styles.brandName} maxFontSizeMultiplier={1.4}>Ripple</Text>
          <Text style={styles.brandSub}>
            {mode === "verify" ? "Check your email" : "Every referral creates a ripple"}
          </Text>
        </LinearGradient>

        {/* Form sheet */}
        <View style={[styles.sheet, { backgroundColor: colors.background, paddingBottom: botPad + 24 }]}>

          {/* Sign In / Create Account toggle */}
          {mode !== "verify" && (
            <View style={[styles.toggle, { backgroundColor: colors.muted }]}>
              <Pressable
                onPress={() => { setMode("signin"); setError(""); }}
                style={[styles.toggleBtn, mode === "signin" && [styles.toggleActive, { backgroundColor: colors.card }]]}
              >
                <Text style={[styles.toggleText, {
                  color: mode === "signin" ? colors.foreground : colors.mutedForeground,
                  fontFamily: mode === "signin" ? "Inter_600SemiBold" : "Inter_400Regular",
                }]}>
                  Sign In
                </Text>
              </Pressable>
              <Pressable
                onPress={() => { setMode("signup"); setError(""); }}
                style={[styles.toggleBtn, mode === "signup" && [styles.toggleActive, { backgroundColor: colors.card }]]}
              >
                <Text style={[styles.toggleText, {
                  color: mode === "signup" ? colors.foreground : colors.mutedForeground,
                  fontFamily: mode === "signup" ? "Inter_600SemiBold" : "Inter_400Regular",
                }]}>
                  Create Account
                </Text>
              </Pressable>
            </View>
          )}

          {/* OAuth buttons */}
          {mode !== "verify" && (
            <View style={styles.oauthRow}>
              {/* Google — strategy driven by CLERK_OAUTH_PROVIDERS[0] */}
              <Pressable
                style={({ pressed }) => [
                  styles.oauthBtn,
                  { borderColor: colors.border, backgroundColor: colors.card, opacity: pressed || googleLoading ? 0.7 : 1 },
                ]}
                onPress={() => handleOAuth(CLERK_OAUTH_PROVIDERS[0].strategy, setGoogleLoading, CLERK_OAUTH_PROVIDERS[0].label)}
                disabled={anyLoading}
              >
                {googleLoading ? (
                  <ActivityIndicator size="small" color="#4285F4" />
                ) : (
                  <>
                    <GoogleIcon />
                    <Text style={[styles.oauthText, { color: colors.foreground }]}>{CLERK_OAUTH_PROVIDERS[0].label}</Text>
                  </>
                )}
              </Pressable>

              {/* Apple — strategy driven by CLERK_OAUTH_PROVIDERS[1] */}
              <Pressable
                style={({ pressed }) => [
                  styles.oauthBtn,
                  styles.appleBtn,
                  { opacity: pressed || appleLoading ? 0.85 : 1 },
                ]}
                onPress={() => handleOAuth(CLERK_OAUTH_PROVIDERS[1].strategy, setAppleLoading, CLERK_OAUTH_PROVIDERS[1].label)}
                disabled={anyLoading}
              >
                {appleLoading ? (
                  <ActivityIndicator size="small" color="#FFFFFF" />
                ) : (
                  <>
                    <Ionicons name="logo-apple" size={18} color="#FFFFFF" />
                    <Text style={styles.appleText}>{CLERK_OAUTH_PROVIDERS[1].label}</Text>
                  </>
                )}
              </Pressable>
            </View>
          )}

          {/* OR divider */}
          {mode !== "verify" && (
            <View style={styles.dividerRow}>
              <View style={[styles.dividerLine, { backgroundColor: colors.border }]} />
              <Text style={[styles.dividerText, { color: colors.mutedForeground }]}>or continue with email</Text>
              <View style={[styles.dividerLine, { backgroundColor: colors.border }]} />
            </View>
          )}

          {/* Email / password / OTP fields */}
          {mode === "verify" ? (
            <View style={[styles.inputGroup, { backgroundColor: colors.card, borderColor: colors.border }]}>
              <Text style={[styles.inputLabel, { color: colors.mutedForeground }]}>Verification Code</Text>
              <TextInput
                style={[styles.input, { color: colors.foreground }]}
                value={otp}
                onChangeText={setOtp}
                placeholder="6-digit code from email"
                placeholderTextColor={colors.border}
                keyboardType="number-pad"
                autoFocus
              />
            </View>
          ) : (
            <View style={[styles.inputGroup, { backgroundColor: colors.card, borderColor: colors.border }]}>
              <View style={styles.inputRow}>
                <Text style={[styles.inputLabel, { color: colors.mutedForeground }]}>Email</Text>
                <TextInput
                  style={[styles.input, { color: colors.foreground }]}
                  value={email}
                  onChangeText={setEmail}
                  placeholder="you@example.com"
                  placeholderTextColor={colors.border}
                  keyboardType="email-address"
                  autoCapitalize="none"
                  autoCorrect={false}
                />
              </View>
              <View style={[styles.inputDivider, { backgroundColor: colors.muted }]} />
              <View style={styles.inputRow}>
                <Text style={[styles.inputLabel, { color: colors.mutedForeground }]}>Password</Text>
                <View style={styles.pwRow}>
                  <TextInput
                    style={[styles.input, styles.pwInput, { color: colors.foreground }]}
                    value={password}
                    onChangeText={setPassword}
                    placeholder="••••••••"
                    placeholderTextColor={colors.border}
                    secureTextEntry={!showPw}
                    autoCapitalize="none"
                  />
                  <Pressable onPress={() => setShowPw((p) => !p)} style={styles.eyeBtn}>
                    <Feather name={showPw ? "eye-off" : "eye"} size={17} color={colors.mutedForeground} />
                  </Pressable>
                </View>
              </View>
            </View>
          )}

          {error !== "" && (
            <View style={[styles.errorBox, { backgroundColor: colors.destructive + "12" }]}>
              <Feather name="alert-circle" size={14} color={colors.destructive} />
              <Text style={[styles.errorText, { color: colors.destructive }]}>{error}</Text>
            </View>
          )}

          <Pressable
            style={({ pressed }) => [
              styles.submitBtn,
              { backgroundColor: colors.primary, opacity: pressed || loading ? 0.85 : 1 },
            ]}
            onPress={mode === "verify" ? onVerify : mode === "signin" ? onSignIn : onSignUp}
            disabled={anyLoading}
          >
            {loading
              ? <ActivityIndicator color="#FFFFFF" />
              : <Text style={styles.submitText}>
                  {mode === "verify" ? "Verify Email" : mode === "signin" ? "Sign In with Email" : "Create Account"}
                </Text>}
          </Pressable>

          {mode === "verify" && (
            <Pressable onPress={() => { setMode("signup"); setError(""); }}>
              <Text style={[styles.link, { color: colors.primary }]}>Back to sign up</Text>
            </Pressable>
          )}
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  closeBtn: { position: "absolute", right: 16, zIndex: 20, padding: 8, borderRadius: 20 },
  brand: { paddingHorizontal: 24, paddingBottom: 40, alignItems: "center", gap: 8 },
  brandIcon: {
    width: 68, height: 68, borderRadius: 20,
    backgroundColor: "rgba(255,255,255,0.2)",
    alignItems: "center", justifyContent: "center", marginBottom: 4,
  },
  brandName: { fontSize: 24, fontFamily: "Nunito_800ExtraBold", color: "#FFFFFF", letterSpacing: -0.4 },
  brandSub: { fontSize: 14, fontFamily: "Inter_400Regular", color: "rgba(255,255,255,0.65)" },
  sheet: { borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 20, gap: 14, flex: 1, marginTop: -20 },
  toggle: { flexDirection: "row", borderRadius: 12, padding: 4 },
  toggleBtn: { flex: 1, paddingVertical: 10, alignItems: "center", borderRadius: 9 },
  toggleActive: { shadowColor: "#000", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.08, shadowRadius: 3, elevation: 1 },
  toggleText: { fontSize: 14 },
  oauthRow: { flexDirection: "row", gap: 10 },
  oauthBtn: {
    flex: 1, height: 50, borderRadius: 14, borderWidth: 1.5,
    flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8,
  },
  appleBtn: { backgroundColor: "#000000", borderColor: "#000000" },
  oauthText: { fontSize: 15, fontFamily: "Inter_600SemiBold" },
  appleText: { fontSize: 15, fontFamily: "Inter_600SemiBold", color: "#FFFFFF" },
  dividerRow: { flexDirection: "row", alignItems: "center", gap: 8 },
  dividerLine: { flex: 1, height: 1 },
  dividerText: { fontSize: 12, fontFamily: "Inter_400Regular" },
  inputGroup: { borderRadius: 14, borderWidth: 1, overflow: "hidden", padding: 4 },
  inputRow: { padding: 12, gap: 4 },
  inputLabel: { fontSize: 11, fontFamily: "Inter_500Medium", letterSpacing: 0.4, textTransform: "uppercase" },
  input: { fontSize: 16, fontFamily: "Inter_400Regular", paddingTop: 4 },
  inputDivider: { height: 1 },
  pwRow: { flexDirection: "row", alignItems: "center" },
  pwInput: { flex: 1 },
  eyeBtn: { padding: 6 },
  errorBox: { borderRadius: 10, padding: 12, flexDirection: "row", gap: 8, alignItems: "flex-start" },
  errorText: { fontSize: 13, fontFamily: "Inter_400Regular", flex: 1, lineHeight: 18 },
  submitBtn: { height: 52, borderRadius: 14, alignItems: "center", justifyContent: "center" },
  submitText: { fontSize: 16, fontFamily: "Inter_600SemiBold", color: "#FFFFFF" },
  link: { textAlign: "center", fontSize: 14, fontFamily: "Inter_500Medium", paddingVertical: 4 },
});

import { useAuth } from "@clerk/expo";
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { LinearGradient } from "expo-linear-gradient";
import { router } from "expo-router";
import React, { useState } from "react";
import {
  Alert,
  FlatList,
  Platform,
  Pressable,
  RefreshControl,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import Svg, { Circle } from "react-native-svg";

import { CodeCard, CATEGORY_COLORS, CodeItem } from "@/components/CodeCard";
import { EmptyState } from "@/components/EmptyState";
import { useColors } from "@/hooks/useColors";
import { useClaimCode, useListCodes } from "@workspace/api-client-react";

function RippleIconMark({ size = 20, color = "#FFFFFF" }: { size?: number; color?: string }) {
  return (
    <Svg width={size} height={size} viewBox="0 0 40 40" fill="none">
      <Circle cx="20" cy="20" r="5" fill={color} />
      <Circle cx="20" cy="20" r="10" stroke={color} strokeWidth="2.5" opacity="0.7" />
      <Circle cx="20" cy="20" r="16" stroke={color} strokeWidth="2" opacity="0.4" />
      <Circle cx="20" cy="20" r="19" stroke={color} strokeWidth="1.2" opacity="0.2" />
    </Svg>
  );
}

const CATS = ["All", "Shopping", "Travel", "Tech", "Food", "Entertainment", "Finance", "Beauty", "Health", "Other"];

export default function BrowseScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { isSignedIn } = useAuth();

  const [search, setSearch] = useState("");
  const [cat, setCat] = useState("All");
  const [claimingId, setClaimingId] = useState<number | null>(null);

  const topPad = Platform.OS === "web" ? 67 : insets.top;

  const { data, isLoading, refetch, isRefetching } = useListCodes({
    limit: 50,
    category: cat === "All" ? undefined : cat.toLowerCase(),
    search: search || undefined,
  });

  const claimMutation = useClaimCode();

  const handleClaim = async (id: number) => {
    if (!isSignedIn) { router.push("/sign-in"); return; }
    setClaimingId(id);
    try {
      const result = await claimMutation.mutateAsync({ id });
      await refetch();
      if (Platform.OS !== "web") Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      Alert.alert("Code Unlocked!", `Your code for "${result.title}":\n\n${result.code}`, [{ text: "Got it" }]);
    } catch (err: any) {
      Alert.alert("Couldn't claim", err?.response?.data?.error ?? err?.message ?? "Please try again.");
    } finally {
      setClaimingId(null);
    }
  };

  const codes = (data?.codes ?? []) as CodeItem[];

  const Header = (
    <View>
      <LinearGradient
        colors={["#0369A1", "#0284C7", "#0EA5E9"]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={[styles.hero, { paddingTop: topPad + 12 }]}
      >
        <View style={styles.heroTop}>
          <View style={styles.logoRow}>
            <View style={styles.logoIcon}>
              <RippleIconMark size={18} color="#FFFFFF" />
            </View>
            <Text style={styles.logoText} maxFontSizeMultiplier={1.0}>Ripple</Text>
          </View>
          <Text style={styles.heroTitle} maxFontSizeMultiplier={1.4}>Browse Codes</Text>
          <Text style={styles.heroSub} maxFontSizeMultiplier={1.3}>
            {data?.total != null ? `${data.total} referral codes available` : "Find deals, save money"}
          </Text>
        </View>

        <View style={styles.searchWrap}>
          <Feather name="search" size={15} color="#6B7280" style={styles.searchIcon} />
          <TextInput
            style={styles.searchInput}
            value={search}
            onChangeText={setSearch}
            placeholder="Search codes, brands, deals…"
            placeholderTextColor="#9CA3AF"
            returnKeyType="search"
            autoCorrect={false}
            maxFontSizeMultiplier={1.2}
          />
          {search.length > 0 && (
            <Pressable onPress={() => setSearch("")} style={styles.clearBtn}>
              <Feather name="x" size={14} color="#6B7280" />
            </Pressable>
          )}
        </View>
      </LinearGradient>

      {/* Category pills */}
      <View style={[styles.catWrap, { backgroundColor: colors.background, borderBottomColor: colors.border }]}>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.catScroll}>
          {CATS.map((c) => {
            const active = cat === c;
            const catColor = c === "All" ? colors.primary : (CATEGORY_COLORS[c.toLowerCase()] ?? colors.primary);
            return (
              <Pressable
                key={c}
                onPress={() => setCat(c)}
                style={[
                  styles.catPill,
                  { backgroundColor: active ? catColor : colors.muted },
                ]}
              >
                <Text style={[styles.catPillText, { color: active ? "#fff" : colors.mutedForeground, fontFamily: active ? "Inter_600SemiBold" : "Inter_400Regular" }]} maxFontSizeMultiplier={1.0}>
                  {c}
                </Text>
              </Pressable>
            );
          })}
        </ScrollView>
      </View>
    </View>
  );

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <FlatList
        data={codes}
        keyExtractor={(item) => String(item.id)}
        ListHeaderComponent={Header}
        stickyHeaderIndices={[]}
        renderItem={({ item }) => (
          <CodeCard
            code={item}
            onClaim={handleClaim}
            claimLoading={claimingId === item.id}
          />
        )}
        contentContainerStyle={styles.listContent}
        refreshControl={
          <RefreshControl refreshing={isRefetching} onRefresh={refetch} tintColor={colors.primary} />
        }
        ListEmptyComponent={
          isLoading ? null : (
            <EmptyState
              icon="inbox"
              title="No codes yet"
              description={search ? "Try a different search term" : "Be the first to post a referral code!"}
            />
          )
        }
        scrollEnabled={true}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  hero: {
    paddingHorizontal: 20,
    paddingBottom: 20,
    gap: 16,
  },
  heroTop: { gap: 4 },
  logoRow: { flexDirection: "row", alignItems: "center", gap: 7, marginBottom: 8 },
  logoIcon: {
    width: 26,
    height: 26,
    borderRadius: 8,
    backgroundColor: "rgba(255,255,255,0.2)",
    alignItems: "center",
    justifyContent: "center",
  },
  logoText: { fontSize: 13, fontFamily: "Inter_600SemiBold", color: "rgba(255,255,255,0.85)", letterSpacing: 0.3 },
  heroTitle: { fontSize: 26, fontFamily: "Nunito_800ExtraBold", color: "#FFFFFF", letterSpacing: -0.5 },
  heroSub: { fontSize: 14, fontFamily: "Inter_400Regular", color: "rgba(255,255,255,0.65)" },
  searchWrap: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#FFFFFF",
    borderRadius: 12,
    paddingHorizontal: 12,
    height: 44,
    gap: 8,
  },
  searchIcon: {},
  searchInput: {
    flex: 1,
    fontSize: 15,
    fontFamily: "Inter_400Regular",
    color: "#111827",
  },
  clearBtn: { padding: 4 },
  catWrap: {
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  catScroll: { paddingHorizontal: 16, paddingVertical: 10, gap: 8 },
  catPill: { paddingHorizontal: 14, paddingVertical: 6, borderRadius: 99 },
  catPillText: { fontSize: 13 },
  listContent: { paddingTop: 8, paddingBottom: 32, flexGrow: 1 },
});

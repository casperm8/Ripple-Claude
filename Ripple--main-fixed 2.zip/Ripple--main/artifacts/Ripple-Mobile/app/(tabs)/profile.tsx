import { useAuth, useUser } from "@clerk/expo";
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { LinearGradient } from "expo-linear-gradient";
import * as WebBrowser from "expo-web-browser";
import { router, useFocusEffect } from "expo-router";
import React, { useCallback, useState } from "react";
import {
  Alert,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
  ActivityIndicator,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { useColors } from "@/hooks/useColors";
import {
  useGetMe,
  getGetMeQueryKey,
  useGetPlans,
  getGetPlansQueryKey,
  useCreateCheckout,
  useCreateBillingPortal,
} from "@workspace/api-client-react";

export default function ProfileScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { isSignedIn, signOut } = useAuth();
  const { user } = useUser();
  const meQ = useGetMe({ query: { queryKey: getGetMeQueryKey(), enabled: !!isSignedIn } });
  const plansQ = useGetPlans({ query: { queryKey: getGetPlansQueryKey(), enabled: !!isSignedIn } });

  const [checkoutLoading, setCheckoutLoading] = useState(false);
  const [portalLoading, setPortalLoading] = useState(false);

  const checkout = useCreateCheckout();
  const portal = useCreateBillingPortal();

  useFocusEffect(
    useCallback(() => {
      meQ.refetch();
    }, [])
  );

  const topPad = Platform.OS === "web" ? 67 : insets.top;
  const botPad = Platform.OS === "web" ? 34 : insets.bottom;

  const handleUpgrade = async () => {
    const plans = plansQ.data;
    const monthlyPlan = plans?.find((p) => p.interval === "month") ?? plans?.[0];
    if (!monthlyPlan?.priceId) {
      Alert.alert("Unavailable", "Plans could not be loaded. Please try again.");
      return;
    }
    if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setCheckoutLoading(true);
    try {
      const result = await checkout.mutateAsync({
        data: {
          priceId: monthlyPlan.priceId,
          successUrl: "",
          cancelUrl: "",
        },
      });
      if (result.url) {
        await WebBrowser.openBrowserAsync(result.url);
        meQ.refetch();
      }
    } catch {
      Alert.alert("Error", "Could not start checkout. Please try again.");
    } finally {
      setCheckoutLoading(false);
    }
  };

  const handleManageBilling = async () => {
    setPortalLoading(true);
    try {
      const result = await portal.mutateAsync();
      if (result.url) {
        await WebBrowser.openBrowserAsync(result.url);
        meQ.refetch();
      }
    } catch {
      Alert.alert("Error", "Could not open billing portal. Please try again.");
    } finally {
      setPortalLoading(false);
    }
  };

  // In development, EXPO_PUBLIC_E2E_TEST=1 allows Playwright to reach the
  // authenticated content without real Clerk auth (used only by the automated
  // e2e screenshot suite). The __DEV__ guard prevents this bypass from ever
  // activating in a production build even if the env var were set accidentally.
  const isE2EBypass = __DEV__ && process.env.EXPO_PUBLIC_E2E_TEST === "1";

  if (!isSignedIn && !isE2EBypass) {
    return (
      <View style={[styles.gate, { backgroundColor: colors.background }]}>
        <LinearGradient colors={["#0369A1", "#0284C7"]} style={[styles.gateGrad, { paddingTop: topPad + 20 }]}>
          <View style={styles.gateAvatar}>
            <Feather name="user" size={32} color="#FFFFFF" />
          </View>
        </LinearGradient>
        <View style={[styles.gateSheet, { backgroundColor: colors.background }]}>
          <Text style={[styles.gateTitle, { color: colors.foreground }]} maxFontSizeMultiplier={1.4}>Your Profile</Text>
          <Text style={[styles.gateSub, { color: colors.mutedForeground }]} maxFontSizeMultiplier={1.3}>
            Sign in to manage your account and track your activity.
          </Text>
          <Pressable
            style={({ pressed }) => [styles.gateBtn, { backgroundColor: colors.primary, opacity: pressed ? 0.85 : 1 }]}
            onPress={() => router.push("/sign-in")}
          >
            <Text style={[styles.gateBtnText, { color: colors.primaryForeground }]} maxFontSizeMultiplier={1.0}>Sign In</Text>
          </Pressable>
        </View>
      </View>
    );
  }

  const me = meQ.data;
  const isPro = me?.tier === "pro";
  const name = user?.fullName || user?.primaryEmailAddress?.emailAddress?.split("@")[0] || "User";
  const email = user?.primaryEmailAddress?.emailAddress ?? "";
  const initial = name.charAt(0).toUpperCase();

  const signOutConfirm = () => {
    Alert.alert("Sign Out", "Are you sure?", [
      { text: "Cancel", style: "cancel" },
      {
        text: "Sign Out",
        style: "destructive",
        onPress: async () => {
          if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
          await signOut();
        },
      },
    ]);
  };

  return (
    <ScrollView
      style={[styles.container, { backgroundColor: colors.background }]}
      contentContainerStyle={{ paddingBottom: botPad + 32 }}
      showsVerticalScrollIndicator={false}
    >
      <LinearGradient
        colors={["#0369A1", "#0284C7", "#0EA5E9"]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={[styles.header, { paddingTop: topPad + 20 }]}
      >
        <View style={styles.avatarRing}>
          <View style={styles.avatar}>
            <Text style={styles.avatarInitial} maxFontSizeMultiplier={1.0}>{initial}</Text>
          </View>
        </View>
        <Text style={styles.headerName} maxFontSizeMultiplier={1.4}>{name}</Text>
        <Text style={styles.headerEmail} maxFontSizeMultiplier={1.3}>{email}</Text>
        <View style={[styles.tierBadge, { backgroundColor: isPro ? "#FBBF24" : "rgba(255,255,255,0.2)" }]}>
          {isPro && <Feather name="zap" size={11} color="#92400E" />}
          <Text style={[styles.tierText, { color: isPro ? "#92400E" : "rgba(255,255,255,0.9)" }]} maxFontSizeMultiplier={1.0}>
            {isPro ? "Pro Member" : "Free Tier"}
          </Text>
        </View>
      </LinearGradient>

      <View style={styles.body}>
        {me && (
          <View style={styles.statsRow}>
            <View style={[styles.statCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
              <Text style={[styles.statNum, { color: colors.primary }]} maxFontSizeMultiplier={1.4}>
                {me.codesPostedThisWeek}
                {me.weeklyPostLimit != null && (
                  <Text style={[styles.statDenom, { color: colors.mutedForeground }]} maxFontSizeMultiplier={1.4}>/{me.weeklyPostLimit}</Text>
                )}
              </Text>
              <Text style={[styles.statLabel, { color: colors.mutedForeground }]} maxFontSizeMultiplier={1.3}>Posts this week</Text>
            </View>
            <View style={[styles.statCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
              <Text style={[styles.statNum, { color: colors.primary }]} maxFontSizeMultiplier={1.4}>
                {me.requestsToday}
                {me.dailyRequestLimit != null && (
                  <Text style={[styles.statDenom, { color: colors.mutedForeground }]} maxFontSizeMultiplier={1.4}>/{me.dailyRequestLimit}</Text>
                )}
              </Text>
              <Text style={[styles.statLabel, { color: colors.mutedForeground }]} maxFontSizeMultiplier={1.3}>Claims today</Text>
            </View>
          </View>
        )}

        {!isPro && (
          <Pressable onPress={checkoutLoading ? undefined : handleUpgrade} disabled={checkoutLoading}>
            {({ pressed }) => (
              <LinearGradient
                colors={["#4338CA", "#7C3AED"]}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 0 }}
                style={[styles.upgradeCard, { opacity: pressed || checkoutLoading ? 0.75 : 1 }]}
              >
                <View style={styles.upgradeLeft}>
                  <View style={styles.upgradeIconWrap}>
                    {checkoutLoading ? (
                      <ActivityIndicator size="small" color="#FBBF24" />
                    ) : (
                      <Feather name="zap" size={18} color="#FBBF24" />
                    )}
                  </View>
                  <View>
                    <Text style={styles.upgradeTitle} maxFontSizeMultiplier={1.3}>
                      {checkoutLoading ? "Opening checkout…" : "Upgrade to Pro"}
                    </Text>
                    <Text style={styles.upgradeDesc} maxFontSizeMultiplier={1.3}>$9.99/mo · Unlimited claims · No ads</Text>
                  </View>
                </View>
                {!checkoutLoading && <Feather name="arrow-right" size={18} color="rgba(255,255,255,0.7)" />}
              </LinearGradient>
            )}
          </Pressable>
        )}

        <View style={[styles.menuCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
          {isPro && (
            <Pressable
              style={({ pressed }) => [
                styles.menuItem,
                { borderBottomColor: colors.border, borderBottomWidth: 1, opacity: pressed ? 0.7 : 1 },
              ]}
              onPress={portalLoading ? undefined : handleManageBilling}
              disabled={portalLoading}
            >
              <View style={[styles.menuIconBox, { backgroundColor: colors.primary + "15" }]}>
                {portalLoading ? (
                  <ActivityIndicator size="small" color={colors.primary} />
                ) : (
                  <Feather name="credit-card" size={16} color={colors.primary} />
                )}
              </View>
              <Text style={[styles.menuLabel, { color: colors.foreground }]} maxFontSizeMultiplier={1.3}>
                {portalLoading ? "Opening portal…" : "Manage Billing"}
              </Text>
              <Feather name="chevron-right" size={16} color={colors.mutedForeground} />
            </Pressable>
          )}

          <Pressable
            style={({ pressed }) => [styles.menuItem, { borderBottomColor: colors.border, opacity: pressed ? 0.7 : 1 }]}
            onPress={signOutConfirm}
          >
            <View style={[styles.menuIconBox, { backgroundColor: colors.destructive + "15" }]}>
              <Feather name="log-out" size={16} color={colors.destructive} />
            </View>
            <Text style={[styles.menuLabel, { color: colors.destructive }]} maxFontSizeMultiplier={1.3}>Sign Out</Text>
            <Feather name="chevron-right" size={16} color={colors.destructive + "60"} />
          </Pressable>
        </View>

        <Text style={[styles.footer, { color: colors.mutedForeground }]} maxFontSizeMultiplier={1.3}>
          Ripple · Every referral creates a ripple
        </Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { alignItems: "center", paddingBottom: 32, gap: 8, paddingHorizontal: 20 },
  avatarRing: {
    width: 80,
    height: 80,
    borderRadius: 40,
    borderWidth: 3,
    borderColor: "rgba(255,255,255,0.3)",
    padding: 3,
    marginBottom: 4,
  },
  avatar: { flex: 1, borderRadius: 36, backgroundColor: "rgba(255,255,255,0.25)", alignItems: "center", justifyContent: "center" },
  avatarInitial: { fontSize: 28, fontFamily: "Inter_700Bold", color: "#FFFFFF" },
  headerName: { fontSize: 20, fontFamily: "Nunito_800ExtraBold", color: "#FFFFFF", letterSpacing: -0.3 },
  headerEmail: { fontSize: 13, fontFamily: "Inter_400Regular", color: "rgba(255,255,255,0.65)" },
  tierBadge: { flexDirection: "row", alignItems: "center", gap: 5, paddingHorizontal: 12, paddingVertical: 5, borderRadius: 99, marginTop: 4 },
  tierText: { fontSize: 12, fontFamily: "Inter_600SemiBold" },
  body: { padding: 16, gap: 12 },
  statsRow: { flexDirection: "row", gap: 12 },
  statCard: { flex: 1, padding: 16, borderRadius: 14, borderWidth: 1, gap: 4, shadowColor: "#1E1B4B", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.05, shadowRadius: 4, elevation: 1 },
  statNum: { fontSize: 26, fontFamily: "Inter_700Bold" },
  statDenom: { fontSize: 16, fontFamily: "Inter_400Regular" },
  statLabel: { fontSize: 12, fontFamily: "Inter_400Regular" },
  upgradeCard: { borderRadius: 14, padding: 16, flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  upgradeLeft: { flexDirection: "row", alignItems: "center", gap: 12, flex: 1 },
  upgradeIconWrap: { width: 36, height: 36, borderRadius: 10, backgroundColor: "rgba(255,255,255,0.15)", alignItems: "center", justifyContent: "center" },
  upgradeTitle: { fontSize: 15, fontFamily: "Inter_600SemiBold", color: "#FFFFFF" },
  upgradeDesc: { fontSize: 12, fontFamily: "Inter_400Regular", color: "rgba(255,255,255,0.7)", marginTop: 1 },
  menuCard: { borderRadius: 14, borderWidth: 1, overflow: "hidden", shadowColor: "#1E1B4B", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.05, shadowRadius: 4, elevation: 1 },
  menuItem: { flexDirection: "row", alignItems: "center", padding: 16, gap: 12 },
  menuIconBox: { width: 34, height: 34, borderRadius: 9, alignItems: "center", justifyContent: "center" },
  menuLabel: { fontSize: 15, fontFamily: "Inter_500Medium", flex: 1 },
  footer: { textAlign: "center", fontSize: 12, fontFamily: "Inter_400Regular", marginTop: 8 },
  gate: { flex: 1 },
  gateGrad: { height: 220, alignItems: "center", justifyContent: "flex-end", paddingBottom: 28 },
  gateAvatar: { width: 80, height: 80, borderRadius: 40, backgroundColor: "rgba(255,255,255,0.2)", alignItems: "center", justifyContent: "center" },
  gateSheet: { flex: 1, paddingHorizontal: 32, paddingTop: 32, gap: 14, alignItems: "center" },
  gateTitle: { fontSize: 22, fontFamily: "Nunito_800ExtraBold", textAlign: "center" },
  gateSub: { fontSize: 15, fontFamily: "Inter_400Regular", textAlign: "center", lineHeight: 22 },
  gateBtn: { width: "100%", height: 50, borderRadius: 12, alignItems: "center", justifyContent: "center", marginTop: 8 },
  gateBtnText: { fontSize: 16, fontFamily: "Inter_600SemiBold" },
});

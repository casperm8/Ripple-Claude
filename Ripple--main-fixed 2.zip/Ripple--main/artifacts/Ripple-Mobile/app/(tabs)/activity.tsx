import { useAuth } from "@clerk/expo";
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { LinearGradient } from "expo-linear-gradient";
import { router } from "expo-router";
import React, { useState } from "react";
import {
  Alert,
  FlatList,
  Platform,
  Pressable,
  RefreshControl,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { CodeCard, CATEGORY_COLORS, CodeItem } from "@/components/CodeCard";
import { EmptyState } from "@/components/EmptyState";
import { useColors } from "@/hooks/useColors";
import { useDeleteCode, useGetMyClaims, useGetMyCodes, getGetMyClaimsQueryKey, getGetMyCodesQueryKey } from "@workspace/api-client-react";

type Tab = "codes" | "claims";

export default function ActivityScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { isSignedIn } = useAuth();
  const [tab, setTab] = useState<Tab>("codes");
  const [deletingId, setDeletingId] = useState<number | null>(null);

  const topPad = Platform.OS === "web" ? 67 : insets.top;

  const codesQ = useGetMyCodes({ limit: 50 }, { query: { queryKey: getGetMyCodesQueryKey({ limit: 50 }), enabled: !!isSignedIn } });
  const claimsQ = useGetMyClaims({ limit: 50 }, { query: { queryKey: getGetMyClaimsQueryKey({ limit: 50 }), enabled: !!isSignedIn } });
  const deleteMut = useDeleteCode();

  if (!isSignedIn) {
    return (
      <View style={[styles.gate, { backgroundColor: colors.background }]}>
        <LinearGradient colors={["#0369A1", "#0284C7"]} style={[styles.gateGrad, { paddingTop: topPad + 20 }]}>
          <View style={styles.gateIcon}>
            <Feather name="list" size={28} color="#FFFFFF" />
          </View>
        </LinearGradient>
        <View style={[styles.gateSheet, { backgroundColor: colors.background }]}>
          <Text style={[styles.gateTitle, { color: colors.foreground }]} maxFontSizeMultiplier={1.4}>Your Activity</Text>
          <Text style={[styles.gateSub, { color: colors.mutedForeground }]}>
            Sign in to track your posted codes and claimed rewards.
          </Text>
          <Pressable
            style={({ pressed }) => [styles.gateBtn, { backgroundColor: colors.primary, opacity: pressed ? 0.85 : 1 }]}
            onPress={() => router.push("/sign-in")}
          >
            <Text style={[styles.gateBtnText, { color: colors.primaryForeground }]}>Sign In</Text>
          </Pressable>
        </View>
      </View>
    );
  }

  const handleDelete = async (id: number) => {
    setDeletingId(id);
    try {
      await deleteMut.mutateAsync({ id });
      if (Platform.OS !== "web") Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      codesQ.refetch();
    } catch {
      Alert.alert("Error", "Could not delete this code.");
    } finally {
      setDeletingId(null);
    }
  };

  const myCodes = (codesQ.data?.codes ?? []) as CodeItem[];
  const myClaims = codesQ.data ? (claimsQ.data?.claims ?? []) : [];

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      {/* Gradient header */}
      <LinearGradient
        colors={["#0369A1", "#0284C7", "#0EA5E9"]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={[styles.header, { paddingTop: topPad + 12 }]}
      >
        <Text style={styles.headerTitle} maxFontSizeMultiplier={1.4}>Activity</Text>

        {/* Segmented control */}
        <View style={styles.segWrap}>
          <Pressable
            onPress={() => setTab("codes")}
            style={[styles.segBtn, tab === "codes" && styles.segActive]}
          >
            <Feather name="tag" size={14} color={tab === "codes" ? "#0284C7" : "rgba(255,255,255,0.65)"} />
            <Text style={[styles.segText, { color: tab === "codes" ? "#0284C7" : "rgba(255,255,255,0.75)", fontFamily: tab === "codes" ? "Inter_600SemiBold" : "Inter_400Regular" }]}>
              My Codes
              {myCodes.length > 0 && <Text style={{ fontSize: 11 }}> {myCodes.length}</Text>}
            </Text>
          </Pressable>
          <Pressable
            onPress={() => setTab("claims")}
            style={[styles.segBtn, tab === "claims" && styles.segActive]}
          >
            <Feather name="download" size={14} color={tab === "claims" ? "#0284C7" : "rgba(255,255,255,0.65)"} />
            <Text style={[styles.segText, { color: tab === "claims" ? "#0284C7" : "rgba(255,255,255,0.75)", fontFamily: tab === "claims" ? "Inter_600SemiBold" : "Inter_400Regular" }]}>
              My Claims
              {myClaims.length > 0 && <Text style={{ fontSize: 11 }}> {myClaims.length}</Text>}
            </Text>
          </Pressable>
        </View>
      </LinearGradient>

      {tab === "codes" ? (
        <FlatList
          data={myCodes}
          keyExtractor={(item) => String(item.id)}
          renderItem={({ item }) => (
            <CodeCard
              code={item}
              onDelete={handleDelete}
              deleteLoading={deletingId === item.id}
              showDelete
            />
          )}
          contentContainerStyle={styles.listContent}
          refreshControl={
            <RefreshControl refreshing={codesQ.isRefetching} onRefresh={codesQ.refetch} tintColor={colors.primary} />
          }
          ListEmptyComponent={
            codesQ.isLoading ? null : (
              <EmptyState icon="tag" title="No codes posted" description="Post a referral code to see it here." />
            )
          }
          scrollEnabled={true}
        />
      ) : (
        <FlatList
          data={myClaims}
          keyExtractor={(item) => String(item.id)}
          renderItem={({ item }) => {
            const catColor = CATEGORY_COLORS[item.category?.toLowerCase()] ?? "#64748B";
            return (
              <View style={[styles.claimCard, { backgroundColor: colors.card, borderLeftColor: catColor, shadowColor: colors.border }]}>
                <View style={styles.claimTop}>
                  <View style={[styles.claimCatPill, { backgroundColor: catColor + "18" }]}>
                    <View style={[styles.claimCatDot, { backgroundColor: catColor }]} />
                    <Text style={[styles.claimCatText, { color: catColor }]}>
                      {item.category?.charAt(0).toUpperCase() + item.category?.slice(1).toLowerCase()}
                    </Text>
                  </View>
                  <Text style={[styles.claimDate, { color: colors.mutedForeground }]}>
                    {new Date(item.claimedAt).toLocaleDateString("en-US", { month: "short", day: "numeric" })}
                  </Text>
                </View>
                <Text style={[styles.claimTitle, { color: colors.foreground }]} numberOfLines={1}>
                  {item.codeTitle}
                </Text>
                <View style={[styles.claimCodeBox, { backgroundColor: catColor + "12", borderRadius: 10 }]}>
                  <Feather name="tag" size={14} color={catColor} />
                  <Text style={[styles.claimCode, { color: catColor }]}>{item.code}</Text>
                  <Text style={[styles.claimCodeHint, { color: catColor + "80" }]}>Tap to copy</Text>
                </View>
              </View>
            );
          }}
          contentContainerStyle={styles.listContent}
          refreshControl={
            <RefreshControl refreshing={claimsQ.isRefetching} onRefresh={claimsQ.refetch} tintColor={colors.primary} />
          }
          ListEmptyComponent={
            claimsQ.isLoading ? null : (
              <EmptyState icon="download" title="No claims yet" description="Browse codes and claim your first deal." />
            )
          }
          scrollEnabled={true}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { paddingHorizontal: 20, paddingBottom: 16, gap: 16 },
  headerTitle: { fontSize: 26, fontFamily: "Nunito_800ExtraBold", color: "#FFFFFF", letterSpacing: -0.5 },
  segWrap: { flexDirection: "row", backgroundColor: "rgba(255,255,255,0.15)", borderRadius: 12, padding: 4, gap: 4 },
  segBtn: { flex: 1, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 6, paddingVertical: 9, borderRadius: 10 },
  segActive: { backgroundColor: "#FFFFFF" },
  segText: { fontSize: 14 },
  listContent: { paddingTop: 10, paddingBottom: 32, flexGrow: 1 },
  claimCard: {
    marginHorizontal: 16,
    marginVertical: 5,
    padding: 15,
    borderRadius: 12,
    borderLeftWidth: 3,
    gap: 10,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.06,
    shadowRadius: 8,
    elevation: 2,
  },
  claimTop: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  claimCatPill: { flexDirection: "row", alignItems: "center", gap: 5, paddingHorizontal: 9, paddingVertical: 4, borderRadius: 99 },
  claimCatDot: { width: 6, height: 6, borderRadius: 3 },
  claimCatText: { fontSize: 11, fontFamily: "Inter_600SemiBold" },
  claimDate: { fontSize: 12, fontFamily: "Inter_400Regular" },
  claimTitle: { fontSize: 15, fontFamily: "Inter_600SemiBold", letterSpacing: -0.2 },
  claimCodeBox: { flexDirection: "row", alignItems: "center", gap: 8, padding: 12 },
  claimCode: { fontSize: 16, fontFamily: "Inter_700Bold", letterSpacing: 1.5, flex: 1 },
  claimCodeHint: { fontSize: 11, fontFamily: "Inter_400Regular" },
  gate: { flex: 1 },
  gateGrad: { height: 200, alignItems: "center", justifyContent: "flex-end", paddingBottom: 28 },
  gateIcon: { width: 72, height: 72, borderRadius: 36, backgroundColor: "rgba(255,255,255,0.2)", alignItems: "center", justifyContent: "center" },
  gateSheet: { flex: 1, paddingHorizontal: 32, paddingTop: 32, gap: 14, alignItems: "center" },
  gateTitle: { fontSize: 22, fontFamily: "Nunito_800ExtraBold", textAlign: "center" },
  gateSub: { fontSize: 15, fontFamily: "Inter_400Regular", textAlign: "center", lineHeight: 22 },
  gateBtn: { width: "100%", height: 50, borderRadius: 12, alignItems: "center", justifyContent: "center", marginTop: 8 },
  gateBtnText: { fontSize: 16, fontFamily: "Inter_600SemiBold" },
});

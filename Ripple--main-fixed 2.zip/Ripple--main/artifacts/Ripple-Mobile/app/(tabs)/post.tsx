import { useAuth } from "@clerk/expo";
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { LinearGradient } from "expo-linear-gradient";
import { router } from "expo-router";
import React, { useMemo, useState } from "react";
import {
  ActivityIndicator,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { CATEGORY_COLORS } from "@/components/CodeCard";
import { useColors } from "@/hooks/useColors";
import { useCreateCode } from "@workspace/api-client-react";

const CATEGORIES: { id: string; icon: keyof typeof Feather.glyphMap }[] = [
  { id: "shopping",      icon: "shopping-bag" },
  { id: "travel",        icon: "map-pin" },
  { id: "tech",          icon: "cpu" },
  { id: "food",          icon: "coffee" },
  { id: "entertainment", icon: "film" },
  { id: "finance",       icon: "trending-up" },
  { id: "beauty",        icon: "star" },
  { id: "health",        icon: "heart" },
  { id: "other",         icon: "grid" },
];

const CODE_MAX = 50;
const CLAIMS_MIN = 1;
const CLAIMS_MAX = 100;

const VALID_CATEGORY_IDS = new Set(CATEGORIES.map((c) => c.id));

function validateFields(
  title: string,
  code: string,
  description: string,
  maxClaims: number,
  category: string,
) {
  const errors: Record<string, string> = {};
  if (!title.trim()) {
    errors.title = "Title is required.";
  }
  if (!code.trim()) {
    errors.code = "Referral code is required.";
  } else if (code.trim().length > CODE_MAX) {
    errors.code = `Code must be ${CODE_MAX} characters or fewer.`;
  }
  if (!description.trim()) {
    errors.description = "Description is required.";
  }
  if (maxClaims < CLAIMS_MIN || maxClaims > CLAIMS_MAX) {
    errors.maxClaims = `Max claims must be between ${CLAIMS_MIN} and ${CLAIMS_MAX}.`;
  }
  if (!category || !VALID_CATEGORY_IDS.has(category)) {
    errors.category = "Please select a category.";
  }
  return errors;
}

export default function PostScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { isSignedIn } = useAuth();
  const createMutation = useCreateCode();

  const topPad = Platform.OS === "web" ? 67 : insets.top;
  const botPad = Platform.OS === "web" ? 34 : insets.bottom;

  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [code, setCode] = useState("");
  const [category, setCategory] = useState("shopping");
  const [maxClaims, setMaxClaims] = useState(10);
  const [serverError, setServerError] = useState("");

  const [touched, setTouched] = useState<Record<string, boolean>>({});

  const fieldErrors = useMemo(
    () => validateFields(title, code, description, maxClaims, category),
    [title, code, description, maxClaims, category]
  );

  const isFormValid = Object.keys(fieldErrors).length === 0;

  const touch = (field: string) =>
    setTouched((prev) => ({ ...prev, [field]: true }));

  const visibleError = (field: string) =>
    touched[field] ? (fieldErrors[field] ?? "") : "";

  // In development, EXPO_PUBLIC_E2E_TEST=1 allows Playwright to reach the form
  // without real Clerk auth (used only by the automated e2e test suite). The
  // __DEV__ guard prevents this bypass from ever activating in a production
  // build even if the env var were set accidentally.
  const isE2EBypass = __DEV__ && process.env.EXPO_PUBLIC_E2E_TEST === "1";

  if (!isSignedIn && !isE2EBypass) {
    return (
      <View style={[styles.gate, { backgroundColor: colors.background }]}>
        <LinearGradient colors={["#0369A1", "#0284C7"]} style={[styles.gateGrad, { paddingTop: topPad + 20 }]}>
          <View style={styles.gateIcon}>
            <Feather name="lock" size={28} color="#FFFFFF" />
          </View>
        </LinearGradient>
        <View style={[styles.gateSheet, { backgroundColor: colors.background }]}>
          <Text style={[styles.gateTitle, { color: colors.foreground }]} maxFontSizeMultiplier={1.4}>Sign in to post</Text>
          <Text style={[styles.gateSub, { color: colors.mutedForeground }]} maxFontSizeMultiplier={1.3}>
            Share your referral codes with thousands of users.
          </Text>
          <Pressable
            style={({ pressed }) => [styles.gateBtn, { backgroundColor: colors.primary, opacity: pressed ? 0.85 : 1 }]}
            onPress={() => router.push("/sign-in")}
          >
            <Text style={[styles.gateBtnText, { color: colors.primaryForeground }]} maxFontSizeMultiplier={1.0}>Sign In</Text>
          </Pressable>
        </View>
      </View>
    );
  }

  const submit = async () => {
    setTouched({ title: true, code: true, description: true, maxClaims: true, category: true });
    if (!isFormValid) return;
    setServerError("");
    try {
      await createMutation.mutateAsync({
        data: {
          title: title.trim(),
          description: description.trim(),
          code: code.trim(),
          category,
          maxClaims,
        },
      });
      if (Platform.OS !== "web") Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      setTitle("");
      setDescription("");
      setCode("");
      setCategory("shopping");
      setMaxClaims(10);
      setTouched({});
      router.push("/(tabs)");
    } catch (err: any) {
      setServerError(err?.response?.data?.error ?? err?.message ?? "Failed to post. Please try again.");
    }
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <LinearGradient
        colors={["#0369A1", "#0284C7", "#0EA5E9"]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={[styles.header, { paddingTop: topPad + 12 }]}
      >
        <Text style={styles.headerTitle} maxFontSizeMultiplier={1.4}>Share a Code</Text>
        <Text style={styles.headerSub} maxFontSizeMultiplier={1.3}>Help others save money</Text>
      </LinearGradient>

      <ScrollView
        contentContainerStyle={[styles.scroll, { paddingBottom: botPad + 24 }]}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        {/* Code first — most important */}
        <View style={[styles.section, { backgroundColor: colors.card, borderColor: visibleError("code") ? colors.destructive : colors.border }]}>
          <Text style={[styles.sectionLabel, { color: colors.mutedForeground }]} maxFontSizeMultiplier={1.0}>Referral Code</Text>
          <TextInput
            style={[styles.codeField, { color: colors.primary, borderBottomColor: visibleError("code") ? colors.destructive : colors.border }]}
            value={code}
            onChangeText={setCode}
            onBlur={() => touch("code")}
            placeholder="MYCODE2024"
            placeholderTextColor={colors.border}
            autoCapitalize="characters"
            maxLength={CODE_MAX}
            maxFontSizeMultiplier={1.3}
          />
          {visibleError("code") !== "" ? (
            <InlineError message={visibleError("code")} color={colors.destructive} />
          ) : (
            <Text style={[styles.fieldHint, { color: colors.mutedForeground }]} maxFontSizeMultiplier={1.3}>
              The actual code people will claim · max {CODE_MAX} characters
            </Text>
          )}
        </View>

        {/* Title & description */}
        <View style={[styles.section, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <View style={styles.fieldGroup}>
            <Text style={[styles.fieldLabel, { color: colors.mutedForeground }]} maxFontSizeMultiplier={1.0}>Title</Text>
            <TextInput
              style={[styles.field, { color: colors.foreground, borderBottomColor: visibleError("title") ? colors.destructive : colors.border }]}
              value={title}
              onChangeText={setTitle}
              onBlur={() => touch("title")}
              placeholder="e.g. $20 off your first order"
              placeholderTextColor={colors.border}
              maxLength={100}
            />
            {visibleError("title") !== "" && (
              <InlineError message={visibleError("title")} color={colors.destructive} />
            )}
          </View>
          <View style={[styles.fieldDivider, { backgroundColor: colors.muted }]} />
          <View style={styles.fieldGroup}>
            <Text style={[styles.fieldLabel, { color: colors.mutedForeground }]} maxFontSizeMultiplier={1.0}>Description</Text>
            <TextInput
              style={[styles.textareaField, { color: colors.foreground }]}
              value={description}
              onChangeText={setDescription}
              onBlur={() => touch("description")}
              placeholder="Describe the deal and how to use it…"
              placeholderTextColor={colors.border}
              multiline
              numberOfLines={3}
              maxLength={500}
              textAlignVertical="top"
            />
            {visibleError("description") !== "" && (
              <InlineError message={visibleError("description")} color={colors.destructive} />
            )}
          </View>
        </View>

        {/* Category grid */}
        <View style={[styles.section, { backgroundColor: colors.card, borderColor: visibleError("category") ? colors.destructive : colors.border }]}>
          <Text style={[styles.sectionLabel, { color: colors.mutedForeground }]} maxFontSizeMultiplier={1.0}>Category</Text>
          <View style={styles.catGrid}>
            {CATEGORIES.map(({ id, icon }) => {
              const isActive = category === id;
              const catColor = CATEGORY_COLORS[id] ?? colors.primary;
              return (
                <Pressable
                  key={id}
                  onPress={() => { setCategory(id); touch("category"); }}
                  style={({ pressed }) => [
                    styles.catTile,
                    {
                      backgroundColor: isActive ? catColor + "20" : colors.muted,
                      borderColor: isActive ? catColor : "transparent",
                      opacity: pressed ? 0.8 : 1,
                    },
                  ]}
                >
                  <View style={[styles.catTileIcon, { backgroundColor: isActive ? catColor + "30" : colors.background }]}>
                    <Feather name={icon} size={16} color={isActive ? catColor : colors.mutedForeground} />
                  </View>
                  <Text style={[styles.catTileText, { color: isActive ? catColor : colors.mutedForeground, fontFamily: isActive ? "Inter_600SemiBold" : "Inter_400Regular" }]} maxFontSizeMultiplier={1.0}>
                    {id.charAt(0).toUpperCase() + id.slice(1)}
                  </Text>
                </Pressable>
              );
            })}
          </View>
          {visibleError("category") !== "" && (
            <InlineError message={visibleError("category")} color={colors.destructive} />
          )}
        </View>

        {/* Max claims stepper */}
        <View style={[styles.section, { backgroundColor: colors.card, borderColor: visibleError("maxClaims") ? colors.destructive : colors.border }]}>
          <Text style={[styles.sectionLabel, { color: colors.mutedForeground }]} maxFontSizeMultiplier={1.0}>Max Claims</Text>
          {/* Dev-only: hidden input so E2E tests can set an out-of-range value to trigger validation */}
          {isE2EBypass && (
            <TextInput
              accessibilityLabel="maxClaims test override"
              style={{ width: 0, height: 0, opacity: 0, overflow: "hidden" }}
              value={String(maxClaims)}
              onChangeText={(v) => {
                const n = parseInt(v, 10);
                if (!isNaN(n)) { setMaxClaims(n); touch("maxClaims"); }
              }}
              keyboardType="number-pad"
            />
          )}
          <View style={styles.stepperRow}>
            <Pressable
              onPress={() => { setMaxClaims((v) => Math.max(CLAIMS_MIN, v - 1)); touch("maxClaims"); }}
              style={[styles.stepBtn, { backgroundColor: colors.muted }]}
              accessibilityLabel="Decrease max claims"
            >
              <Feather name="minus" size={16} color={colors.foreground} />
            </Pressable>
            <Text style={[styles.stepValue, { color: colors.foreground }]} maxFontSizeMultiplier={1.3}>{maxClaims}</Text>
            <Pressable
              onPress={() => { setMaxClaims((v) => Math.min(CLAIMS_MAX, v + 1)); touch("maxClaims"); }}
              style={[styles.stepBtn, { backgroundColor: colors.muted }]}
              accessibilityLabel="Increase max claims"
            >
              <Feather name="plus" size={16} color={colors.foreground} />
            </Pressable>
            <Text style={[styles.stepHint, { color: colors.mutedForeground }]} maxFontSizeMultiplier={1.3}>
              people can claim · max {CLAIMS_MAX}
            </Text>
          </View>
          {visibleError("maxClaims") !== "" && (
            <InlineError message={visibleError("maxClaims")} color={colors.destructive} />
          )}
        </View>

        {serverError !== "" && (
          <View style={[styles.errorBox, { backgroundColor: colors.destructive + "15" }]}>
            <Feather name="alert-circle" size={14} color={colors.destructive} />
            <Text style={[styles.errorText, { color: colors.destructive }]} maxFontSizeMultiplier={1.3}>{serverError}</Text>
          </View>
        )}

        <Pressable
          style={({ pressed }) => [
            styles.submitBtn,
            {
              backgroundColor: colors.primary,
              opacity: pressed || createMutation.isPending || !isFormValid ? 0.5 : 1,
            },
          ]}
          onPress={submit}
          disabled={createMutation.isPending}
        >
          {createMutation.isPending
            ? <ActivityIndicator color="#FFFFFF" />
            : (
              <>
                <Feather name="send" size={16} color="#FFFFFF" />
                <Text style={styles.submitText} maxFontSizeMultiplier={1.0}>Post Code</Text>
              </>
            )}
        </Pressable>
      </ScrollView>
    </View>
  );
}

function InlineError({ message, color }: { message: string; color: string }) {
  return (
    <View style={styles.inlineErrorRow}>
      <Feather name="alert-circle" size={12} color={color} />
      <Text style={[styles.inlineErrorText, { color }]} maxFontSizeMultiplier={1.3}>{message}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  gate: { flex: 1 },
  gateGrad: { height: 200, alignItems: "center", justifyContent: "flex-end", paddingBottom: 28 },
  gateIcon: { width: 72, height: 72, borderRadius: 36, backgroundColor: "rgba(255,255,255,0.2)", alignItems: "center", justifyContent: "center" },
  gateSheet: { flex: 1, paddingHorizontal: 32, paddingTop: 32, gap: 14, alignItems: "center" },
  gateTitle: { fontSize: 22, fontFamily: "Nunito_800ExtraBold", textAlign: "center" },
  gateSub: { fontSize: 15, fontFamily: "Inter_400Regular", textAlign: "center", lineHeight: 22 },
  gateBtn: { width: "100%", height: 50, borderRadius: 12, alignItems: "center", justifyContent: "center", marginTop: 8 },
  gateBtnText: { fontSize: 16, fontFamily: "Inter_600SemiBold" },
  header: { paddingHorizontal: 20, paddingBottom: 20, gap: 4 },
  headerTitle: { fontSize: 26, fontFamily: "Nunito_800ExtraBold", color: "#FFFFFF", letterSpacing: -0.5 },
  headerSub: { fontSize: 14, fontFamily: "Inter_400Regular", color: "rgba(255,255,255,0.65)" },
  scroll: { padding: 16, gap: 12 },
  section: { borderRadius: 14, padding: 16, borderWidth: 1, gap: 12 },
  sectionLabel: { fontSize: 12, fontFamily: "Inter_600SemiBold", letterSpacing: 0.5, textTransform: "uppercase" },
  codeField: { fontSize: 22, fontFamily: "Inter_700Bold", letterSpacing: 2, paddingBottom: 8, borderBottomWidth: 1 },
  fieldHint: { fontSize: 12, fontFamily: "Inter_400Regular" },
  fieldGroup: { gap: 6 },
  fieldLabel: { fontSize: 12, fontFamily: "Inter_500Medium", letterSpacing: 0.3 },
  field: { fontSize: 15, fontFamily: "Inter_400Regular", paddingBottom: 8, borderBottomWidth: 1 },
  textareaField: { fontSize: 15, fontFamily: "Inter_400Regular", minHeight: 70 },
  fieldDivider: { height: 1 },
  catGrid: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  catTile: {
    width: "30%",
    alignItems: "center",
    padding: 10,
    borderRadius: 10,
    gap: 6,
    borderWidth: 1.5,
  },
  catTileIcon: { width: 36, height: 36, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  catTileText: { fontSize: 11, textAlign: "center" },
  stepperRow: { flexDirection: "row", alignItems: "center", gap: 16 },
  stepBtn: { width: 38, height: 38, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  stepValue: { fontSize: 24, fontFamily: "Inter_700Bold", minWidth: 40, textAlign: "center" },
  stepHint: { fontSize: 13, fontFamily: "Inter_400Regular" },
  errorBox: { borderRadius: 10, padding: 12, flexDirection: "row", gap: 8, alignItems: "flex-start" },
  errorText: { fontSize: 13, fontFamily: "Inter_400Regular", flex: 1, lineHeight: 18 },
  inlineErrorRow: { flexDirection: "row", alignItems: "center", gap: 5 },
  inlineErrorText: { fontSize: 12, fontFamily: "Inter_400Regular", flex: 1, lineHeight: 16 },
  submitBtn: { height: 52, borderRadius: 14, alignItems: "center", justifyContent: "center", flexDirection: "row", gap: 8, marginTop: 4 },
  submitText: { fontSize: 16, fontFamily: "Inter_600SemiBold", color: "#FFFFFF" },
});

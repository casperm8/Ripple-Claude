/**
 * Design tokens for the Referral Hub mobile app.
 *
 * NOTE — gradient headers:
 *   The blue LinearGradient headers across the tab screens use fixed Ripple
 *   brand colors ["#0369A1", "#0284C7", "#0EA5E9"] and intentionally do NOT
 *   adapt to the device color scheme. White Nunito headings on that blue
 *   gradient pass WCAG AA contrast in both light and dark mode, and the deep
 *   blue-to-dark-background transition in dark mode is more cohesive than
 *   the light-mode counterpart. The card/background tokens below DO switch
 *   palettes via useColors() → useColorScheme().
 *
 * NOTE — purple Upgrade card gradient (profile.tsx):
 *   The "Upgrade to Pro" CTA card uses a fixed indigo-to-purple LinearGradient
 *   ["#4338CA", "#7C3AED"] and intentionally does NOT adapt to the device
 *   color scheme. Against the dark background (#0D1520) this vivid purple band
 *   creates strong visual hierarchy for the primary upgrade action — the same
 *   technique used by many premium-tier UIs in dark mode.
 *
 *   Contrast ratios (verified 2026-07-01, WCAG AA minimum 4.5:1 normal text):
 *     • White title on #4338CA  ≈ 9.1 : 1  ✓
 *     • White title on #7C3AED  ≈ 7.2 : 1  ✓
 *     • rgba(255,255,255,0.7) description on #7C3AED ≈ 5.0 : 1  ✓
 *     • Amber icon #FBBF24 on #4338CA ≈ 6.8 : 1  ✓
 *
 *   No opacity or stop adjustments are needed for dark mode; the gradient
 *   renders as-intended against the dark navy background.
 */
const colors = {
  light: {
    text: "#0F172A",
    tint: "#0EA5E9",

    background: "#F0FAFF",
    foreground: "#0F172A",

    card: "#FFFFFF",
    cardForeground: "#0F172A",

    primary: "#0EA5E9",
    primaryForeground: "#FFFFFF",

    secondary: "#E0F4FE",
    secondaryForeground: "#0369A1",

    muted: "#E0F4FE",
    mutedForeground: "#64748B",

    accent: "#F97316",
    accentForeground: "#FFFFFF",

    destructive: "#EF4444",
    destructiveForeground: "#FFFFFF",

    success: "#10B981",
    successForeground: "#FFFFFF",

    pro: "#F59E0B",

    border: "#BAE6FD",
    input: "#BAE6FD",
  },

  dark: {
    text: "#F0FAFF",
    tint: "#38BDF8",

    /* oklch(15-20% 0.01 220) backgrounds as per Ripple brand kit */
    background: "#0D1520",
    foreground: "#F0FAFF",

    card: "#111E2E",
    cardForeground: "#F0FAFF",

    primary: "#38BDF8",
    primaryForeground: "#0F172A",

    secondary: "#162035",
    secondaryForeground: "#7DD3FC",

    muted: "#142030",
    mutedForeground: "#94A3B8",

    accent: "#FB923C",
    accentForeground: "#0F172A",

    destructive: "#EF4444",
    destructiveForeground: "#FFFFFF",

    success: "#10B981",
    successForeground: "#FFFFFF",

    pro: "#FBBF24",

    border: "#1E3048",
    input: "#1E3048",
  },

  radius: 12,
};

export default colors;

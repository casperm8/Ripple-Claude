import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import React from "react";
import {
  ActivityIndicator,
  Alert,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  View,
} from "react-native";

import { useColors } from "@/hooks/useColors";

export const CATEGORY_COLORS: Record<string, string> = {
  shopping: "#F59E0B",
  travel: "#10B981",
  tech: "#6366F1",
  food: "#EF4444",
  entertainment: "#8B5CF6",
  productivity: "#3B82F6",
  finance: "#0EA5E9",
  beauty: "#EC4899",
  health: "#14B8A6",
  other: "#64748B",
};

export function getCategoryColor(cat: string) {
  return CATEGORY_COLORS[cat.toLowerCase()] ?? "#64748B";
}

function fmt(cat: string) {
  return cat.charAt(0).toUpperCase() + cat.slice(1).toLowerCase();
}

function fmtDate(s: string) {
  return new Date(s).toLocaleDateString("en-US", { month: "short", day: "numeric" });
}

export interface CodeItem {
  id: number;
  title: string;
  description: string;
  category: string;
  maxClaims: number;
  claimCount: number;
  isExpired: boolean;
  expiresAt: string | null;
  createdAt: string;
  posterName: string;
  isClaimedByMe: boolean;
  isMine: boolean;
}

interface Props {
  code: CodeItem;
  onClaim?: (id: number) => void;
  onDelete?: (id: number) => void;
  claimLoading?: boolean;
  deleteLoading?: boolean;
  showDelete?: boolean;
  revealedCode?: string;
}

export function CodeCard({ code, onClaim, onDelete, claimLoading, deleteLoading, showDelete, revealedCode }: Props) {
  const colors = useColors();
  const catColor = getCategoryColor(code.category);
  const slotsLeft = code.maxClaims - code.claimCount;
  const isFull = slotsLeft <= 0;
  const unavailable = isFull || code.isExpired;
  const claimed = code.isClaimedByMe;

  const pct = Math.min((code.claimCount / code.maxClaims) * 100, 100);

  const doDelete = () => {
    if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    Alert.alert("Delete Code", "Remove this code from Referral Hub?", [
      { text: "Cancel", style: "cancel" },
      { text: "Delete", style: "destructive", onPress: () => onDelete?.(code.id) },
    ]);
  };

  const doClaim = () => {
    if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    onClaim?.(code.id);
  };

  return (
    <View style={[styles.card, { backgroundColor: colors.card, borderRadius: colors.radius, borderLeftColor: catColor, shadowColor: colors.border }]}>
      {/* Top row */}
      <View style={styles.topRow}>
        <View style={[styles.catPill, { backgroundColor: catColor + "18" }]}>
          <View style={[styles.catDot, { backgroundColor: catColor }]} />
          <Text style={[styles.catLabel, { color: catColor }]} maxFontSizeMultiplier={1.0}>{fmt(code.category)}</Text>
        </View>

        <View style={styles.topRight}>
          {!isFull && !code.isExpired && (
            <View style={[styles.slotPill, { backgroundColor: colors.muted }]}>
              <Text style={[styles.slotText, { color: colors.mutedForeground }]} maxFontSizeMultiplier={1.0}>
                {slotsLeft} left
              </Text>
            </View>
          )}
          {(isFull || code.isExpired) && (
            <View style={[styles.slotPill, { backgroundColor: colors.destructive + "18" }]}>
              <Text style={[styles.slotText, { color: colors.destructive }]} maxFontSizeMultiplier={1.0}>
                {code.isExpired ? "Expired" : "Full"}
              </Text>
            </View>
          )}
          {code.isMine && (
            <View style={[styles.minePill, { backgroundColor: colors.secondary }]}>
              <Text style={[styles.mineText, { color: colors.primary }]} maxFontSizeMultiplier={1.0}>Mine</Text>
            </View>
          )}
        </View>
      </View>

      {/* Title */}
      <Text style={[styles.title, { color: colors.foreground }]} numberOfLines={1} maxFontSizeMultiplier={1.3}>
        {code.title}
      </Text>

      {/* Description */}
      <Text style={[styles.desc, { color: colors.mutedForeground }]} numberOfLines={2} maxFontSizeMultiplier={1.3}>
        {code.description}
      </Text>

      {/* Revealed code */}
      {revealedCode && (
        <View style={[styles.revealBox, { backgroundColor: catColor + "12", borderRadius: colors.radius - 4 }]}>
          <Feather name="tag" size={13} color={catColor} />
          <Text style={[styles.revealCode, { color: catColor }]} maxFontSizeMultiplier={1.3}>{revealedCode}</Text>
        </View>
      )}

      {/* Progress bar */}
      <View style={[styles.progressTrack, { backgroundColor: colors.muted }]}>
        <View
          style={[
            styles.progressFill,
            { width: `${pct}%` as any, backgroundColor: isFull ? colors.destructive : catColor },
          ]}
        />
      </View>

      {/* Footer */}
      <View style={styles.footer}>
        <View style={styles.meta}>
          <View style={[styles.avatarSmall, { backgroundColor: catColor + "22" }]}>
            <Text style={[styles.avatarInitial, { color: catColor }]} maxFontSizeMultiplier={1.0}>
              {code.posterName.charAt(0).toUpperCase()}
            </Text>
          </View>
          <Text style={[styles.metaName, { color: colors.mutedForeground }]} numberOfLines={1} maxFontSizeMultiplier={1.3}>
            {code.posterName}
          </Text>
          <Text style={[styles.metaDot, { color: colors.border }]} maxFontSizeMultiplier={1.0}>·</Text>
          <Text style={[styles.metaDate, { color: colors.mutedForeground }]} maxFontSizeMultiplier={1.3}>
            {fmtDate(code.createdAt)}
          </Text>
        </View>

        {showDelete && onDelete ? (
          <Pressable
            onPress={doDelete}
            disabled={deleteLoading}
            style={({ pressed }) => [styles.deleteBtn, { opacity: pressed ? 0.6 : 1 }]}
          >
            {deleteLoading
              ? <ActivityIndicator size="small" color={colors.destructive} />
              : <Feather name="trash-2" size={16} color={colors.destructive} />}
          </Pressable>
        ) : onClaim && !code.isMine ? (
          <Pressable
            onPress={doClaim}
            disabled={claimed || unavailable || claimLoading}
            style={({ pressed }) => [
              styles.claimBtn,
              {
                borderRadius: 99,
                backgroundColor: claimed ? colors.success + "20" : unavailable ? colors.muted : colors.primary,
                opacity: pressed ? 0.85 : 1,
              },
            ]}
          >
            {claimLoading
              ? <ActivityIndicator size="small" color={claimed ? colors.success : colors.primaryForeground} />
              : (
                <Text style={[
                  styles.claimText,
                  { color: claimed ? colors.success : unavailable ? colors.mutedForeground : colors.primaryForeground },
                ]} maxFontSizeMultiplier={1.0}>
                  {claimed ? "Claimed ✓" : isFull ? "Full" : code.isExpired ? "Expired" : "Get Code"}
                </Text>
              )}
          </Pressable>
        ) : null}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    marginHorizontal: 16,
    marginVertical: 5,
    padding: 15,
    borderLeftWidth: 3,
    gap: 8,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.06,
    shadowRadius: 8,
    elevation: 2,
  },
  topRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  catPill: {
    flexDirection: "row",
    alignItems: "center",
    gap: 5,
    paddingHorizontal: 9,
    paddingVertical: 4,
    borderRadius: 99,
  },
  catDot: { width: 6, height: 6, borderRadius: 3 },
  catLabel: { fontSize: 11, fontFamily: "Inter_600SemiBold", letterSpacing: 0.2 },
  topRight: { flexDirection: "row", gap: 6, alignItems: "center" },
  slotPill: { paddingHorizontal: 8, paddingVertical: 3, borderRadius: 99 },
  slotText: { fontSize: 11, fontFamily: "Inter_500Medium" },
  minePill: { paddingHorizontal: 8, paddingVertical: 3, borderRadius: 99 },
  mineText: { fontSize: 11, fontFamily: "Inter_600SemiBold" },
  title: { fontSize: 16, fontFamily: "Inter_600SemiBold", letterSpacing: -0.2 },
  desc: { fontSize: 13, fontFamily: "Inter_400Regular", lineHeight: 19 },
  revealBox: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    paddingHorizontal: 10,
    paddingVertical: 8,
  },
  revealCode: { fontSize: 14, fontFamily: "Inter_700Bold", letterSpacing: 1 },
  progressTrack: { height: 3, borderRadius: 2, overflow: "hidden" },
  progressFill: { height: 3, borderRadius: 2 },
  footer: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  meta: { flexDirection: "row", alignItems: "center", gap: 5, flex: 1 },
  avatarSmall: { width: 20, height: 20, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  avatarInitial: { fontSize: 10, fontFamily: "Inter_700Bold" },
  metaName: { fontSize: 12, fontFamily: "Inter_400Regular", maxWidth: 80 },
  metaDot: { fontSize: 12 },
  metaDate: { fontSize: 12, fontFamily: "Inter_400Regular" },
  claimBtn: { paddingHorizontal: 14, paddingVertical: 7, minWidth: 80, alignItems: "center" },
  claimText: { fontSize: 13, fontFamily: "Inter_600SemiBold" },
  deleteBtn: { padding: 8 },
});

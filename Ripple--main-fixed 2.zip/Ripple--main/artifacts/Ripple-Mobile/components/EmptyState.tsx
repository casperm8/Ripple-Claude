import { Feather } from "@expo/vector-icons";
import React from "react";
import { StyleSheet, Text, View } from "react-native";

import { useColors } from "@/hooks/useColors";

interface Props {
  icon: keyof typeof Feather.glyphMap;
  title: string;
  description: string;
  accent?: string;
}

export function EmptyState({ icon, title, description, accent }: Props) {
  const colors = useColors();
  const color = accent ?? colors.primary;

  return (
    <View style={styles.wrap}>
      <View style={[styles.ring, { borderColor: color + "30" }]}>
        <View style={[styles.iconBox, { backgroundColor: color + "15" }]}>
          <Feather name={icon} size={26} color={color} />
        </View>
      </View>
      <Text style={[styles.title, { color: colors.foreground }]} maxFontSizeMultiplier={1.4}>{title}</Text>
      <Text style={[styles.desc, { color: colors.mutedForeground }]}>{description}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 40,
    paddingVertical: 72,
    gap: 10,
  },
  ring: {
    width: 80,
    height: 80,
    borderRadius: 40,
    borderWidth: 1.5,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 4,
  },
  iconBox: {
    width: 60,
    height: 60,
    borderRadius: 30,
    alignItems: "center",
    justifyContent: "center",
  },
  title: {
    fontSize: 17,
    fontFamily: "Inter_600SemiBold",
    textAlign: "center",
    letterSpacing: -0.2,
  },
  desc: {
    fontSize: 14,
    fontFamily: "Inter_400Regular",
    textAlign: "center",
    lineHeight: 20,
  },
});

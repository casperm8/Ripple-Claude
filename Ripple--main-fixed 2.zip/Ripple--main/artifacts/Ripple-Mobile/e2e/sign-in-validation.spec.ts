/**
 * Sign-in / Sign-up screen — end-to-end regression tests
 *
 * Validates the auth screen after the migration from @clerk/expo/legacy to the
 * current signals-based API (useSignIn / useSignUp returning
 * { signIn, fetchStatus, errors }, finalize() instead of setActive()).
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * TEST TIERS
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * Tier 1 — Always runs (no credentials needed):
 *   • Screen rendering, mode toggle, password field
 *   • Verify-mode elements absent before signup completes
 *
 * Tier 2 — Runs against live Clerk API (always requires connectivity):
 *   • Failed sign-in with non-existent email → inline error appears
 *     (exercises signIn.create(), extractClerkError(), error box render)
 *   • Switching modes clears the error
 *   • Failed sign-up with invalid email → inline error appears
 *     (exercises signUp.password(), error extraction)
 *
 * Tier 3 — Happy-path: gated on CLERK_TEST_EMAIL + CLERK_TEST_PASSWORD env vars.
 *   When those vars are set the tests MUST pass — failure is a real regression.
 *   Without them the tests are skipped with a clear reason.
 *   • Successful email+password sign-in → main tab screen reachable
 *   • Sign-up triggers the verify screen (email code screen appears)
 *     Note: OTP code entry requires a test-inbox service (e.g. Mailosaur).
 *     Set CLERK_TEST_OTP to make the full verify→finalize path run.
 *
 * Tier 4 — OAuth (Google / Apple): headless Playwright cannot follow a browser
 *   popup to a third-party OAuth provider. These flows are validated by the
 *   UI-rendering tests (buttons present, click handler wired) but the full
 *   round-trip requires a native device or manual QA.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * Environment variables
 * ═══════════════════════════════════════════════════════════════════════════
 *   CLERK_TEST_EMAIL    – email address of a pre-seeded Clerk test account
 *   CLERK_TEST_PASSWORD – password for that account
 *   CLERK_TEST_OTP      – one-time code (only needed for OTP verification path)
 *
 * Run (all tiers including Tier 3):
 *   CLERK_TEST_EMAIL=test@example.com CLERK_TEST_PASSWORD=TestPass1! \
 *   pnpm --filter @workspace/referral-hub-mobile test:e2e -- e2e/sign-in-validation.spec.ts
 *
 * Run (Tier 1 + Tier 2 only):
 *   pnpm --filter @workspace/referral-hub-mobile test:e2e -- e2e/sign-in-validation.spec.ts
 */

import { test, expect, type Page } from "@playwright/test";

/* ── Environment ─────────────────────────────────────────────────────────── */

const TEST_EMAIL = process.env.CLERK_TEST_EMAIL ?? "";
const TEST_PASSWORD = process.env.CLERK_TEST_PASSWORD ?? "";
const TEST_OTP = process.env.CLERK_TEST_OTP ?? "";
const HAS_HAPPY_PATH_CREDS = TEST_EMAIL.length > 0 && TEST_PASSWORD.length > 0;

/* ── Helpers ─────────────────────────────────────────────────────────────── */

async function gotoSignIn(page: Page) {
  await page.goto("/sign-in");
  await page.waitForLoadState("networkidle");
  // "Ripple" (exact) is the brand name in the header gradient — always rendered.
  // exact:true prevents matching "Every referral creates a ripple".
  await expect(page.getByText("Ripple", { exact: true })).toBeVisible({ timeout: 15_000 });
}

async function fillEmailPassword(page: Page, email: string, password: string) {
  await page.getByPlaceholder("you@example.com").fill(email);
  await page.getByPlaceholder("••••••••").fill(password);
}

/**
 * Click a toggle tab (Sign In | Create Account) via DOM traversal to bypass any
 * fixed overlay that might intercept pointer events.
 */
async function clickToggleTab(page: Page, label: string) {
  await page.getByText(label, { exact: true }).first().evaluate((el) => {
    let node: Element | null = el;
    while (node && node !== document.body) {
      if (node.getAttribute("role") === "button") {
        (node as HTMLElement).click();
        return;
      }
      node = node.parentElement;
    }
    (el as HTMLElement).click();
  });
}

/**
 * Click the primary submit button via direct DOM .click() to bypass any
 * fixed overlay that might intercept pointer events.
 */
async function clickPrimaryButton(page: Page, label: string) {
  await page.getByText(label, { exact: true }).last().waitFor({ state: "attached" });
  await page.getByText(label, { exact: true }).last().evaluate((el) => {
    let node: Element | null = el;
    while (node && node !== document.body) {
      if (node.getAttribute("role") === "button") {
        (node as HTMLElement).click();
        return;
      }
      node = node.parentElement;
    }
    (el as HTMLElement).click();
  });
}

/**
 * Wait for the ActivityIndicator (progressbar role) to disappear, then wait
 * for any subsequent re-render to settle.
 */
async function waitForSpinnerGone(page: Page, timeoutMs = 30_000) {
  await expect(page.getByRole("progressbar")).not.toBeVisible({ timeout: timeoutMs });
}

/* ═══════════════════════════════════════════════════════════════════════════
 * TIER 1 — Always runs
 * ═══════════════════════════════════════════════════════════════════════════ */

test.describe("Sign-in screen — rendering", () => {
  test("brand header, mode toggle, OAuth buttons, and email form all render", async ({
    page,
  }) => {
    await gotoSignIn(page);

    // Brand header
    await expect(page.getByText("Ripple", { exact: true })).toBeVisible();
    await expect(page.getByText("Every referral creates a ripple")).toBeVisible();

    // Mode toggle — both tabs present
    await expect(page.getByText("Sign In", { exact: true }).first()).toBeVisible();
    await expect(page.getByText("Create Account", { exact: true }).first()).toBeVisible();

    // OAuth buttons
    await expect(page.getByText("Google", { exact: true })).toBeVisible();
    await expect(page.getByText("Apple", { exact: true })).toBeVisible();

    // Email / password fields
    await expect(page.getByPlaceholder("you@example.com")).toBeVisible();
    await expect(page.getByPlaceholder("••••••••")).toBeVisible();

    // Primary submit button defaults to sign-in mode
    await expect(page.getByText("Sign In with Email")).toBeVisible();
  });
});

test.describe("Sign-in screen — mode toggle", () => {
  test.beforeEach(async ({ page }) => {
    await gotoSignIn(page);
  });

  test("switching to Create Account changes the primary button label", async ({
    page,
  }) => {
    await clickToggleTab(page, "Create Account");
    await expect(page.getByText("Sign In with Email")).not.toBeVisible({ timeout: 5_000 });
    // "Create Account" appears in the toggle AND on the submit button
    const els = page.getByText("Create Account", { exact: true });
    await expect(els.first()).toBeVisible();
  });

  test("switching back to Sign In restores the Sign In with Email button", async ({
    page,
  }) => {
    await clickToggleTab(page, "Create Account");
    await expect(page.getByText("Sign In with Email")).not.toBeVisible({ timeout: 5_000 });
    await clickToggleTab(page, "Sign In");
    await expect(page.getByText("Sign In with Email")).toBeVisible({ timeout: 5_000 });
  });
});

test.describe("Sign-in screen — password field", () => {
  test("password input accepts text and is type=password by default", async ({
    page,
  }) => {
    await gotoSignIn(page);
    const pwInput = page.getByPlaceholder("••••••••");
    await pwInput.fill("mysecretpassword");
    await expect(pwInput).toHaveValue("mysecretpassword");
    await expect(pwInput).toHaveAttribute("type", "password");
  });
});

test.describe("Sign-in screen — verify-mode elements absent before sign-up", () => {
  test.beforeEach(async ({ page }) => {
    await gotoSignIn(page);
  });

  test("OTP code-entry field not shown in sign-in mode", async ({ page }) => {
    await expect(page.getByPlaceholder("6-digit code from email")).not.toBeVisible();
  });

  test("Verify Email button not shown in sign-in mode", async ({ page }) => {
    await expect(page.getByText("Verify Email", { exact: true })).not.toBeVisible();
  });

  test("Check your email sub-header not shown in sign-in mode", async ({ page }) => {
    await expect(page.getByText("Check your email")).not.toBeVisible();
  });

  test("Back to sign up link absent in sign-in mode", async ({ page }) => {
    await expect(page.getByText("Back to sign up")).not.toBeVisible();
  });

  test("OTP code-entry field not shown in sign-up mode", async ({ page }) => {
    await clickToggleTab(page, "Create Account");
    await expect(page.getByPlaceholder("6-digit code from email")).not.toBeVisible();
  });

  test("Back to sign up link absent in sign-up mode", async ({ page }) => {
    await clickToggleTab(page, "Create Account");
    await expect(page.getByText("Back to sign up")).not.toBeVisible();
  });
});

/* ═══════════════════════════════════════════════════════════════════════════
 * TIER 2 — Live Clerk API (error paths)
 * These tests call the real Clerk API and assert on the response.
 * They MUST NOT skip silently — a missing error box is a real failure.
 * ═══════════════════════════════════════════════════════════════════════════ */

test.describe("Sign-in screen — sign-in error path (live Clerk)", () => {
  test.beforeEach(async ({ page }) => {
    await gotoSignIn(page);
  });

  test("submitting with a non-existent email shows an inline Clerk error", async ({
    page,
  }) => {
    await fillEmailPassword(
      page,
      "definitely-does-not-exist-clerk-test@example.invalid",
      "WrongPassword123!",
    );
    await clickPrimaryButton(page, "Sign In with Email");

    // Wait for the API call to complete (spinner disappears)
    await waitForSpinnerGone(page);

    // A Clerk error must appear — the exact wording depends on the Clerk instance locale.
    // We match broadly but exclude the static UI labels "Email" and "or continue with email".
    // If no error appears within the timeout, that IS a failure: it means either
    // signIn.create() wasn't called, or the error was swallowed.
    const errorText = await page
      .locator("text=/couldn't find|invalid|no account|not found|incorrect|failed/i")
      .first()
      .textContent({ timeout: 10_000 });

    expect(
      errorText,
      "signIn.create() must surface a Clerk error for a non-existent account",
    ).toBeTruthy();

    // Confirm the form is still visible (no navigation away)
    await expect(page.getByText("Ripple", { exact: true })).toBeVisible();
  });

  test("switching modes after a sign-in error clears the error message", async ({
    page,
  }) => {
    await fillEmailPassword(page, "nobody@example.invalid", "WrongPassword123!");
    await clickPrimaryButton(page, "Sign In with Email");
    await waitForSpinnerGone(page);

    const errorLocator = page.locator(
      "text=/couldn't find|invalid|no account|not found|incorrect|failed/i",
    );
    // Error must be present first
    await expect(errorLocator.first()).toBeVisible({ timeout: 10_000 });

    // Switching to Create Account calls setError("") — error must clear
    await clickToggleTab(page, "Create Account");
    await expect(errorLocator).not.toBeVisible({ timeout: 5_000 });
  });
});

test.describe("Sign-in screen — sign-up error path (live Clerk)", () => {
  test("submitting sign-up with an invalid email shows an inline Clerk error", async ({
    page,
  }) => {
    await gotoSignIn(page);
    await clickToggleTab(page, "Create Account");
    await expect(page.getByText("Sign In with Email")).not.toBeVisible({ timeout: 3_000 });

    await fillEmailPassword(page, "notvalid@@@.bad", "TestPass123!");
    await clickPrimaryButton(page, "Create Account");

    // Wait for the API call to complete
    await waitForSpinnerGone(page, 30_000);

    // An error must now appear. We look for any non-empty text that appeared in
    // the error box — it will not match the static UI strings because those are
    // multi-word and don't start with "Email" alone.
    // Use first() to avoid strict mode violations if multiple error-like strings exist.
    const errorText = await page
      .locator("text=/invalid|failed|not valid|address|error/i")
      .evaluateAll((els: HTMLElement[]) => {
        // Filter out the known static UI labels
        const excluded = ["email", "or continue with email", "password"];
        return els
          .map((el) => el.textContent?.trim() ?? "")
          .find((t) => !excluded.includes(t.toLowerCase()) && t.length > 0) ?? null;
      });

    expect(
      errorText,
      "signUp.password() must surface a Clerk error for an invalid email address — " +
        "no error appeared, which means the API wasn't called or the error was swallowed.",
    ).toBeTruthy();

    await expect(page.getByText("Ripple", { exact: true })).toBeVisible();
  });
});

/* ═══════════════════════════════════════════════════════════════════════════
 * TIER 3 — Happy-path: gated on CLERK_TEST_EMAIL + CLERK_TEST_PASSWORD
 * When those env vars are set these tests MUST pass.
 * When they are not set the tests are skipped with a clear message.
 * ═══════════════════════════════════════════════════════════════════════════ */

test.describe("Sign-in screen — happy path (requires CLERK_TEST_EMAIL + CLERK_TEST_PASSWORD)", () => {
  test.beforeEach(async ({ page }) => {
    if (!HAS_HAPPY_PATH_CREDS) {
      test.skip(
        true,
        "Set CLERK_TEST_EMAIL and CLERK_TEST_PASSWORD to run happy-path sign-in tests. " +
          "These tests must pass in any environment where those vars are configured.",
      );
    }
    await gotoSignIn(page);
  });

  test("email + password sign-in routes to the main tab screen", async ({ page }) => {
    await fillEmailPassword(page, TEST_EMAIL, TEST_PASSWORD);
    await clickPrimaryButton(page, "Sign In with Email");

    // signIn.create() → signIn.password() → signIn.finalize() → router.replace("/(tabs)")
    // The tabs screen must become visible, confirming finalize() ran and the
    // session was activated.
    await page.waitForURL((url) => url.pathname.startsWith("/(tabs)") || url.pathname === "/", {
      timeout: 20_000,
    });

    // Home screen header or tab bar must be visible — not the sign-in sheet
    await expect(page.getByText("Sign In with Email")).not.toBeVisible({ timeout: 5_000 });
    await expect(page.getByText("Ripple", { exact: true })).toBeVisible();
  });
});

test.describe("Sign-up — verify screen (requires CLERK_TEST_EMAIL + CLERK_TEST_PASSWORD)", () => {
  test.beforeEach(async ({ page }) => {
    if (!HAS_HAPPY_PATH_CREDS) {
      test.skip(
        true,
        "Set CLERK_TEST_EMAIL and CLERK_TEST_PASSWORD to run sign-up happy-path tests.",
      );
    }
    await gotoSignIn(page);
  });

  test("sign-up with a new address shows the OTP code-entry screen", async ({
    page,
  }) => {
    // Use a unique address so the account doesn't already exist.
    // This test is intentionally one-way (creates a new account); tear-down
    // should be handled in the Clerk dashboard for the test tenant.
    const uniqueEmail = `e2e-test+${Date.now()}@example.invalid`;

    await clickToggleTab(page, "Create Account");
    await fillEmailPassword(page, uniqueEmail, TEST_PASSWORD);
    await clickPrimaryButton(page, "Create Account");

    // signUp.password() → signUp.verifications.sendEmailCode() → setMode("verify")
    // The verify screen must appear.
    await expect(
      page.getByPlaceholder("6-digit code from email"),
      "The OTP code-entry field must appear after signUp.verifications.sendEmailCode() succeeds",
    ).toBeVisible({ timeout: 20_000 });

    await expect(page.getByText("Check your email")).toBeVisible();
    await expect(page.getByText("Verify Email", { exact: true })).toBeVisible();
    await expect(page.getByText("Back to sign up")).toBeVisible();
  });

  test("OTP verification routes to the main tab screen (requires CLERK_TEST_OTP)", async ({
    page,
  }) => {
    if (!TEST_OTP) {
      test.skip(
        true,
        "Set CLERK_TEST_OTP to run the full OTP verification path. " +
          "Without it this test is skipped but NOT absent — the code path exists " +
          "and must be verified in environments with a test inbox service.",
      );
    }

    // Sign up with the test account's email to reach the verify screen
    await clickToggleTab(page, "Create Account");
    await fillEmailPassword(page, TEST_EMAIL, TEST_PASSWORD);
    await clickPrimaryButton(page, "Create Account");

    await expect(page.getByPlaceholder("6-digit code from email")).toBeVisible({
      timeout: 20_000,
    });

    // Enter the OTP
    await page.getByPlaceholder("6-digit code from email").fill(TEST_OTP);
    await clickPrimaryButton(page, "Verify Email");

    // signUp.verifications.verifyEmailCode() → signUp.finalize() → router.replace("/(tabs)")
    await page.waitForURL((url) => url.pathname.startsWith("/(tabs)") || url.pathname === "/", {
      timeout: 20_000,
    });

    await expect(page.getByText("Verify Email", { exact: true })).not.toBeVisible({ timeout: 5_000 });
  });
});

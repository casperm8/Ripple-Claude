/**
 * Profile screen — dark-mode gradient visual confirmation
 *
 * Confirms the purple "Upgrade to Pro" LinearGradient card (#4338CA → #7C3AED)
 * renders intentionally against the dark background (#0D1520).
 *
 * Dev-mode bypass:
 *   EXPO_PUBLIC_E2E_TEST=1 skips the Clerk auth gate on the profile screen so
 *   the upgrade card is reachable without a real session. In bypass mode the
 *   user data from the API is unavailable (unauthenticated request), so me===
 *   undefined, isPro===false, and the upgrade card renders unconditionally.
 *
 * Dark mode:
 *   page.emulateMedia({ colorScheme: "dark" }) sets prefers-color-scheme: dark
 *   before navigation, so useColorScheme() returns "dark" and the app applies
 *   the dark token palette (#0D1520 background, #111E2E cards, etc.).
 *
 * Run:
 *   EXPO_PUBLIC_E2E_TEST=1 pnpm --filter @workspace/referral-hub-mobile test:e2e \
 *     --grep "purple upgrade card"
 */

import { test, expect } from "@playwright/test";
import path from "path";
import fs from "fs";

test.describe("Profile screen — purple upgrade card in dark mode", () => {
  test("purple upgrade card gradient looks intentional against the dark background", async ({
    page,
  }) => {
    await page.emulateMedia({ colorScheme: "dark" });

    await page.goto("/profile");
    await page.waitForLoadState("networkidle");

    await expect(
      page.getByText("Upgrade to Pro"),
      '"Upgrade to Pro" card must be visible in bypass mode (not signed in, not pro)',
    ).toBeVisible({ timeout: 15_000 });

    const screenshotDir = path.join(
      __dirname,
      "../../../attached_assets/screenshots",
    );
    fs.mkdirSync(screenshotDir, { recursive: true });

    await page.screenshot({
      path: path.join(screenshotDir, "profile-dark-mode-upgrade-card.png"),
      fullPage: false,
    });

    const card = page.getByText("Upgrade to Pro").locator("..").locator("..");
    await expect(card).toBeVisible();
  });
});

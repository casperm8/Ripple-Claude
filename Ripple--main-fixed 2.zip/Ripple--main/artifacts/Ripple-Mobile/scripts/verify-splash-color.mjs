/**
 * verify-splash-color.mjs
 *
 * Confirms that the splash screen backgroundColor in app.json matches
 * the corner/edge pixels of both icon.png and splash-icon.png.
 *
 * This is the programmatic equivalent of a "does the splash feel like a
 * seamless extension of the icon?" visual check. The corners of the icon
 * image are the pixels that sit directly against the splash background;
 * if they match the configured backgroundColor there will be no colour
 * seam or white flash on a native build.
 *
 * Usage: node scripts/verify-splash-color.mjs
 */

import { readFileSync } from 'fs';
import { inflateSync } from 'zlib';
import { resolve, dirname } from 'path';
import { fileURLToPath } from 'url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const root = resolve(__dirname, '..');

// ── helpers ──────────────────────────────────────────────────────────────────

function paeth(a, b, c) {
  const p = a + b - c;
  const pa = Math.abs(p - a);
  const pb = Math.abs(p - b);
  const pc = Math.abs(p - c);
  return pa <= pb && pa <= pc ? a : pb <= pc ? b : c;
}

/**
 * Decode a PNG file and return a flat RGB(A) pixel buffer plus metadata.
 */
function decodePNG(filepath) {
  const buf = readFileSync(filepath);

  const width = buf.readUInt32BE(16);
  const height = buf.readUInt32BE(20);
  const bitDepth = buf[24];
  const colorType = buf[25]; // 2=RGB, 6=RGBA

  if (bitDepth !== 8) throw new Error(`Unsupported bit depth ${bitDepth} in ${filepath}`);
  if (colorType !== 2 && colorType !== 6) throw new Error(`Unsupported colorType ${colorType} in ${filepath}`);

  const bpp = colorType === 6 ? 4 : 3;

  // Collect IDAT chunks
  const idatChunks = [];
  let offset = 8;
  while (offset < buf.length - 12) {
    const len = buf.readUInt32BE(offset);
    const type = buf.slice(offset + 4, offset + 8).toString('ascii');
    if (type === 'IDAT') idatChunks.push(buf.slice(offset + 8, offset + 8 + len));
    if (type === 'IEND') break;
    offset += 12 + len;
  }

  const raw = inflateSync(Buffer.concat(idatChunks));
  const stride = width * bpp + 1; // 1 filter byte per row
  const pixels = Buffer.alloc(height * width * bpp);

  for (let y = 0; y < height; y++) {
    const filterType = raw[y * stride];
    const rowIn = raw.slice(y * stride + 1, y * stride + 1 + width * bpp);
    const rowOut = pixels.slice(y * width * bpp, (y + 1) * width * bpp);
    const prev = y > 0 ? pixels.slice((y - 1) * width * bpp, y * width * bpp) : Buffer.alloc(width * bpp);

    for (let x = 0; x < width * bpp; x++) {
      const a = x >= bpp ? rowOut[x - bpp] : 0;
      const b = prev[x];
      const c = x >= bpp ? prev[x - bpp] : 0;
      switch (filterType) {
        case 0: rowOut[x] = rowIn[x]; break;
        case 1: rowOut[x] = (rowIn[x] + a) & 0xff; break;
        case 2: rowOut[x] = (rowIn[x] + b) & 0xff; break;
        case 3: rowOut[x] = (rowIn[x] + Math.floor((a + b) / 2)) & 0xff; break;
        case 4: rowOut[x] = (rowIn[x] + paeth(a, b, c)) & 0xff; break;
        default: throw new Error(`Unknown PNG filter type ${filterType} at row ${y}`);
      }
    }
  }

  return { width, height, bpp, pixels };
}

/**
 * Sample a pixel and return a lowercase hex colour string e.g. "#34b9f4".
 */
function samplePixel(decoded, row, col) {
  const { width, bpp, pixels } = decoded;
  const i = (row * width + col) * bpp;
  return '#'
    + pixels[i].toString(16).padStart(2, '0')
    + pixels[i + 1].toString(16).padStart(2, '0')
    + pixels[i + 2].toString(16).padStart(2, '0');
}

/**
 * Parse a hex colour string to [r, g, b] (0–255).
 */
function hexToRgb(hex) {
  const h = hex.replace('#', '');
  return [
    parseInt(h.slice(0, 2), 16),
    parseInt(h.slice(2, 4), 16),
    parseInt(h.slice(4, 6), 16),
  ];
}

/**
 * Euclidean distance in RGB space. Returns 0 for identical colours.
 */
function colorDistance(hexA, hexB) {
  const [r1, g1, b1] = hexToRgb(hexA);
  const [r2, g2, b2] = hexToRgb(hexB);
  return Math.sqrt((r1 - r2) ** 2 + (g1 - g2) ** 2 + (b1 - b2) ** 2);
}

// ── main ─────────────────────────────────────────────────────────────────────

const appJson = JSON.parse(readFileSync(resolve(root, 'app.json'), 'utf8'));

// Check both the legacy splash config and the plugin config
const legacySplashBg = appJson.expo?.splash?.backgroundColor;
const pluginConfig = appJson.expo?.plugins
  ?.flat()
  .find((_, i, arr) => arr[i - 1] === 'expo-splash-screen');
const pluginSplashBg = pluginConfig?.backgroundColor;

console.log('=== Splash Color Verification ===\n');
console.log(`Legacy splash.backgroundColor:          ${legacySplashBg ?? '(not set)'}`);
console.log(`expo-splash-screen plugin backgroundColor: ${pluginSplashBg ?? '(not set)'}`);

if (!legacySplashBg) {
  console.error('\nFAIL: expo.splash.backgroundColor is not set in app.json');
  process.exit(1);
}
if (!pluginSplashBg) {
  console.error('\nFAIL: expo-splash-screen plugin backgroundColor is not set in app.json');
  process.exit(1);
}
if (legacySplashBg.toLowerCase() !== pluginSplashBg.toLowerCase()) {
  console.error(`\nFAIL: backgroundColor mismatch between splash (${legacySplashBg}) and plugin (${pluginSplashBg})`);
  process.exit(1);
}
console.log('✓ Both backgroundColor values match in app.json\n');

const targetBg = legacySplashBg.toLowerCase();
const TOLERANCE = 10; // max Euclidean RGB distance allowed for a "match"

const assets = [
  { name: 'icon.png', path: resolve(root, 'assets/images/icon.png') },
  { name: 'splash-icon.png', path: resolve(root, 'assets/images/splash-icon.png') },
];

let allPassed = true;

for (const { name, path } of assets) {
  const decoded = decodePNG(path);
  const { width, height } = decoded;

  // Sample the four corners — these are the pixels that butt up against the
  // splash background and must match to avoid a colour seam on device.
  const samples = [
    { label: 'top-left corner',     row: 0,          col: 0 },
    { label: 'top-right corner',    row: 0,          col: width - 1 },
    { label: 'bottom-left corner',  row: height - 1, col: 0 },
    { label: 'bottom-right corner', row: height - 1, col: width - 1 },
    // Also check a few pixels in from each corner (rounded-corner fallback area)
    { label: 'top-left +8px',       row: 8,          col: 8 },
    { label: 'top-right +8px',      row: 8,          col: width - 9 },
    { label: 'bottom-left +8px',    row: height - 9, col: 8 },
    { label: 'bottom-right +8px',   row: height - 9, col: width - 9 },
  ];

  console.log(`--- ${name} (${width}×${height}) ---`);

  let assetPassed = true;
  for (const { label, row, col } of samples) {
    const pixel = samplePixel(decoded, row, col);
    const dist = colorDistance(pixel, targetBg);
    const ok = dist <= TOLERANCE;
    if (!ok) assetPassed = false;
    console.log(
      `  ${ok ? '✓' : '✗'} ${label.padEnd(22)} pixel=${pixel}  target=${targetBg}  distance=${dist.toFixed(1)}${ok ? '' : '  ← MISMATCH'}`
    );
  }

  if (assetPassed) {
    console.log(`  → All sampled edge pixels match splash backgroundColor (within tolerance ${TOLERANCE})\n`);
  } else {
    console.log(`  → FAIL: One or more edge pixels do not match splash backgroundColor\n`);
    allPassed = false;
  }
}

if (allPassed) {
  console.log('PASS: Splash backgroundColor matches icon edge pixels on all sampled points.');
  console.log('      On a native build, the splash will feel like a seamless extension of the icon.');
  process.exit(0);
} else {
  console.error('FAIL: Colour mismatch detected. Update splash.backgroundColor in app.json or regenerate the icon assets.');
  process.exit(1);
}

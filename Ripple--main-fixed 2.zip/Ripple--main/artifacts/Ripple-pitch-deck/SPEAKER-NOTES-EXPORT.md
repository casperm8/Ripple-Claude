# Speaker Notes — Export Limitation

All 11 slides in this deck have presenter notes populated in `src/data/slides-manifest.json` under the `speakerNotes` field. These notes are visible in the Replit workspace sidebar when editing slides.

## What does not work

Neither the PDF nor the PPTX export includes speaker notes:

- **PDF export** — uses a Playwright-based renderer that screenshots each slide's visual content. The `speakerNotes` manifest field is never rendered into the DOM (it is only used by the workspace UI), so no note annotations appear in the output file.
- **PPTX export** — produces `notesSlide` XML stubs for all 11 slides, but those stubs are empty. The manifest `speakerNotes` values are not written into the notes pane content.

This is a platform-level limitation of both export pipelines. The exporter renders `/allslides`, which only contains slide visuals — notes are not part of that route.

## Presenter workaround

A companion speaker notes document is generated alongside each export:

```
.local/outputs/Ripple-Rebrand-Pitch-Deck-Speaker-Notes.txt
```

This file lists all slide titles and their full talking points in order, and can be shared alongside the PDF for presenters who need their notes.

To regenerate it after editing notes in the workspace UI, run:

```bash
node -e "
const fs = require('fs');
const slides = JSON.parse(fs.readFileSync('src/data/slides-manifest.json', 'utf8'))
  .sort((a, b) => a.position - b.position);
let out = 'RIPPLE REBRAND PITCH DECK\nSPEAKER NOTES\n' + '='.repeat(60) + '\n\n';
for (const s of slides) {
  out += 'SLIDE ' + s.position + ': ' + s.title.toUpperCase() + '\n';
  out += '-'.repeat(60) + '\n';
  out += (s.speakerNotes || '(no notes)').replace(/\\n/g, '\n') + '\n\n';
}
fs.writeFileSync('../../.local/outputs/Ripple-Rebrand-Pitch-Deck-Speaker-Notes.txt', out);
" 
```

(Run from `artifacts/ripple-pitch-deck/`.)

## Known follow-up work

- Embed notes into PPTX export — the `notesSlide` XML structure already exists in the output; it needs the `speakerNotes` content injected. Tracked as a follow-up task.

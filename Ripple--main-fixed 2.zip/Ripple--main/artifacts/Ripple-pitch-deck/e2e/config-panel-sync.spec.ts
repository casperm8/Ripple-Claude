/**
 * Config panel ↔ Slide 11 sync regression tests
 *
 * The ConfigPanel renders Slide11Closing directly as a live preview and
 * updates it via DeckConfigContext. Any structural change to that slide that
 * breaks context consumption would silently break the preview — these tests
 * catch that regression.
 *
 * Covered:
 *  1. Editing the Contact Email field updates the live preview in real time.
 *  2. Navigating to /slide11 shows the same value that was just saved.
 *
 * Run: pnpm --filter @workspace/ripple-pitch-deck test:e2e
 */

import { test, expect } from "@playwright/test";

const STORAGE_KEY = "ripple-deck-config";
const TEST_EMAIL = `test-${Date.now()}@preview-sync.test`;

test.describe("ConfigPanel ↔ Slide 11 preview sync", () => {
  test.beforeEach(async ({ page }) => {
    await page.goto("/ripple-pitch-deck/config");
    await page.waitForLoadState("networkidle");
    await page.evaluate((key) => localStorage.removeItem(key), STORAGE_KEY);
    await page.reload();
    await page.waitForLoadState("networkidle");
  });

  test.afterEach(async ({ page }) => {
    await page.evaluate((key) => localStorage.removeItem(key), STORAGE_KEY);
  });

  test("editing Contact Email updates the live preview immediately", async ({ page }) => {
    /**
     * The Contact Email input has id="contactEmail". Typing into it calls
     * setConfig() which patches the shared DeckConfigContext state, causing
     * the Slide11Closing rendered inside SlidePreview to re-render with the
     * new value — all without a page navigation.
     */
    const emailInput = page.locator("#contactEmail");
    await expect(emailInput).toBeVisible();

    await emailInput.fill(TEST_EMAIL);

    const preview = page.locator("main");
    await expect(
      preview.getByText(TEST_EMAIL),
      `Expected "${TEST_EMAIL}" to appear in the live preview immediately after typing`,
    ).toBeVisible();
  });

  test("value set in config panel is visible on /slide11", async ({ page }) => {
    /**
     * After typing in the config panel the value is saved to localStorage via
     * DeckConfigContext. Navigating to /slide11 in the same browser context
     * should show the same email because DeckConfigProvider re-hydrates from
     * localStorage on mount.
     */
    const emailInput = page.locator("#contactEmail");
    await expect(emailInput).toBeVisible();

    await emailInput.fill(TEST_EMAIL);

    await page.goto("/ripple-pitch-deck/slide11");
    await page.waitForLoadState("networkidle");

    await expect(
      page.getByText(TEST_EMAIL),
      `Expected "${TEST_EMAIL}" on /slide11 — DeckConfigContext must surface the value saved from the config panel`,
    ).toBeVisible();
  });
});

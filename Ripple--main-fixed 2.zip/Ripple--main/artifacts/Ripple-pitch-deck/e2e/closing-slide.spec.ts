/**
 * Closing slide (Slide 11) regression tests
 *
 * These tests verify that Slide11Closing correctly reads its content from
 * deck-config.ts after the config refactor. A typo in deck-config.ts or a
 * broken import would silently produce a blank or wrong closing slide — these
 * tests catch that before a presentation.
 *
 * Covered:
 *  1. Demo link href matches deckConfig.demoUrl
 *  2. Demo link visible text matches deckConfig.demoLabel
 *  3. Contact email text is visible
 *  4. Social handles text is visible
 *
 * Run: pnpm --filter @workspace/ripple-pitch-deck test:e2e
 */

import { test, expect } from "@playwright/test";
import deckConfig from "../src/data/deck-config";

test.describe("Slide 11 — Closing slide config values", () => {
  test.beforeEach(async ({ page }) => {
    await page.goto("/ripple-pitch-deck/slide11");
    await page.waitForLoadState("networkidle");
  });

  test("demo link href matches deckConfig.demoUrl", async ({ page }) => {
    /**
     * The <a> tag on the closing slide reads its href from config.demoUrl.
     * If the import is broken or the field is renamed the link will be empty
     * or wrong, and this test will catch it.
     */
    const demoLink = page.locator(`a[href="${deckConfig.demoUrl}"]`);
    await expect(
      demoLink,
      `Expected a link with href="${deckConfig.demoUrl}" — check that deck-config.ts demoUrl is correct and imported via DeckConfigContext`,
    ).toBeVisible();
  });

  test("demo link visible text matches deckConfig.demoLabel", async ({ page }) => {
    /**
     * The link text is rendered from config.demoLabel. An empty string or
     * import error would produce an invisible or missing link label.
     */
    const demoLink = page.locator(`a[href="${deckConfig.demoUrl}"]`);
    await expect(
      demoLink,
      `Demo link text should be "${deckConfig.demoLabel}"`,
    ).toHaveText(deckConfig.demoLabel);
  });

  test("contact email is visible", async ({ page }) => {
    /**
     * config.contactEmail is rendered as a plain <p> on the closing slide.
     * This test confirms the value from deck-config.ts reaches the DOM.
     */
    await expect(
      page.getByText(deckConfig.contactEmail),
      `Expected contact email "${deckConfig.contactEmail}" to appear on the slide`,
    ).toBeVisible();
  });

  test("social handles text is visible", async ({ page }) => {
    /**
     * config.socialHandles is rendered as a plain <p> below the contact email.
     * This test confirms the value from deck-config.ts reaches the DOM.
     */
    await expect(
      page.getByText(deckConfig.socialHandles),
      `Expected social handles "${deckConfig.socialHandles}" to appear on the slide`,
    ).toBeVisible();
  });
});

/**
 * Deck-level configuration for the Ripple pitch deck.
 *
 * Non-developers: update the values below to customise the closing slide
 * for a specific audience or deployment. No other files need to change.
 */
const deckConfig = {
  /** URL shown and linked on the closing slide's "Live Demo" section. */
  demoUrl: "https://referralhub.replit.app",

  /** Display label for the demo link (usually the hostname without "https://"). */
  demoLabel: "referralhub.replit.app",

  /** Primary contact email shown on the closing slide. */
  contactEmail: "hello@ripple.app",

  /** Social-handles line shown below the contact email. */
  socialHandles: "@ripple on LinkedIn · X · Instagram",
};

export default deckConfig;

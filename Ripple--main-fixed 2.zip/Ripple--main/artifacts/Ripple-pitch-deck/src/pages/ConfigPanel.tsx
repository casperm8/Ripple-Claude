import { useEffect, useRef, useState } from "react";
import { useLocation } from "wouter";
import { useDeckConfig } from "../context/DeckConfigContext";
import type { DeckConfig } from "../context/DeckConfigContext";
import defaultConfig from "../data/deck-config";
import Slide11Closing from "./slides/Slide11Closing";

const SLIDE_W = 1920;
const SLIDE_H = 1080;

function SlidePreview() {
  const containerRef = useRef<HTMLDivElement>(null);
  const [scale, setScale] = useState(1);

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const obs = new ResizeObserver(([entry]) => {
      setScale(entry.contentRect.width / SLIDE_W);
    });
    obs.observe(el);
    setScale(el.clientWidth / SLIDE_W);
    return () => obs.disconnect();
  }, []);

  return (
    <div
      ref={containerRef}
      className="rounded-xl overflow-hidden shadow-2xl ring-1 ring-white/10"
      style={{ width: "min(100%, 960px)", aspectRatio: "16 / 9", position: "relative" }}
    >
      <div
        style={{
          width: SLIDE_W,
          height: SLIDE_H,
          transformOrigin: "top left",
          transform: `scale(${scale})`,
          position: "absolute",
          top: 0,
          left: 0,
          pointerEvents: "none",
        }}
      >
        <Slide11Closing />
      </div>
    </div>
  );
}

export default function ConfigPanel() {
  const [, navigate] = useLocation();
  const { config, setConfig, resetConfig } = useDeckConfig();

  const [draft, setDraft] = useState<DeckConfig>({ ...config });

  const handleChange = (field: keyof DeckConfig) => (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setDraft((prev) => ({ ...prev, [field]: value }));
    setConfig({ [field]: value });
  };

  const handleReset = () => {
    resetConfig();
    setDraft({ ...defaultConfig });
  };

  const fields: { key: keyof DeckConfig; label: string; placeholder: string }[] = [
    { key: "demoUrl", label: "Demo URL", placeholder: "https://referralhub.replit.app" },
    { key: "demoLabel", label: "Demo Label", placeholder: "referralhub.replit.app" },
    { key: "contactEmail", label: "Contact Email", placeholder: "hello@ripple.app" },
    { key: "socialHandles", label: "Social Handles", placeholder: "@ripple on LinkedIn · X · Instagram" },
  ];

  return (
    <div className="min-h-screen bg-slate-950 text-white flex flex-col">
      {/* Header */}
      <header className="flex items-center justify-between px-8 py-4 border-b border-white/10 shrink-0">
        <div className="flex items-center gap-3">
          <svg width="28" height="28" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
            <circle cx="32" cy="32" r="8" fill="white" />
            <circle cx="32" cy="32" r="18" stroke="white" strokeOpacity="0.7" strokeWidth="3" fill="none" />
            <circle cx="32" cy="32" r="28" stroke="white" strokeOpacity="0.4" strokeWidth="2.5" fill="none" />
          </svg>
          <span className="font-bold text-lg tracking-tight">Ripple · Closing Slide Settings</span>
        </div>
        <button
          onClick={() => navigate("/slide11")}
          className="flex items-center gap-2 px-4 py-2 rounded-lg bg-sky-500 hover:bg-sky-400 transition-colors text-sm font-semibold cursor-pointer"
        >
          <svg width="14" height="14" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
            <path d="M6.3 2.841A1.5 1.5 0 004 4.11v11.78a1.5 1.5 0 002.3 1.269l9.344-5.89a1.5 1.5 0 000-2.538L6.3 2.84z" />
          </svg>
          Present deck
        </button>
      </header>

      {/* Body */}
      <div className="flex flex-1 overflow-hidden">
        {/* Form panel */}
        <aside className="w-80 shrink-0 border-r border-white/10 p-8 flex flex-col gap-6 overflow-y-auto">
          <div>
            <h2 className="text-xs font-semibold uppercase tracking-widest text-white/40 mb-5">
              Closing slide content
            </h2>
            <div className="flex flex-col gap-5">
              {fields.map(({ key, label, placeholder }) => (
                <div key={key} className="flex flex-col gap-1.5">
                  <label className="text-sm font-medium text-white/70" htmlFor={key}>
                    {label}
                  </label>
                  <input
                    id={key}
                    type="text"
                    value={draft[key]}
                    placeholder={placeholder}
                    onChange={handleChange(key)}
                    className="w-full px-3 py-2 rounded-md bg-white/5 border border-white/10 text-white placeholder-white/25 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-transparent transition"
                  />
                </div>
              ))}
            </div>
          </div>

          <div className="mt-auto flex flex-col gap-3">
            <button
              onClick={handleReset}
              className="w-full px-3 py-2 rounded-md bg-white/5 hover:bg-white/10 border border-white/10 text-white/50 hover:text-white/70 text-sm font-medium transition-colors cursor-pointer"
            >
              Reset to defaults
            </button>
            <p className="text-xs text-white/30 leading-relaxed">
              Settings are saved to your browser and survive page refreshes.
            </p>
          </div>
        </aside>

        {/* Live preview */}
        <main className="flex-1 flex flex-col items-center justify-center bg-slate-900 p-8 gap-4">
          <p className="text-xs font-semibold uppercase tracking-widest text-white/30 shrink-0">
            Live preview — Closing slide
          </p>
          <SlidePreview />
        </main>
      </div>
    </div>
  );
}

export default function Slide10Roadmap() {
  return (
    <div className="relative w-screen h-screen overflow-hidden" style={{ background: "linear-gradient(160deg, #0C4A6E 0%, #0EA5E9 100%)" }}>
      {/* Ripple circles — right side decoration */}
      <div className="absolute" style={{ right: "-8vw", top: "50%", transform: "translateY(-50%)", opacity: 0.15 }}>
        <svg width="60vw" height="60vw" viewBox="0 0 600 600" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
          <circle cx="300" cy="300" r="60" fill="white" />
          <circle cx="300" cy="300" r="140" stroke="white" strokeWidth="2.5" fill="none" />
          <circle cx="300" cy="300" r="220" stroke="white" strokeWidth="2" fill="none" />
          <circle cx="300" cy="300" r="300" stroke="white" strokeWidth="1.5" fill="none" />
          <circle cx="300" cy="300" r="380" stroke="white" strokeWidth="1" fill="none" />
          <circle cx="300" cy="300" r="460" stroke="white" strokeWidth="0.8" fill="none" />
        </svg>
      </div>

      {/* Orange top bar */}
      <div className="absolute top-0 left-0 right-0" style={{ height: "0.8vh", background: "#F97316" }} />

      <div className="relative z-10 flex h-full" style={{ paddingTop: "7vh", paddingBottom: "7vh", paddingLeft: "8vw", paddingRight: "45vw" }}>
        <div className="flex flex-col justify-between h-full w-full">
          <div>
            <p className="font-body font-medium uppercase tracking-widest text-white/50 mb-[1vh]" style={{ fontSize: "1.4vw" }}>What's Ahead</p>
            <h2 className="font-display font-extrabold text-white tracking-tight leading-none mb-[3vh]" style={{ fontSize: "5.5vw", textWrap: "balance" }}>
              The road from here.
            </h2>
            <div className="w-[4vw] h-[0.5vh] mb-[4vh]" style={{ background: "#F97316" }} />
          </div>

          <div className="flex flex-col" style={{ gap: "0" }}>
            {/* Phase 1 */}
            <div className="flex" style={{ gap: "2.5vw" }}>
              <div className="flex flex-col items-center" style={{ width: "2vw", flexShrink: 0 }}>
                <div className="rounded-full" style={{ width: "1.2vw", height: "1.2vw", background: "#F97316", flexShrink: 0 }} />
                <div style={{ width: "2px", flex: 1, background: "rgba(255,255,255,0.2)", marginTop: "0.5vh" }} />
              </div>
              <div style={{ paddingBottom: "3vh" }}>
                <p className="font-body font-medium text-white/50 mb-[0.3vh]" style={{ fontSize: "1.3vw" }}>Now</p>
                <p className="font-display font-bold text-white mb-[0.5vh]" style={{ fontSize: "2.3vw" }}>Brand rollout across all surfaces</p>
                <p className="font-body text-white/60" style={{ fontSize: "1.8vw" }}>App, web, social, onboarding — Ripple everywhere</p>
              </div>
            </div>

            {/* Phase 2 */}
            <div className="flex" style={{ gap: "2.5vw" }}>
              <div className="flex flex-col items-center" style={{ width: "2vw", flexShrink: 0 }}>
                <div className="rounded-full" style={{ width: "1.2vw", height: "1.2vw", background: "rgba(255,255,255,0.5)", flexShrink: 0 }} />
                <div style={{ width: "2px", flex: 1, background: "rgba(255,255,255,0.2)", marginTop: "0.5vh" }} />
              </div>
              <div style={{ paddingBottom: "3vh" }}>
                <p className="font-body font-medium text-white/50 mb-[0.3vh]" style={{ fontSize: "1.3vw" }}>Q3 2026</p>
                <p className="font-display font-bold text-white mb-[0.5vh]" style={{ fontSize: "2.3vw" }}>Partner co-branding kit</p>
                <p className="font-body text-white/60" style={{ fontSize: "1.8vw" }}>Templates and assets for brands listing on Ripple</p>
              </div>
            </div>

            {/* Phase 3 */}
            <div className="flex" style={{ gap: "2.5vw" }}>
              <div className="flex flex-col items-center" style={{ width: "2vw", flexShrink: 0 }}>
                <div className="rounded-full" style={{ width: "1.2vw", height: "1.2vw", background: "rgba(255,255,255,0.5)", flexShrink: 0 }} />
                <div style={{ width: "2px", flex: 1, background: "transparent", marginTop: "0.5vh" }} />
              </div>
              <div>
                <p className="font-body font-medium text-white/50 mb-[0.3vh]" style={{ fontSize: "1.3vw" }}>Q4 2026</p>
                <p className="font-display font-bold text-white mb-[0.5vh]" style={{ fontSize: "2.3vw" }}>Community creator program</p>
                <p className="font-body text-white/60" style={{ fontSize: "1.8vw" }}>Top sharers get branded presence and early deals</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom logo lockup */}
      <div className="absolute bottom-0 left-0 right-0 flex items-center justify-between" style={{ padding: "0 8vw", paddingBottom: "3vh" }}>
        <div className="flex items-center" style={{ gap: "1.2vw" }}>
          <svg width="2vw" height="2vw" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
            <circle cx="16" cy="16" r="4" fill="white" />
            <circle cx="16" cy="16" r="9" stroke="white" strokeOpacity="0.7" strokeWidth="2" fill="none" />
            <circle cx="16" cy="16" r="14" stroke="white" strokeOpacity="0.3" strokeWidth="1.5" fill="none" />
          </svg>
          <span className="font-display font-bold text-white" style={{ fontSize: "2vw" }}>Ripple</span>
        </div>
        <span className="font-body text-white/40" style={{ fontSize: "1.4vw" }}>Find codes. Share codes. Earn together.</span>
      </div>
    </div>
  );
}

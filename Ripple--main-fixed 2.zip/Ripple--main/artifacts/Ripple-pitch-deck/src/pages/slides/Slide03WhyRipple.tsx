export default function Slide03WhyRipple() {
  return (
    <div className="relative w-screen h-screen overflow-hidden" style={{ background: "#0C4A6E" }}>
      {/* Ripple circles — centered hero motif */}
      <div className="absolute inset-0 flex items-center justify-center" aria-hidden="true">
        <svg width="80vw" height="80vw" viewBox="0 0 800 800" fill="none" xmlns="http://www.w3.org/2000/svg" style={{ opacity: 0.12 }}>
          <circle cx="400" cy="400" r="60" fill="#0EA5E9" />
          <circle cx="400" cy="400" r="140" stroke="#0EA5E9" strokeWidth="3" fill="none" />
          <circle cx="400" cy="400" r="220" stroke="#0EA5E9" strokeWidth="2.5" fill="none" />
          <circle cx="400" cy="400" r="300" stroke="#0EA5E9" strokeWidth="2" fill="none" />
          <circle cx="400" cy="400" r="380" stroke="#0EA5E9" strokeWidth="1.5" fill="none" />
          <circle cx="400" cy="400" r="460" stroke="#0EA5E9" strokeWidth="1" fill="none" />
        </svg>
      </div>

      {/* Orange top bar */}
      <div className="absolute top-0 left-0 right-0" style={{ height: "0.8vh", background: "#F97316" }} />

      <div className="relative z-10 flex flex-col items-center justify-center h-full text-center" style={{ padding: "8vh 10vw" }}>
        <p className="font-body font-medium uppercase tracking-widest text-white/50 mb-[2.5vh]" style={{ fontSize: "1.4vw" }}>Naming Rationale</p>

        <h2 className="font-display font-extrabold text-white tracking-tight leading-none mb-[3vh]" style={{ fontSize: "6.5vw", textWrap: "balance" }}>
          Why <span style={{ color: "#38BDF8" }}>Ripple</span>?
        </h2>

        <div className="w-[4vw] h-[0.5vh] mx-auto mb-[5vh]" style={{ background: "#F97316" }} />

        <div className="flex" style={{ gap: "4vw", maxWidth: "80vw" }}>
          <div className="flex flex-col items-center text-center" style={{ flex: 1 }}>
            <div className="rounded-full flex items-center justify-center mb-[2vh]" style={{ width: "5vw", height: "5vw", background: "rgba(14,165,233,0.2)", border: "2px solid rgba(14,165,233,0.4)" }}>
              <svg width="2.5vw" height="2.5vw" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
                <circle cx="20" cy="20" r="6" fill="#38BDF8" />
                <circle cx="20" cy="20" r="13" stroke="#38BDF8" strokeOpacity="0.6" strokeWidth="2" fill="none" />
                <circle cx="20" cy="20" r="20" stroke="#38BDF8" strokeOpacity="0.3" strokeWidth="1.5" fill="none" />
              </svg>
            </div>
            <p className="font-display font-bold text-white mb-[1vh]" style={{ fontSize: "2.2vw" }}>One share spreads</p>
            <p className="font-body text-white/60 leading-relaxed" style={{ fontSize: "1.9vw" }}>A single referral reaches far beyond the first person — like ripples from a stone</p>
          </div>

          <div className="flex flex-col items-center text-center" style={{ flex: 1 }}>
            <div className="rounded-full flex items-center justify-center mb-[2vh]" style={{ width: "5vw", height: "5vw", background: "rgba(14,165,233,0.2)", border: "2px solid rgba(14,165,233,0.4)" }}>
              <svg width="2.5vw" height="2.5vw" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M20 8 L32 20 L20 32 L8 20 Z" stroke="#38BDF8" strokeWidth="2" fill="none" />
                <circle cx="20" cy="20" r="4" fill="#38BDF8" />
                <path d="M20 8 L20 4M32 20 L36 20M20 32 L20 36M8 20 L4 20" stroke="#38BDF8" strokeOpacity="0.5" strokeWidth="2" />
              </svg>
            </div>
            <p className="font-display font-bold text-white mb-[1vh]" style={{ fontSize: "2.2vw" }}>Community at the core</p>
            <p className="font-body text-white/60 leading-relaxed" style={{ fontSize: "1.9vw" }}>Ripples need water. Our product lives because people share it with each other</p>
          </div>

          <div className="flex flex-col items-center text-center" style={{ flex: 1 }}>
            <div className="rounded-full flex items-center justify-center mb-[2vh]" style={{ width: "5vw", height: "5vw", background: "rgba(14,165,233,0.2)", border: "2px solid rgba(14,165,233,0.4)" }}>
              <svg width="2.5vw" height="2.5vw" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M8 32 L20 12 L32 32" stroke="#38BDF8" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" fill="none" />
                <path d="M12 26 L20 14 L28 26" stroke="#38BDF8" strokeOpacity="0.5" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" fill="none" />
              </svg>
            </div>
            <p className="font-display font-bold text-white mb-[1vh]" style={{ fontSize: "2.2vw" }}>Short, ownable, global</p>
            <p className="font-body text-white/60 leading-relaxed" style={{ fontSize: "1.9vw" }}>Six letters. Instantly understood across languages and cultures</p>
          </div>
        </div>
      </div>

      {/* Bottom label */}
      <div className="absolute bottom-0 left-0 right-0 flex items-center justify-between" style={{ padding: "0 8vw", paddingBottom: "3vh" }}>
        <span className="font-body text-white/30" style={{ fontSize: "1.4vw" }}>Referral Hub → Ripple</span>
        <span className="font-body text-white/30" style={{ fontSize: "1.4vw" }}>2026</span>
      </div>
    </div>
  );
}

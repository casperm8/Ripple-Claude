export default function Slide06LogoConcepts() {
  return (
    <div className="relative w-screen h-screen overflow-hidden bg-bg">
      {/* Top blue bar */}
      <div className="absolute top-0 left-0 right-0" style={{ height: "0.8vh", background: "#0EA5E9" }} />

      <div className="relative z-10 flex flex-col h-full" style={{ paddingTop: "7vh", paddingBottom: "6vh", paddingLeft: "8vw", paddingRight: "8vw" }}>
        <p className="font-body font-medium uppercase tracking-widest text-accent mb-[1vh]" style={{ fontSize: "1.4vw" }}>Logo Concepts</p>
        <h2 className="font-display font-extrabold text-text tracking-tight leading-none mb-[4vh]" style={{ fontSize: "4.5vw" }}>
          The mark in four forms.
        </h2>

        <div className="flex flex-1" style={{ gap: "3vw" }}>
          {/* Wordmark */}
          <div className="flex flex-col" style={{ flex: 1 }}>
            <div className="rounded-xl flex-1 flex flex-col items-center justify-center" style={{ background: "white", border: "1px solid #BAE6FD", minHeight: "24vh" }}>
              <div className="flex items-center" style={{ gap: "1.2vw" }}>
                <svg width="3.5vw" height="3.5vw" viewBox="0 0 56 56" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <circle cx="28" cy="28" r="7" fill="#0EA5E9" />
                  <circle cx="28" cy="28" r="16" stroke="#0EA5E9" strokeOpacity="0.7" strokeWidth="2.5" fill="none" />
                  <circle cx="28" cy="28" r="25" stroke="#0EA5E9" strokeOpacity="0.35" strokeWidth="2" fill="none" />
                </svg>
                <span className="font-display font-extrabold text-text" style={{ fontSize: "3.5vw", letterSpacing: "-0.02em" }}>Ripple</span>
              </div>
            </div>
            <p className="font-display font-bold text-text mt-[1.5vh] text-center" style={{ fontSize: "1.8vw" }}>Wordmark</p>
            <p className="font-body text-muted text-center" style={{ fontSize: "1.5vw" }}>Primary brand expression</p>
          </div>

          {/* Icon only */}
          <div className="flex flex-col" style={{ flex: 1 }}>
            <div className="rounded-xl flex-1 flex flex-col items-center justify-center" style={{ background: "white", border: "1px solid #BAE6FD", minHeight: "24vh" }}>
              <svg width="6vw" height="6vw" viewBox="0 0 80 80" fill="none" xmlns="http://www.w3.org/2000/svg">
                <circle cx="40" cy="40" r="10" fill="#0EA5E9" />
                <circle cx="40" cy="40" r="22" stroke="#0EA5E9" strokeOpacity="0.7" strokeWidth="3" fill="none" />
                <circle cx="40" cy="40" r="34" stroke="#0EA5E9" strokeOpacity="0.4" strokeWidth="2.5" fill="none" />
                <circle cx="40" cy="40" r="46" stroke="#0EA5E9" strokeOpacity="0.18" strokeWidth="2" fill="none" />
              </svg>
            </div>
            <p className="font-display font-bold text-text mt-[1.5vh] text-center" style={{ fontSize: "1.8vw" }}>Icon Mark</p>
            <p className="font-body text-muted text-center" style={{ fontSize: "1.5vw" }}>Social, favicon, solo use</p>
          </div>

          {/* App icon */}
          <div className="flex flex-col" style={{ flex: 1 }}>
            <div className="rounded-xl flex-1 flex flex-col items-center justify-center" style={{ background: "white", border: "1px solid #BAE6FD", minHeight: "24vh" }}>
              <div className="rounded-2xl flex items-center justify-center" style={{ width: "7vw", height: "7vw", background: "linear-gradient(135deg, #38BDF8, #0284C7)" }}>
                <svg width="4.5vw" height="4.5vw" viewBox="0 0 60 60" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <circle cx="30" cy="30" r="8" fill="white" />
                  <circle cx="30" cy="30" r="18" stroke="white" strokeOpacity="0.7" strokeWidth="2.5" fill="none" />
                  <circle cx="30" cy="30" r="28" stroke="white" strokeOpacity="0.35" strokeWidth="2" fill="none" />
                </svg>
              </div>
            </div>
            <p className="font-display font-bold text-text mt-[1.5vh] text-center" style={{ fontSize: "1.8vw" }}>App Icon</p>
            <p className="font-body text-muted text-center" style={{ fontSize: "1.5vw" }}>iOS, Android stores</p>
          </div>

          {/* Dark / inverted */}
          <div className="flex flex-col" style={{ flex: 1 }}>
            <div className="rounded-xl flex-1 flex flex-col items-center justify-center" style={{ background: "#0C4A6E", minHeight: "24vh" }}>
              <div className="flex items-center" style={{ gap: "1.2vw" }}>
                <svg width="3.5vw" height="3.5vw" viewBox="0 0 56 56" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <circle cx="28" cy="28" r="7" fill="white" />
                  <circle cx="28" cy="28" r="16" stroke="white" strokeOpacity="0.7" strokeWidth="2.5" fill="none" />
                  <circle cx="28" cy="28" r="25" stroke="white" strokeOpacity="0.35" strokeWidth="2" fill="none" />
                </svg>
                <span className="font-display font-extrabold text-white" style={{ fontSize: "3.5vw", letterSpacing: "-0.02em" }}>Ripple</span>
              </div>
            </div>
            <p className="font-display font-bold text-text mt-[1.5vh] text-center" style={{ fontSize: "1.8vw" }}>Dark / Reversed</p>
            <p className="font-body text-muted text-center" style={{ fontSize: "1.5vw" }}>Dark surfaces, overlays</p>
          </div>
        </div>
      </div>
    </div>
  );
}

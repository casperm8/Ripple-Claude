export default function Slide07BrandInAction() {
  return (
    <div className="relative w-screen h-screen overflow-hidden bg-bg">
      {/* Orange top bar */}
      <div className="absolute top-0 left-0 right-0" style={{ height: "0.8vh", background: "#F97316" }} />

      {/* Ripple watermark bottom-left */}
      <div className="absolute" style={{ left: "-5vw", bottom: "-5vh", opacity: 0.05 }}>
        <svg width="40vw" height="40vw" viewBox="0 0 400 400" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
          <circle cx="200" cy="200" r="50" fill="#0EA5E9" />
          <circle cx="200" cy="200" r="110" stroke="#0EA5E9" strokeWidth="2.5" fill="none" />
          <circle cx="200" cy="200" r="170" stroke="#0EA5E9" strokeWidth="2" fill="none" />
          <circle cx="200" cy="200" r="230" stroke="#0EA5E9" strokeWidth="1.5" fill="none" />
          <circle cx="200" cy="200" r="290" stroke="#0EA5E9" strokeWidth="1" fill="none" />
        </svg>
      </div>

      <div className="relative z-10 flex h-full" style={{ paddingTop: "7vh", paddingBottom: "6vh", paddingLeft: "8vw", paddingRight: "8vw" }}>
        {/* Left: heading */}
        <div className="flex flex-col justify-between" style={{ width: "30%", paddingRight: "4vw" }}>
          <div>
            <p className="font-body font-medium uppercase tracking-widest text-accent mb-[1vh]" style={{ fontSize: "1.4vw" }}>Brand in Action</p>
            <h2 className="font-display font-extrabold text-text tracking-tight leading-none mb-[2.5vh]" style={{ fontSize: "4vw", textWrap: "balance" }}>
              Ripple across every surface.
            </h2>
            <div className="w-[4vw] h-[0.5vh] mb-[2.5vh]" style={{ background: "#0EA5E9" }} />
            <p className="font-body text-muted leading-relaxed" style={{ fontSize: "1.9vw" }}>
              The brand shows up consistently from mobile feed to share card to app store listing.
            </p>
          </div>

          {/* Key stats */}
          <div className="flex flex-col" style={{ gap: "2vh" }}>
            <div>
              <p className="font-display font-extrabold text-primary" style={{ fontSize: "4.5vw" }}>3</p>
              <p className="font-body text-muted" style={{ fontSize: "1.7vw" }}>Primary touch points</p>
            </div>
            <div style={{ height: "1px", background: "#BAE6FD" }} />
            <div>
              <p className="font-display font-extrabold" style={{ fontSize: "4.5vw", color: "#F97316" }}>1</p>
              <p className="font-body text-muted" style={{ fontSize: "1.7vw" }}>Consistent brand mark</p>
            </div>
          </div>
        </div>

        {/* Right: mock UI previews */}
        <div className="flex flex-1" style={{ gap: "2.5vw" }}>
          {/* Mobile feed mockup */}
          <div className="flex-1 flex flex-col" style={{ gap: "1.5vh" }}>
            <div className="rounded-xl flex-1 overflow-hidden" style={{ background: "#0C4A6E", padding: "2.5vh 2vw" }}>
              <div className="flex items-center" style={{ gap: "1vw", marginBottom: "2vh" }}>
                <svg width="2vw" height="2vw" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <circle cx="16" cy="16" r="4" fill="white" />
                  <circle cx="16" cy="16" r="9" stroke="white" strokeOpacity="0.7" strokeWidth="2" fill="none" />
                  <circle cx="16" cy="16" r="14" stroke="white" strokeOpacity="0.3" strokeWidth="1.5" fill="none" />
                </svg>
                <span className="font-display font-bold text-white" style={{ fontSize: "1.6vw" }}>Ripple</span>
              </div>
              <div className="rounded-lg p-[1.5vh_1.5vw] mb-[1.5vh]" style={{ background: "rgba(255,255,255,0.08)" }}>
                <p className="font-body font-medium text-white/90" style={{ fontSize: "1.5vw" }}>PRIME-WX7G</p>
                <p className="font-body text-white/50" style={{ fontSize: "1.3vw" }}>Amazon Prime · 30 day trial</p>
                <div className="flex items-center mt-[1vh]" style={{ gap: "1vw" }}>
                  <span className="rounded-full px-[0.8vw] py-[0.3vh] font-body font-medium text-white" style={{ fontSize: "1.2vw", background: "#F97316" }}>Hot</span>
                  <span className="font-body text-white/50" style={{ fontSize: "1.2vw" }}>1.2k shares</span>
                </div>
              </div>
              <div className="rounded-lg p-[1.5vh_1.5vw]" style={{ background: "rgba(255,255,255,0.08)" }}>
                <p className="font-body font-medium text-white/90" style={{ fontSize: "1.5vw" }}>SPOTIFY3MO</p>
                <p className="font-body text-white/50" style={{ fontSize: "1.3vw" }}>Spotify · 3 free months</p>
                <span className="font-body text-white/50" style={{ fontSize: "1.2vw" }}>843 shares</span>
              </div>
            </div>
            <p className="font-body text-muted text-center" style={{ fontSize: "1.5vw" }}>Mobile feed</p>
          </div>

          {/* Share card mockup */}
          <div className="flex-1 flex flex-col" style={{ gap: "1.5vh" }}>
            <div className="rounded-xl flex-1 overflow-hidden flex items-center justify-center" style={{ background: "white", border: "1px solid #BAE6FD" }}>
              <div className="rounded-2xl p-[2.5vh_3vw] text-center" style={{ background: "linear-gradient(135deg, #F0FAFF, #E0F2FE)", border: "1px solid #BAE6FD", maxWidth: "80%" }}>
                <div className="flex items-center justify-center mb-[1.5vh]" style={{ gap: "0.8vw" }}>
                  <svg width="1.8vw" height="1.8vw" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="16" cy="16" r="4" fill="#0EA5E9" />
                    <circle cx="16" cy="16" r="9" stroke="#0EA5E9" strokeOpacity="0.7" strokeWidth="2" fill="none" />
                    <circle cx="16" cy="16" r="14" stroke="#0EA5E9" strokeOpacity="0.3" strokeWidth="1.5" fill="none" />
                  </svg>
                  <span className="font-display font-extrabold text-primary" style={{ fontSize: "1.8vw" }}>Ripple</span>
                </div>
                <p className="font-display font-extrabold text-text mb-[0.5vh]" style={{ fontSize: "2.2vw" }}>Found a deal for you</p>
                <p className="font-body text-muted" style={{ fontSize: "1.4vw" }}>Use code NETFLIX-FREE</p>
                <div className="rounded-lg mt-[1.5vh] py-[1vh]" style={{ background: "#0EA5E9" }}>
                  <p className="font-body font-medium text-white text-center" style={{ fontSize: "1.4vw" }}>Claim on Ripple</p>
                </div>
              </div>
            </div>
            <p className="font-body text-muted text-center" style={{ fontSize: "1.5vw" }}>Share card</p>
          </div>

          {/* App store listing mockup */}
          <div className="flex-1 flex flex-col" style={{ gap: "1.5vh" }}>
            <div className="rounded-xl flex-1 overflow-hidden flex flex-col" style={{ background: "white", border: "1px solid #BAE6FD", padding: "2.5vh 2vw" }}>
              <div className="flex items-center" style={{ gap: "1.5vw", marginBottom: "2vh" }}>
                <div className="rounded-xl flex items-center justify-center" style={{ width: "4vw", height: "4vw", background: "linear-gradient(135deg, #38BDF8, #0284C7)", flexShrink: 0 }}>
                  <svg width="2.5vw" height="2.5vw" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="20" cy="20" r="5" fill="white" />
                    <circle cx="20" cy="20" r="12" stroke="white" strokeOpacity="0.7" strokeWidth="2" fill="none" />
                    <circle cx="20" cy="20" r="18" stroke="white" strokeOpacity="0.35" strokeWidth="1.5" fill="none" />
                  </svg>
                </div>
                <div>
                  <p className="font-display font-bold text-text" style={{ fontSize: "1.8vw" }}>Ripple</p>
                  <p className="font-body text-muted" style={{ fontSize: "1.3vw" }}>Find codes. Share codes.</p>
                </div>
              </div>
              <div className="flex" style={{ gap: "0.8vw", marginBottom: "1.5vh" }}>
                <div className="rounded-lg flex-1 flex flex-col items-center py-[1vh]" style={{ background: "#F0FAFF" }}>
                  <p className="font-display font-bold text-primary" style={{ fontSize: "1.8vw" }}>4.8</p>
                  <p className="font-body text-muted" style={{ fontSize: "1.1vw" }}>Rating</p>
                </div>
                <div className="rounded-lg flex-1 flex flex-col items-center py-[1vh]" style={{ background: "#F0FAFF" }}>
                  <p className="font-display font-bold text-primary" style={{ fontSize: "1.8vw" }}>Free</p>
                  <p className="font-body text-muted" style={{ fontSize: "1.1vw" }}>Price</p>
                </div>
              </div>
              <p className="font-body text-muted leading-snug" style={{ fontSize: "1.4vw" }}>Find referral codes, share rewards, earn together with your community.</p>
            </div>
            <p className="font-body text-muted text-center" style={{ fontSize: "1.5vw" }}>App store listing</p>
          </div>
        </div>
      </div>
    </div>
  );
}

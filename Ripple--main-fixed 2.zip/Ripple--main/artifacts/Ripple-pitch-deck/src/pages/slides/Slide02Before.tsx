export default function Slide02Before() {
  return (
    <div className="relative w-screen h-screen overflow-hidden bg-bg">
      {/* Subtle ripple watermark top-right */}
      <div className="absolute" style={{ right: "-5vw", top: "-5vh", opacity: 0.06 }}>
        <svg width="45vw" height="45vw" viewBox="0 0 500 500" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
          <circle cx="250" cy="250" r="60" fill="#0EA5E9" />
          <circle cx="250" cy="250" r="130" stroke="#0EA5E9" strokeWidth="3" fill="none" />
          <circle cx="250" cy="250" r="200" stroke="#0EA5E9" strokeWidth="2.5" fill="none" />
          <circle cx="250" cy="250" r="270" stroke="#0EA5E9" strokeWidth="2" fill="none" />
          <circle cx="250" cy="250" r="340" stroke="#0EA5E9" strokeWidth="1.5" fill="none" />
        </svg>
      </div>

      {/* Orange accent bar at top */}
      <div className="absolute top-0 left-0 right-0" style={{ height: "0.8vh", background: "#F97316" }} />

      <div className="relative z-10 flex h-full" style={{ paddingTop: "8vh", paddingBottom: "8vh", paddingLeft: "8vw", paddingRight: "8vw" }}>
        {/* Left column — context */}
        <div className="flex flex-col justify-center" style={{ width: "45%" }}>
          <p className="font-body font-medium uppercase tracking-widest text-accent mb-[2vh]" style={{ fontSize: "1.4vw" }}>Before the Rebrand</p>
          <h2 className="font-display font-extrabold text-text tracking-tight leading-none mb-[3vh]" style={{ fontSize: "5vw", textWrap: "balance" }}>
            A product without a brand.
          </h2>
          <div className="w-[4vw] h-[0.5vh] mb-[3vh]" style={{ background: "#0EA5E9" }} />
          <p className="font-body text-muted leading-relaxed" style={{ fontSize: "2.4vw", textWrap: "pretty" }}>
            The app worked. The name did not. "Referral Hub" described a feature, not a feeling — and it showed.
          </p>
        </div>

        {/* Divider */}
        <div className="flex-shrink-0" style={{ width: "8%", display: "flex", alignItems: "center", justifyContent: "center" }}>
          <div style={{ width: "1px", height: "60%", background: "linear-gradient(to bottom, transparent, #CBD5E1, transparent)" }} />
        </div>

        {/* Right column — pain points */}
        <div className="flex flex-col justify-center" style={{ width: "47%" }}>
          <p className="font-body font-medium text-muted uppercase tracking-widest mb-[3vh]" style={{ fontSize: "1.4vw" }}>What wasn't working</p>

          <div className="flex flex-col" style={{ gap: "2.5vh" }}>
            <div className="flex items-start" style={{ gap: "2vw" }}>
              <div className="flex-shrink-0 w-[1vw] h-[1vw] rounded-full mt-[0.6vh]" style={{ background: "#F97316" }} />
              <div>
                <p className="font-display font-bold text-text" style={{ fontSize: "2.2vw" }}>Forgettable name</p>
                <p className="font-body text-muted" style={{ fontSize: "1.9vw" }}>"Referral Hub" read like a back-office tool, not a social product</p>
              </div>
            </div>

            <div className="flex items-start" style={{ gap: "2vw" }}>
              <div className="flex-shrink-0 w-[1vw] h-[1vw] rounded-full mt-[0.6vh]" style={{ background: "#F97316" }} />
              <div>
                <p className="font-display font-bold text-text" style={{ fontSize: "2.2vw" }}>No visual identity</p>
                <p className="font-body text-muted" style={{ fontSize: "1.9vw" }}>Generic palette, no ownable mark, no emotional resonance</p>
              </div>
            </div>

            <div className="flex items-start" style={{ gap: "2vw" }}>
              <div className="flex-shrink-0 w-[1vw] h-[1vw] rounded-full mt-[0.6vh]" style={{ background: "#F97316" }} />
              <div>
                <p className="font-display font-bold text-text" style={{ fontSize: "2.2vw" }}>Mismatch in tone</p>
                <p className="font-body text-muted" style={{ fontSize: "1.9vw" }}>Community-first product with corporate-sounding copy</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom label */}
      <div className="absolute bottom-0 left-0 right-0 flex items-center justify-between" style={{ padding: "0 8vw", paddingBottom: "3vh" }}>
        <span className="font-body text-muted" style={{ fontSize: "1.4vw" }}>Referral Hub → Ripple</span>
        <span className="font-body text-muted" style={{ fontSize: "1.4vw" }}>2026</span>
      </div>
    </div>
  );
}

export default function Slide01Title() {
  return (
    <div className="relative w-screen h-screen overflow-hidden" style={{ background: "linear-gradient(135deg, #0C4A6E 0%, #0EA5E9 60%, #38BDF8 100%)" }}>
      {/* Ripple concentric circles — decorative background motif */}
      <div className="absolute" style={{ right: "-8vw", top: "50%", transform: "translateY(-50%)" }}>
        <svg width="70vw" height="70vw" viewBox="0 0 700 700" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
          <circle cx="350" cy="350" r="80" fill="white" fillOpacity="0.12" />
          <circle cx="350" cy="350" r="160" stroke="white" strokeOpacity="0.15" strokeWidth="2" fill="none" />
          <circle cx="350" cy="350" r="240" stroke="white" strokeOpacity="0.10" strokeWidth="2" fill="none" />
          <circle cx="350" cy="350" r="320" stroke="white" strokeOpacity="0.07" strokeWidth="2" fill="none" />
          <circle cx="350" cy="350" r="400" stroke="white" strokeOpacity="0.05" strokeWidth="2" fill="none" />
          <circle cx="350" cy="350" r="480" stroke="white" strokeOpacity="0.04" strokeWidth="1.5" fill="none" />
          <circle cx="350" cy="350" r="560" stroke="white" strokeOpacity="0.03" strokeWidth="1.5" fill="none" />
        </svg>
      </div>

      {/* Content */}
      <div className="relative z-10 flex flex-col justify-center h-full" style={{ paddingLeft: "8vw", paddingRight: "45vw" }}>
        {/* Logo mark */}
        <div className="flex items-center gap-[1.5vw] mb-[3vh]">
          <svg width="4vw" height="4vw" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
            <circle cx="32" cy="32" r="8" fill="white" />
            <circle cx="32" cy="32" r="18" stroke="white" strokeOpacity="0.7" strokeWidth="3" fill="none" />
            <circle cx="32" cy="32" r="28" stroke="white" strokeOpacity="0.4" strokeWidth="2.5" fill="none" />
          </svg>
          <span className="font-display font-bold text-white" style={{ fontSize: "2.6vw", letterSpacing: "-0.02em" }}>Ripple</span>
        </div>

        <p className="font-body font-medium text-white/60 uppercase tracking-widest mb-[2vh]" style={{ fontSize: "1.4vw" }}>Brand Story · 2026</p>

        <h1 className="font-display font-extrabold text-white leading-none tracking-tight" style={{ fontSize: "7.5vw", textWrap: "balance" }}>
          A New Name.
        </h1>
        <h1 className="font-display font-extrabold leading-none tracking-tight mb-[4vh]" style={{ fontSize: "7.5vw", color: "#7DD3FC", textWrap: "balance" }}>
          A Shared Identity.
        </h1>

        <div className="w-[5vw] h-[0.4vh] mb-[3vh]" style={{ background: "#F97316" }} />

        <p className="font-body text-white/75 leading-relaxed" style={{ fontSize: "2.2vw", textWrap: "pretty" }}>
          How we went from a referral tracker to a community brand — and why every choice matters.
        </p>
      </div>
    </div>
  );
}

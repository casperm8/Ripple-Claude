export default function Slide08VoiceTone() {
  return (
    <div className="relative w-screen h-screen overflow-hidden" style={{ background: "#0C4A6E" }}>
      {/* Ripple decorative BG */}
      <div className="absolute" style={{ right: "-10vw", bottom: "-10vh", opacity: 0.08 }}>
        <svg width="60vw" height="60vw" viewBox="0 0 600 600" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
          <circle cx="300" cy="300" r="60" fill="#38BDF8" />
          <circle cx="300" cy="300" r="140" stroke="#38BDF8" strokeWidth="3" fill="none" />
          <circle cx="300" cy="300" r="220" stroke="#38BDF8" strokeWidth="2.5" fill="none" />
          <circle cx="300" cy="300" r="300" stroke="#38BDF8" strokeWidth="2" fill="none" />
          <circle cx="300" cy="300" r="380" stroke="#38BDF8" strokeWidth="1.5" fill="none" />
          <circle cx="300" cy="300" r="460" stroke="#38BDF8" strokeWidth="1" fill="none" />
        </svg>
      </div>

      {/* Orange bar */}
      <div className="absolute top-0 left-0 right-0" style={{ height: "0.8vh", background: "#F97316" }} />

      <div className="relative z-10 flex flex-col h-full" style={{ paddingTop: "7vh", paddingBottom: "6vh", paddingLeft: "8vw", paddingRight: "8vw" }}>
        <p className="font-body font-medium uppercase tracking-widest text-white/50 mb-[1vh]" style={{ fontSize: "1.4vw" }}>Voice & Tone</p>
        <h2 className="font-display font-extrabold text-white tracking-tight leading-none mb-[4vh]" style={{ fontSize: "4.5vw" }}>
          A friend who found a great deal.
        </h2>

        <div className="flex flex-1" style={{ gap: "3vw" }}>
          {/* Personality pillars */}
          <div className="flex flex-col justify-between" style={{ width: "35%", paddingRight: "3vw", borderRight: "1px solid rgba(255,255,255,0.15)" }}>
            <div>
              <p className="font-body font-medium text-white/50 uppercase tracking-widest mb-[2vh]" style={{ fontSize: "1.3vw" }}>Personality</p>
              <div className="flex flex-col" style={{ gap: "2vh" }}>
                <div className="flex items-center" style={{ gap: "1.5vw" }}>
                  <div style={{ width: "0.5vw", height: "0.5vw", borderRadius: "50%", background: "#F97316", flexShrink: 0 }} />
                  <div>
                    <p className="font-display font-bold text-white" style={{ fontSize: "2.1vw" }}>Enthusiastic</p>
                    <p className="font-body text-white/50" style={{ fontSize: "1.6vw" }}>Not hype. Genuine excitement.</p>
                  </div>
                </div>
                <div className="flex items-center" style={{ gap: "1.5vw" }}>
                  <div style={{ width: "0.5vw", height: "0.5vw", borderRadius: "50%", background: "#F97316", flexShrink: 0 }} />
                  <div>
                    <p className="font-display font-bold text-white" style={{ fontSize: "2.1vw" }}>Community-first</p>
                    <p className="font-body text-white/50" style={{ fontSize: "1.6vw" }}>We before me, always.</p>
                  </div>
                </div>
                <div className="flex items-center" style={{ gap: "1.5vw" }}>
                  <div style={{ width: "0.5vw", height: "0.5vw", borderRadius: "50%", background: "#F97316", flexShrink: 0 }} />
                  <div>
                    <p className="font-display font-bold text-white" style={{ fontSize: "2.1vw" }}>Direct</p>
                    <p className="font-body text-white/50" style={{ fontSize: "1.6vw" }}>No jargon. Plain language.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Do / Don't examples */}
          <div className="flex flex-col flex-1 justify-center" style={{ gap: "2.5vh" }}>
            <p className="font-body font-medium text-white/50 uppercase tracking-widest" style={{ fontSize: "1.3vw" }}>In practice</p>

            <div className="flex" style={{ gap: "2.5vw" }}>
              <div className="flex flex-col flex-1" style={{ gap: "1.5vh" }}>
                <div className="rounded-lg p-[2vh_2vw]" style={{ background: "rgba(14,165,233,0.15)", border: "1px solid rgba(14,165,233,0.3)" }}>
                  <p className="font-body text-white/50 mb-[0.5vh]" style={{ fontSize: "1.2vw" }}>We say</p>
                  <p className="font-body font-medium text-white" style={{ fontSize: "1.9vw" }}>"Your friend shared this — grab it before it's gone."</p>
                </div>
                <div className="rounded-lg p-[2vh_2vw]" style={{ background: "rgba(14,165,233,0.15)", border: "1px solid rgba(14,165,233,0.3)" }}>
                  <p className="font-body text-white/50 mb-[0.5vh]" style={{ fontSize: "1.2vw" }}>We say</p>
                  <p className="font-body font-medium text-white" style={{ fontSize: "1.9vw" }}>"Oops! Something went sideways. Try again?"</p>
                </div>
              </div>

              <div className="flex flex-col flex-1" style={{ gap: "1.5vh" }}>
                <div className="rounded-lg p-[2vh_2vw]" style={{ background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.12)" }}>
                  <p className="font-body text-white/30 mb-[0.5vh]" style={{ fontSize: "1.2vw" }}>Not this</p>
                  <p className="font-body font-medium text-white/50" style={{ fontSize: "1.9vw" }}>"Access your referral dashboard to maximize savings potential."</p>
                </div>
                <div className="rounded-lg p-[2vh_2vw]" style={{ background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.12)" }}>
                  <p className="font-body text-white/30 mb-[0.5vh]" style={{ fontSize: "1.2vw" }}>Not this</p>
                  <p className="font-body font-medium text-white/50" style={{ fontSize: "1.9vw" }}>"An unexpected error has occurred. Error code: 4032."</p>
                </div>
              </div>
            </div>

            <p className="font-body text-white/40 italic" style={{ fontSize: "1.7vw" }}>
              Tagline: "Find codes. Share codes. Earn together."
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

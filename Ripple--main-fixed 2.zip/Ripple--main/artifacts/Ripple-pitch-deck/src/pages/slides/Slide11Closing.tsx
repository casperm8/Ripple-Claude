import { useDeckConfig } from "../../context/DeckConfigContext";

export default function Slide11Closing() {
  const { config } = useDeckConfig();

  return (
    <div
      className="relative w-screen h-screen overflow-hidden"
      style={{ background: "linear-gradient(135deg, #0C4A6E 0%, #0EA5E9 60%, #38BDF8 100%)" }}
    >
      {/* Ripple concentric circles — decorative background motif (mirrored left) */}
      <div className="absolute" style={{ left: "-8vw", top: "50%", transform: "translateY(-50%)" }}>
        <svg width="70vw" height="70vw" viewBox="0 0 700 700" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
          <circle cx="350" cy="350" r="80" fill="white" fillOpacity="0.12" />
          <circle cx="350" cy="350" r="160" stroke="white" strokeOpacity="0.15" strokeWidth="2" fill="none" />
          <circle cx="350" cy="350" r="240" stroke="white" strokeOpacity="0.10" strokeWidth="2" fill="none" />
          <circle cx="350" cy="350" r="320" stroke="white" strokeOpacity="0.07" strokeWidth="2" fill="none" />
          <circle cx="350" cy="350" r="400" stroke="white" strokeOpacity="0.05" strokeWidth="2" fill="none" />
          <circle cx="350" cy="350" r="480" stroke="white" strokeOpacity="0.04" strokeWidth="1.5" fill="none" />
          <circle cx="350" cy="350" r="560" stroke="white" strokeOpacity="0.03" strokeWidth="1.5" fill="none" />
        </svg>
      </div>

      {/* Content — right-aligned to balance the left motif */}
      <div className="relative z-10 flex flex-col justify-center items-end h-full text-right" style={{ paddingRight: "8vw", paddingLeft: "45vw" }}>
        {/* Logo lockup */}
        <div className="flex items-center gap-[1.5vw] mb-[3vh]">
          <svg width="4vw" height="4vw" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
            <circle cx="32" cy="32" r="8" fill="white" />
            <circle cx="32" cy="32" r="18" stroke="white" strokeOpacity="0.7" strokeWidth="3" fill="none" />
            <circle cx="32" cy="32" r="28" stroke="white" strokeOpacity="0.4" strokeWidth="2.5" fill="none" />
          </svg>
          <span className="font-display font-bold text-white" style={{ fontSize: "2.6vw", letterSpacing: "-0.02em" }}>Ripple</span>
        </div>

        {/* Tagline */}
        <h2
          className="font-display font-extrabold text-white leading-none tracking-tight mb-[2vh]"
          style={{ fontSize: "6vw", textWrap: "balance" }}
        >
          Built to spread.
        </h2>
        <h2
          className="font-display font-extrabold leading-none tracking-tight mb-[4vh]"
          style={{ fontSize: "6vw", color: "#7DD3FC", textWrap: "balance" }}
        >
          Ready to grow.
        </h2>

        {/* Divider */}
        <div className="h-[0.4vh] mb-[4vh] self-end" style={{ width: "5vw", background: "#F97316" }} />

        {/* Live demo link */}
        <div className="mb-[3vh]">
          <p className="font-body font-medium text-white/60 uppercase tracking-widest mb-[0.8vh]" style={{ fontSize: "1.1vw" }}>
            Live Demo
          </p>
          <a
            href={config.demoUrl}
            className="font-body font-semibold text-white hover:text-sky-200 transition-colors"
            style={{ fontSize: "2vw", textDecoration: "none" }}
          >
            {config.demoLabel}
          </a>
        </div>

        {/* Contact */}
        <div>
          <p className="font-body font-medium text-white/60 uppercase tracking-widest mb-[1.2vh]" style={{ fontSize: "1.1vw" }}>
            Get in touch
          </p>
          <p className="font-body text-white/90 leading-relaxed" style={{ fontSize: "1.7vw" }}>
            {config.contactEmail}
          </p>
          <p className="font-body text-white/70" style={{ fontSize: "1.4vw" }}>
            {config.socialHandles}
          </p>
        </div>
      </div>
    </div>
  );
}

export default function Slide09Accessibility() {
  return (
    <div className="relative w-screen h-screen overflow-hidden bg-bg">
      {/* Blue accent bar */}
      <div className="absolute top-0 left-0 right-0" style={{ height: "0.8vh", background: "#0EA5E9" }} />

      {/* Ripple watermark */}
      <div className="absolute" style={{ right: "-6vw", top: "-4vh", opacity: 0.05 }}>
        <svg width="45vw" height="45vw" viewBox="0 0 500 500" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
          <circle cx="250" cy="250" r="60" fill="#0EA5E9" />
          <circle cx="250" cy="250" r="140" stroke="#0EA5E9" strokeWidth="3" fill="none" />
          <circle cx="250" cy="250" r="220" stroke="#0EA5E9" strokeWidth="2.5" fill="none" />
          <circle cx="250" cy="250" r="300" stroke="#0EA5E9" strokeWidth="2" fill="none" />
          <circle cx="250" cy="250" r="380" stroke="#0EA5E9" strokeWidth="1.5" fill="none" />
        </svg>
      </div>

      <div className="relative z-10 flex h-full" style={{ paddingTop: "7vh", paddingBottom: "6vh", paddingLeft: "8vw", paddingRight: "8vw" }}>
        {/* Left */}
        <div className="flex flex-col justify-center" style={{ width: "38%", paddingRight: "5vw", borderRight: "1px solid #BAE6FD" }}>
          <p className="font-body font-medium uppercase tracking-widest text-accent mb-[1vh]" style={{ fontSize: "1.4vw" }}>Accessibility</p>
          <h2 className="font-display font-extrabold text-text tracking-tight leading-none mb-[2.5vh]" style={{ fontSize: "4.5vw", textWrap: "balance" }}>
            Built for everyone.
          </h2>
          <div className="w-[4vw] h-[0.5vh] mb-[3vh]" style={{ background: "#0EA5E9" }} />
          <p className="font-body text-muted leading-relaxed" style={{ fontSize: "2vw" }}>
            WCAG AA compliance is a hard requirement — not a stretch goal. Every pixel we ship is usable by anyone who shows up.
          </p>
        </div>

        {/* Right — standards grid */}
        <div className="flex flex-col justify-center flex-1" style={{ paddingLeft: "5vw", gap: "2.5vh" }}>
          <div className="flex" style={{ gap: "2.5vw" }}>
            {/* Contrast ratio */}
            <div className="flex-1 rounded-xl p-[3vh_2vw]" style={{ background: "white", border: "1px solid #BAE6FD" }}>
              <p className="font-display font-extrabold text-primary mb-[0.5vh]" style={{ fontSize: "4vw" }}>4.5:1</p>
              <p className="font-display font-bold text-text mb-[0.5vh]" style={{ fontSize: "2vw" }}>Minimum contrast</p>
              <p className="font-body text-muted" style={{ fontSize: "1.7vw" }}>Small text. WCAG AA compliant.</p>
            </div>

            {/* Large text contrast */}
            <div className="flex-1 rounded-xl p-[3vh_2vw]" style={{ background: "white", border: "1px solid #BAE6FD" }}>
              <p className="font-display font-extrabold text-primary mb-[0.5vh]" style={{ fontSize: "4vw" }}>3:1</p>
              <p className="font-display font-bold text-text mb-[0.5vh]" style={{ fontSize: "2vw" }}>Large text contrast</p>
              <p className="font-body text-muted" style={{ fontSize: "1.7vw" }}>Headlines and display type.</p>
            </div>
          </div>

          <div className="flex" style={{ gap: "2.5vw" }}>
            {/* Touch target */}
            <div className="flex-1 rounded-xl p-[3vh_2vw]" style={{ background: "white", border: "1px solid #BAE6FD" }}>
              <p className="font-display font-extrabold" style={{ fontSize: "4vw", color: "#F97316" }}>48px</p>
              <p className="font-display font-bold text-text mb-[0.5vh]" style={{ fontSize: "2vw" }}>Min touch target</p>
              <p className="font-body text-muted" style={{ fontSize: "1.7vw" }}>All interactive elements.</p>
            </div>

            {/* Primary alt */}
            <div className="flex-1 rounded-xl p-[3vh_2vw]" style={{ background: "white", border: "1px solid #BAE6FD" }}>
              <p className="font-body font-medium text-muted mb-[1vh]" style={{ fontSize: "1.4vw" }}>Accessible primary</p>
              <div className="flex items-center" style={{ gap: "1vw" }}>
                <div className="rounded-lg" style={{ width: "3vw", height: "3vw", background: "#0369A1" }} />
                <div>
                  <p className="font-display font-bold text-text" style={{ fontSize: "2vw" }}>#0369A1</p>
                  <p className="font-body text-muted" style={{ fontSize: "1.4vw" }}>Used for small text</p>
                </div>
              </div>
              <p className="font-body text-muted mt-[1vh]" style={{ fontSize: "1.5vw" }}>Passes AA on white at 5.8:1</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

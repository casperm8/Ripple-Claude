export default function Slide05TypeSystem() {
  return (
    <div className="relative w-screen h-screen overflow-hidden bg-bg">
      {/* Ripple watermark top right */}
      <div className="absolute" style={{ right: "-6vw", top: "-6vh", opacity: 0.05 }}>
        <svg width="48vw" height="48vw" viewBox="0 0 500 500" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
          <circle cx="250" cy="250" r="60" fill="#0EA5E9" />
          <circle cx="250" cy="250" r="140" stroke="#0EA5E9" strokeWidth="3" fill="none" />
          <circle cx="250" cy="250" r="220" stroke="#0EA5E9" strokeWidth="2.5" fill="none" />
          <circle cx="250" cy="250" r="300" stroke="#0EA5E9" strokeWidth="2" fill="none" />
          <circle cx="250" cy="250" r="380" stroke="#0EA5E9" strokeWidth="1.5" fill="none" />
        </svg>
      </div>

      {/* Orange bar */}
      <div className="absolute top-0 left-0 right-0" style={{ height: "0.8vh", background: "#F97316" }} />

      <div className="relative z-10 flex h-full" style={{ paddingTop: "7vh", paddingBottom: "6vh", paddingLeft: "8vw", paddingRight: "8vw" }}>
        {/* Left column */}
        <div className="flex flex-col justify-between" style={{ width: "42%", paddingRight: "4vw", borderRight: "1px solid #BAE6FD" }}>
          <div>
            <p className="font-body font-medium uppercase tracking-widest text-accent mb-[1vh]" style={{ fontSize: "1.4vw" }}>Type System</p>
            <h2 className="font-display font-extrabold text-text tracking-tight leading-none mb-[2.5vh]" style={{ fontSize: "4.5vw" }}>
              Friendly. Clear. Bold.
            </h2>
            <div className="w-[4vw] h-[0.5vh] mb-[3vh]" style={{ background: "#0EA5E9" }} />
            <p className="font-body text-muted leading-relaxed" style={{ fontSize: "2vw" }}>
              Nunito brings warmth to headlines — rounded terminals signal approachability. Inter grounds the interface in legibility.
            </p>
          </div>

          <div className="flex flex-col" style={{ gap: "2vh" }}>
            <div className="rounded-lg p-[2vh_2vw]" style={{ background: "rgba(14,165,233,0.08)", border: "1px solid rgba(14,165,233,0.2)" }}>
              <p className="font-body text-muted mb-[0.5vh]" style={{ fontSize: "1.4vw" }}>Display / Headings</p>
              <p className="font-display font-extrabold text-primary" style={{ fontSize: "2.4vw" }}>Nunito 800</p>
            </div>
            <div className="rounded-lg p-[2vh_2vw]" style={{ background: "rgba(14,165,233,0.08)", border: "1px solid rgba(14,165,233,0.2)" }}>
              <p className="font-body text-muted mb-[0.5vh]" style={{ fontSize: "1.4vw" }}>Body / Interface</p>
              <p className="font-body font-medium text-text" style={{ fontSize: "2.4vw" }}>Inter 400 · 700</p>
            </div>
          </div>
        </div>

        {/* Right column — type specimens */}
        <div className="flex flex-col justify-center" style={{ width: "58%", paddingLeft: "5vw", gap: "2.5vh" }}>
          {/* Hero display */}
          <div>
            <p className="font-body text-muted uppercase tracking-widest mb-[0.5vh]" style={{ fontSize: "1.2vw" }}>Hero / Display — 7vw · Nunito 800</p>
            <p className="font-display font-extrabold text-text tracking-tight leading-none" style={{ fontSize: "7vw" }}>Ripple</p>
          </div>

          <div style={{ height: "1px", background: "#BAE6FD" }} />

          {/* Section headline */}
          <div>
            <p className="font-body text-muted uppercase tracking-widest mb-[0.5vh]" style={{ fontSize: "1.2vw" }}>Section Headline — 4vw · Nunito 800</p>
            <p className="font-display font-extrabold text-text tracking-tight" style={{ fontSize: "4vw" }}>Find codes. Share codes. Earn together.</p>
          </div>

          <div style={{ height: "1px", background: "#BAE6FD" }} />

          {/* Body */}
          <div>
            <p className="font-body text-muted uppercase tracking-widest mb-[0.5vh]" style={{ fontSize: "1.2vw" }}>Body — 3vw · Inter 400</p>
            <p className="font-body text-text leading-relaxed" style={{ fontSize: "3vw" }}>Referral codes, shared by real people for real people.</p>
          </div>

          <div style={{ height: "1px", background: "#BAE6FD" }} />

          {/* Code / mono */}
          <div>
            <p className="font-body text-muted uppercase tracking-widest mb-[0.5vh]" style={{ fontSize: "1.2vw" }}>Referral Code — JetBrains Mono</p>
            <p className="font-body text-primary font-medium tracking-widest" style={{ fontSize: "2.8vw", fontFamily: "'JetBrains Mono', monospace" }}>RIPPLE-XK92</p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function Slide04ColorSystem() {
  return (
    <div className="relative w-screen h-screen overflow-hidden bg-bg">
      {/* Subtle ripple watermark */}
      <div className="absolute" style={{ left: "-8vw", bottom: "-8vh", opacity: 0.05 }}>
        <svg width="50vw" height="50vw" viewBox="0 0 500 500" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
          <circle cx="250" cy="250" r="60" fill="#0EA5E9" />
          <circle cx="250" cy="250" r="140" stroke="#0EA5E9" strokeWidth="3" fill="none" />
          <circle cx="250" cy="250" r="220" stroke="#0EA5E9" strokeWidth="2.5" fill="none" />
          <circle cx="250" cy="250" r="300" stroke="#0EA5E9" strokeWidth="2" fill="none" />
          <circle cx="250" cy="250" r="380" stroke="#0EA5E9" strokeWidth="1.5" fill="none" />
        </svg>
      </div>

      {/* Blue accent bar */}
      <div className="absolute top-0 left-0 right-0" style={{ height: "0.8vh", background: "#0EA5E9" }} />

      <div className="relative z-10 flex flex-col h-full" style={{ paddingTop: "7vh", paddingBottom: "6vh", paddingLeft: "8vw", paddingRight: "8vw" }}>
        <p className="font-body font-medium uppercase tracking-widest text-accent mb-[1vh]" style={{ fontSize: "1.4vw" }}>Color System</p>
        <h2 className="font-display font-extrabold text-text tracking-tight leading-none mb-[4vh]" style={{ fontSize: "4.5vw" }}>
          Sky and flame.
        </h2>

        {/* Color swatches row */}
        <div className="flex" style={{ gap: "2.5vw", flex: 1 }}>
          {/* Primary */}
          <div className="flex flex-col" style={{ flex: 2 }}>
            <div className="rounded-xl flex-1 flex flex-col justify-end" style={{ background: "#0EA5E9", padding: "3vh 2.5vw", minHeight: "30vh" }}>
              <p className="font-display font-extrabold text-white leading-none" style={{ fontSize: "2vw" }}>Primary</p>
              <p className="font-body text-white/70" style={{ fontSize: "1.6vw" }}>Sky Blue</p>
              <p className="font-body font-medium text-white/90 mt-[1vh]" style={{ fontSize: "1.9vw" }}>#0EA5E9</p>
            </div>
            <p className="font-body text-muted mt-[1.5vh]" style={{ fontSize: "1.7vw" }}>Buttons, links, interactive elements</p>
          </div>

          {/* Accent */}
          <div className="flex flex-col" style={{ flex: 1.5 }}>
            <div className="rounded-xl flex-1 flex flex-col justify-end" style={{ background: "#F97316", padding: "3vh 2.5vw", minHeight: "30vh" }}>
              <p className="font-display font-extrabold text-white leading-none" style={{ fontSize: "2vw" }}>Accent</p>
              <p className="font-body text-white/70" style={{ fontSize: "1.6vw" }}>Orange</p>
              <p className="font-body font-medium text-white/90 mt-[1vh]" style={{ fontSize: "1.9vw" }}>#F97316</p>
            </div>
            <p className="font-body text-muted mt-[1.5vh]" style={{ fontSize: "1.7vw" }}>CTAs, rewards, hot badges</p>
          </div>

          {/* Background */}
          <div className="flex flex-col" style={{ flex: 1 }}>
            <div className="rounded-xl flex-1 flex flex-col justify-end" style={{ background: "#F0FAFF", border: "1px solid #BAE6FD", padding: "3vh 2.5vw", minHeight: "30vh" }}>
              <p className="font-display font-extrabold text-text leading-none" style={{ fontSize: "2vw" }}>Background</p>
              <p className="font-body text-muted" style={{ fontSize: "1.6vw" }}>Tinted White</p>
              <p className="font-body font-medium text-text/70 mt-[1vh]" style={{ fontSize: "1.9vw" }}>#F0FAFF</p>
            </div>
            <p className="font-body text-muted mt-[1.5vh]" style={{ fontSize: "1.7vw" }}>Surfaces, app backgrounds</p>
          </div>

          {/* Text / Dark */}
          <div className="flex flex-col" style={{ flex: 1 }}>
            <div className="rounded-xl flex-1 flex flex-col justify-end" style={{ background: "#0F172A", padding: "3vh 2.5vw", minHeight: "30vh" }}>
              <p className="font-display font-extrabold text-white leading-none" style={{ fontSize: "2vw" }}>Text</p>
              <p className="font-body text-white/60" style={{ fontSize: "1.6vw" }}>Dark Navy</p>
              <p className="font-body font-medium text-white/80 mt-[1vh]" style={{ fontSize: "1.9vw" }}>#0F172A</p>
            </div>
            <p className="font-body text-muted mt-[1.5vh]" style={{ fontSize: "1.7vw" }}>High-emphasis copy</p>
          </div>

          {/* Muted */}
          <div className="flex flex-col" style={{ flex: 0.8 }}>
            <div className="rounded-xl flex-1 flex flex-col justify-end" style={{ background: "#64748B", padding: "3vh 2.5vw", minHeight: "30vh" }}>
              <p className="font-display font-extrabold text-white leading-none" style={{ fontSize: "2vw" }}>Muted</p>
              <p className="font-body text-white/60" style={{ fontSize: "1.6vw" }}>Slate</p>
              <p className="font-body font-medium text-white/80 mt-[1vh]" style={{ fontSize: "1.9vw" }}>#64748B</p>
            </div>
            <p className="font-body text-muted mt-[1.5vh]" style={{ fontSize: "1.7vw" }}>Secondary info</p>
          </div>
        </div>
      </div>
    </div>
  );
}

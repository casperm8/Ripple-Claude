import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { Router } from "wouter";

import App from "./App";
import { DeckConfigProvider } from "./context/DeckConfigContext";
import "./index.css";

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <DeckConfigProvider>
      <Router base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
        <App />
      </Router>
    </DeckConfigProvider>
  </StrictMode>,
);

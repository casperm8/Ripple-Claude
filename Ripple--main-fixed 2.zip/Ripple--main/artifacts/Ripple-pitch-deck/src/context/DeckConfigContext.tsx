import { createContext, useContext, useState } from "react";
import type { ReactNode } from "react";
import defaultConfig from "../data/deck-config";

export interface DeckConfig {
  demoUrl: string;
  demoLabel: string;
  contactEmail: string;
  socialHandles: string;
}

interface DeckConfigContextValue {
  config: DeckConfig;
  setConfig: (patch: Partial<DeckConfig>) => void;
  resetConfig: () => void;
}

const STORAGE_KEY = "ripple-deck-config";

function loadFromStorage(): DeckConfig {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      return { ...defaultConfig, ...JSON.parse(raw) };
    }
  } catch {
  }
  return { ...defaultConfig };
}

function saveToStorage(config: DeckConfig) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(config));
  } catch {
  }
}

const DeckConfigContext = createContext<DeckConfigContextValue | null>(null);

export function DeckConfigProvider({ children }: { children: ReactNode }) {
  const [config, setConfigState] = useState<DeckConfig>(loadFromStorage);

  const setConfig = (patch: Partial<DeckConfig>) =>
    setConfigState((prev) => {
      const next = { ...prev, ...patch };
      saveToStorage(next);
      return next;
    });

  const resetConfig = () => {
    try {
      localStorage.removeItem(STORAGE_KEY);
    } catch {
    }
    setConfigState({ ...defaultConfig });
  };

  return (
    <DeckConfigContext.Provider value={{ config, setConfig, resetConfig }}>
      {children}
    </DeckConfigContext.Provider>
  );
}

export function useDeckConfig(): DeckConfigContextValue {
  const ctx = useContext(DeckConfigContext);
  if (!ctx) throw new Error("useDeckConfig must be used inside DeckConfigProvider");
  return ctx;
}

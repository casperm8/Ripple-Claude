import { useState } from "react";
import {
  useGetPlans,
  useGetMe,
  useCreateCheckout,
  useCreateBillingPortal,
} from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Check, Crown, ExternalLink, Loader2, Zap } from "lucide-react";

export function Upgrade() {
  const { data: me } = useGetMe();
  const { data: plans, isLoading } = useGetPlans();
  const isPro = me?.tier === "pro";

  const [loadingPriceId, setLoadingPriceId] = useState<string | null>(null);

  const checkout = useCreateCheckout();
  const portal = useCreateBillingPortal();

  const handleCheckout = async (priceId: string) => {
    setLoadingPriceId(priceId);
    try {
      const result = await checkout.mutateAsync({
        data: {
          priceId,
          successUrl: `${window.location.origin}/upgrade?success=1`,
          cancelUrl: `${window.location.origin}/upgrade`,
        },
      });
      if (result.url) window.location.href = result.url;
    } catch {
      setLoadingPriceId(null);
    }
  };

  const handlePortal = async () => {
    try {
      const result = await portal.mutateAsync();
      if (result.url) window.location.href = result.url;
    } catch {
    }
  };

  if (isPro) {
    return (
      <div>
        <div
          className="px-8 py-8"
          style={{ background: "linear-gradient(135deg, #312E81 0%, #4338CA 100%)" }}
        >
          <div className="max-w-2xl">
            <h1 className="text-2xl font-bold text-white mb-1">Subscription</h1>
            <p className="text-white/60 text-sm">Manage your Pro membership</p>
          </div>
        </div>
        <div className="max-w-2xl mx-auto px-8 py-16 text-center">
          <div
            className="w-20 h-20 rounded-3xl mx-auto flex items-center justify-center mb-5"
            style={{ background: "linear-gradient(135deg, #3730A3, #5B21B6)" }}
          >
            <Crown className="w-10 h-10 text-yellow-300" />
          </div>
          <h2 className="text-2xl font-bold mb-2">You're on Pro</h2>
          <p className="text-muted-foreground mb-8">
            You have unlimited posts, unlimited claims, and no ads.
          </p>
          <Button
            variant="outline"
            className="gap-2"
            onClick={handlePortal}
            disabled={portal.isPending}
          >
            {portal.isPending ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <ExternalLink className="w-4 h-4" />
            )}
            Manage Billing
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div>
      <div
        className="px-8 py-12 text-center"
        style={{ background: "linear-gradient(135deg, #312E81 0%, #4338CA 100%)" }}
      >
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-yellow-400 text-yellow-900 text-sm font-semibold mb-5">
          <Crown className="w-3.5 h-3.5" /> Upgrade
        </div>
        <h1 className="text-3xl font-extrabold text-white mb-3">Go Pro, go unlimited</h1>
        <p className="text-white/65 max-w-md mx-auto">
          Remove all limits and ads. Post and claim as many codes as you want.
        </p>
      </div>

      <div className="max-w-3xl mx-auto px-8 py-10">
        <div className="grid md:grid-cols-2 gap-5 mb-10">
          <div className="rounded-2xl border-2 bg-card p-7">
            <div className="text-muted-foreground font-semibold mb-5">Free</div>
            <ul className="space-y-3">
              {["5 claims / day", "2 posts / week", "Ad-supported"].map((f) => (
                <li key={f} className="flex items-center gap-3 text-sm text-muted-foreground">
                  <div className="w-4 h-4 rounded-full bg-muted flex items-center justify-center shrink-0">
                    <div className="w-1.5 h-1.5 rounded-full bg-muted-foreground" />
                  </div>
                  {f}
                </li>
              ))}
            </ul>
          </div>

          <div
            className="rounded-2xl p-7 text-white"
            style={{ background: "linear-gradient(135deg, #3730A3, #5B21B6)" }}
          >
            <div className="flex items-center gap-2 font-semibold mb-5 text-white">
              <Crown className="w-4 h-4 text-yellow-300" /> Pro
            </div>
            <ul className="space-y-3">
              {["Unlimited daily claims", "Unlimited weekly posts", "Zero ads", "Priority support"].map((f) => (
                <li key={f} className="flex items-center gap-3 text-sm text-white/85">
                  <Check className="w-4 h-4 text-yellow-300 shrink-0" />
                  {f}
                </li>
              ))}
            </ul>
          </div>
        </div>

        {isLoading ? (
          <div className="grid md:grid-cols-2 gap-4">
            {[1, 2].map((i) => <Skeleton key={i} className="h-44 rounded-xl" />)}
          </div>
        ) : plans && plans.length > 0 ? (
          <div className="grid md:grid-cols-2 gap-5">
            {plans.map((plan) => {
              const isThisLoading = loadingPriceId === plan.priceId;
              return (
                <div
                  key={plan.priceId}
                  className="rounded-2xl border-2 border-primary/20 bg-card p-7 hover:border-primary/40 transition-colors"
                >
                  <div className="flex items-start justify-between mb-5">
                    <div>
                      <div className="font-semibold text-base">
                        {plan.interval === "year" ? "Annual" : "Monthly"}
                      </div>
                      {plan.interval === "year" && (
                        <span className="inline-block mt-1 px-2 py-0.5 bg-green-100 text-green-700 text-xs font-semibold rounded-full">
                          Save 33%
                        </span>
                      )}
                    </div>
                    <div className="text-right">
                      <div className="text-3xl font-extrabold">${(plan.amount / 100).toFixed(2)}</div>
                      <div className="text-xs text-muted-foreground">/{plan.interval}</div>
                    </div>
                  </div>

                  <ul className="space-y-2 mb-5">
                    {(plan.features ?? []).slice(0, 3).map((f: string) => (
                      <li key={f} className="flex items-center gap-2 text-sm text-muted-foreground">
                        <Zap className="w-3.5 h-3.5 text-primary shrink-0" />
                        {f}
                      </li>
                    ))}
                  </ul>

                  <Button
                    className="w-full font-semibold"
                    style={{ background: "linear-gradient(135deg, #3730A3, #5B21B6)" }}
                    onClick={() => handleCheckout(plan.priceId)}
                    disabled={loadingPriceId !== null}
                  >
                    {isThisLoading ? (
                      <><Loader2 className="w-4 h-4 animate-spin mr-2" /> Redirecting…</>
                    ) : (
                      "Upgrade to Pro"
                    )}
                  </Button>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="text-center py-12 text-muted-foreground">
            <Crown className="w-10 h-10 mx-auto mb-3 opacity-30" />
            <p>Plans not available right now. Please try again later.</p>
          </div>
        )}
      </div>
    </div>
  );
}

import { useState } from "react";
import { useLocation } from "wouter";
import { useCreateCode, useGetMe } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import { Link } from "wouter";
import { Crown, Send, Info, Minus, Plus } from "lucide-react";
import { getCategoryColor } from "@/lib/categories";

const CATEGORIES = [
  { id: "Finance", icon: "💳" },
  { id: "Food & Dining", icon: "🍔" },
  { id: "Crypto", icon: "₿" },
  { id: "Technology", icon: "💻" },
  { id: "Travel", icon: "✈️" },
  { id: "Entertainment", icon: "🎬" },
  { id: "Productivity", icon: "⚡" },
  { id: "Shopping", icon: "🛍️" },
  { id: "Health", icon: "❤️" },
  { id: "Gaming", icon: "🎮" },
  { id: "Other", icon: "📦" },
];

export function PostCode() {
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const { data: me } = useGetMe();
  const createCode = useCreateCode();

  const [form, setForm] = useState({
    title: "",
    description: "",
    code: "",
    category: "",
    maxClaims: 50,
    expiresAt: "",
  });

  const isFree = !me || me.tier === "free";
  const weeklyPostsUsed = me?.codesPostedThisWeek ?? 0;
  const weeklyLimit = me?.weeklyPostLimit ?? 2;
  const atLimit = isFree && weeklyLimit !== null && weeklyPostsUsed >= weeklyLimit;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.title || !form.description || !form.code || !form.category) {
      toast({ title: "Please fill in all required fields", variant: "destructive" });
      return;
    }
    createCode.mutate(
      {
        data: {
          title: form.title,
          description: form.description,
          code: form.code,
          category: form.category,
          maxClaims: form.maxClaims,
          expiresAt: form.expiresAt || null,
        },
      },
      {
        onSuccess: () => {
          toast({ title: "Code Posted!", description: "Your referral code is now live." });
          queryClient.invalidateQueries({ queryKey: ["/api/users/me/codes"] });
          queryClient.invalidateQueries({ queryKey: ["/api/codes"] });
          setLocation("/my-codes");
        },
        onError: (err: any) => {
          toast({ title: "Failed to post", description: err.message || "Something went wrong.", variant: "destructive" });
        },
      }
    );
  };

  return (
    <div>
      {/* Page header */}
      <div
        className="px-8 py-8"
        style={{ background: "linear-gradient(135deg, #312E81 0%, #4338CA 100%)" }}
      >
        <div className="max-w-2xl">
          <h1 className="text-2xl font-bold text-white mb-1">Share a Code</h1>
          <p className="text-white/60 text-sm">Help others save money with your referral code</p>
        </div>
      </div>

      <div className="max-w-2xl mx-auto px-8 py-8">
        {/* Free tier usage */}
        {isFree && me && weeklyLimit !== null && (
          <div className="mb-6 flex items-center justify-between p-4 rounded-xl bg-primary/5 border border-primary/15">
            <div>
              <p className="text-sm font-medium">Weekly posts</p>
              <p className="text-xs text-muted-foreground">{weeklyPostsUsed} of {weeklyLimit} used this week</p>
            </div>
            <div className="text-sm font-bold text-primary">{weeklyPostsUsed}/{weeklyLimit}</div>
          </div>
        )}

        {atLimit ? (
          <div className="rounded-2xl border-2 border-primary/20 bg-primary/5 p-10 text-center">
            <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-4">
              <Crown className="w-7 h-7 text-primary" />
            </div>
            <h3 className="font-bold text-xl mb-2">Weekly post limit reached</h3>
            <p className="text-muted-foreground text-sm mb-6 max-w-sm mx-auto">
              Free accounts can post {weeklyLimit} codes per week. Upgrade to Pro for unlimited posts.
            </p>
            <Link href="/upgrade">
              <Button className="gap-2 font-semibold px-8">
                <Crown className="w-4 h-4" /> Upgrade to Pro
              </Button>
            </Link>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-5">
            {/* Code — hero field */}
            <div className="p-5 rounded-xl border-2 border-primary/20 bg-primary/5 space-y-1.5">
              <Label htmlFor="code" className="text-xs font-semibold uppercase tracking-wider text-primary">
                Referral Code <span className="text-destructive">*</span>
              </Label>
              <Input
                id="code"
                placeholder="e.g. ALICE2024"
                maxLength={100}
                value={form.code}
                onChange={(e) => setForm((f) => ({ ...f, code: e.target.value.toUpperCase() }))}
                className="font-mono tracking-widest text-lg font-bold border-0 bg-transparent px-0 text-primary placeholder-primary/30 focus-visible:ring-0 h-auto"
              />
              <p className="text-xs text-muted-foreground flex items-center gap-1.5">
                <Info className="w-3 h-3" />
                Only revealed to users who claim this code
              </p>
            </div>

            {/* Title */}
            <div className="space-y-1.5">
              <Label htmlFor="title">Title <span className="text-destructive">*</span></Label>
              <Input
                id="title"
                placeholder="e.g. Robinhood — Free Stock for New Users"
                maxLength={100}
                value={form.title}
                onChange={(e) => setForm((f) => ({ ...f, title: e.target.value }))}
              />
            </div>

            {/* Description */}
            <div className="space-y-1.5">
              <Label htmlFor="description">Description <span className="text-destructive">*</span></Label>
              <Textarea
                id="description"
                placeholder="What does this code give the claimer? Any requirements?"
                maxLength={500}
                rows={3}
                value={form.description}
                onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))}
              />
            </div>

            {/* Category grid */}
            <div className="space-y-2">
              <Label>Category <span className="text-destructive">*</span></Label>
              <div className="grid grid-cols-4 sm:grid-cols-6 gap-2">
                {CATEGORIES.map(({ id }) => {
                  const active = form.category === id;
                  const color = getCategoryColor(id);
                  return (
                    <button
                      key={id}
                      type="button"
                      onClick={() => setForm((f) => ({ ...f, category: id }))}
                      className="flex flex-col items-center gap-1 py-2.5 px-1 rounded-xl border text-xs font-medium transition-all"
                      style={
                        active
                          ? { backgroundColor: color + "15", borderColor: color, color }
                          : { borderColor: "hsl(var(--border))", color: "hsl(var(--muted-foreground))" }
                      }
                    >
                      <span
                        className="w-2 h-2 rounded-full"
                        style={{ backgroundColor: active ? color : "hsl(var(--muted-foreground))" }}
                      />
                      <span className="leading-tight text-center">{id}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Max claims stepper + expiry */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label>Max Claims <span className="text-destructive">*</span></Label>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setForm((f) => ({ ...f, maxClaims: Math.max(1, f.maxClaims - 1) }))}
                    className="w-9 h-9 rounded-lg border flex items-center justify-center hover:bg-muted transition-colors"
                  >
                    <Minus className="w-3.5 h-3.5" />
                  </button>
                  <div className="flex-1 text-center text-xl font-bold text-primary">{form.maxClaims}</div>
                  <button
                    type="button"
                    onClick={() => setForm((f) => ({ ...f, maxClaims: Math.min(1000, f.maxClaims + 1) }))}
                    className="w-9 h-9 rounded-lg border flex items-center justify-center hover:bg-muted transition-colors"
                  >
                    <Plus className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              <div className="space-y-1.5">
                <Label htmlFor="expiresAt">Expiry (optional)</Label>
                <Input
                  id="expiresAt"
                  type="datetime-local"
                  value={form.expiresAt}
                  onChange={(e) => setForm((f) => ({ ...f, expiresAt: e.target.value }))}
                />
              </div>
            </div>

            <Button
              type="submit"
              className="w-full font-semibold gap-2 h-11"
              disabled={createCode.isPending}
            >
              {createCode.isPending ? "Posting…" : <><Send className="w-4 h-4" /> Post Code</>}
            </Button>
          </form>
        )}
      </div>
    </div>
  );
}

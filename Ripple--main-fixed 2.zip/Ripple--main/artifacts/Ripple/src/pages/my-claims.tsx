import { useState } from "react";
import { useGetMyClaims } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "wouter";
import { ChevronLeft, ChevronRight, List, Copy, Check, Tag } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { getCategoryColor, fmtCategory } from "@/lib/categories";

function ClaimCard({ claim }: { claim: any }) {
  const { toast } = useToast();
  const [copied, setCopied] = useState(false);
  const catColor = getCategoryColor(claim.category ?? "other");

  const handleCopy = async () => {
    await navigator.clipboard.writeText(claim.code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
    toast({ title: "Copied to clipboard!" });
  };

  return (
    <div
      className="bg-card border rounded-xl overflow-hidden hover:shadow-sm transition-shadow"
      style={{ borderLeftWidth: 3, borderLeftColor: catColor }}
    >
      <div className="p-5">
        <div className="flex items-center justify-between mb-3">
          <div
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold"
            style={{ backgroundColor: catColor + "18", color: catColor }}
          >
            <span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: catColor }} />
            {fmtCategory(claim.category ?? "other")}
          </div>
          <span className="text-xs text-muted-foreground">
            {new Date(claim.claimedAt).toLocaleDateString("en-US", { month: "short", day: "numeric" })}
          </span>
        </div>

        <h3 className="font-semibold text-base mb-3 leading-snug">{claim.codeTitle}</h3>

        <div
          className="flex items-center gap-3 px-3 py-2.5 rounded-lg"
          style={{ backgroundColor: catColor + "12" }}
        >
          <Tag className="w-3.5 h-3.5 shrink-0" style={{ color: catColor }} />
          <code
            className="text-sm font-bold tracking-widest flex-1 font-mono"
            style={{ color: catColor }}
          >
            {claim.code}
          </code>
          <button
            onClick={handleCopy}
            className="p-1.5 rounded-lg hover:bg-black/5 transition-colors"
            title="Copy code"
          >
            {copied
              ? <Check className="w-3.5 h-3.5 text-green-600" />
              : <Copy className="w-3.5 h-3.5 text-muted-foreground" />}
          </button>
        </div>
      </div>
    </div>
  );
}

export function MyClaims() {
  const [page, setPage] = useState(1);
  const { data, isLoading } = useGetMyClaims({ page, limit: 20 });

  return (
    <div>
      {/* Header */}
      <div
        className="px-8 py-8"
        style={{ background: "linear-gradient(135deg, #312E81 0%, #4338CA 100%)" }}
      >
        <div className="max-w-4xl">
          <h1 className="text-2xl font-bold text-white mb-1">My Claims</h1>
          <p className="text-white/60 text-sm">
            {data?.claims.length ? `${data.claims.length} codes claimed` : "Codes you've claimed and their revealed values"}
          </p>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-8 py-8">
        {isLoading ? (
          <div className="space-y-4">
            {Array.from({ length: 5 }).map((_, i) => (
              <div key={i} className="rounded-xl border p-5 space-y-3">
                <Skeleton className="h-4 w-24" />
                <Skeleton className="h-5 w-48" />
                <Skeleton className="h-10 w-full rounded-lg" />
              </div>
            ))}
          </div>
        ) : data?.claims.length === 0 ? (
          <div className="text-center py-20">
            <div className="w-16 h-16 rounded-2xl bg-primary/10 mx-auto flex items-center justify-center mb-4">
              <List className="w-7 h-7 text-primary" />
            </div>
            <h3 className="font-semibold text-lg mb-2">No claims yet</h3>
            <p className="text-muted-foreground text-sm mb-6">Browse codes and claim them to see their values here</p>
            <Link href="/browse">
              <Button>Browse Codes</Button>
            </Link>
          </div>
        ) : (
          <>
            <div className="grid sm:grid-cols-2 gap-4">
              {data?.claims.map((claim) => <ClaimCard key={claim.id} claim={claim} />)}
            </div>

            {data && data.totalPages > 1 && (
              <div className="flex items-center justify-between mt-8">
                <Button variant="outline" size="sm" onClick={() => setPage((p) => p - 1)} disabled={page === 1} className="gap-2">
                  <ChevronLeft className="w-4 h-4" /> Previous
                </Button>
                <span className="text-sm text-muted-foreground">Page {page} of {data.totalPages}</span>
                <Button variant="outline" size="sm" onClick={() => setPage((p) => p + 1)} disabled={page >= data.totalPages} className="gap-2">
                  Next <ChevronRight className="w-4 h-4" />
                </Button>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}

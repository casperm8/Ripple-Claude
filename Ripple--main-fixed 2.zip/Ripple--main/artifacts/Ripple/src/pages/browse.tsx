import { useState } from "react";
import { useListCodes, useGetMe } from "@workspace/api-client-react";
import { CodeCard } from "@/components/code-card";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Search, ChevronLeft, ChevronRight, X, Inbox } from "lucide-react";
import { getCategoryColor } from "@/lib/categories";

const CATEGORIES = ["Finance", "Food & Dining", "Crypto", "Technology", "Travel", "Entertainment", "Productivity", "Shopping", "Health", "Gaming", "Other"];

export function Browse() {
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");
  const [category, setCategory] = useState<string | undefined>();
  const [searchTimeout, setSearchTimeout] = useState<ReturnType<typeof setTimeout> | null>(null);

  const { data: me } = useGetMe();
  const isFree = !me || me.tier === "free";
  const requestsToday = me?.requestsToday ?? 0;
  const dailyLimit = me?.dailyRequestLimit ?? 5;
  const atDailyLimit = isFree && me && dailyLimit !== null && requestsToday >= dailyLimit;

  const { data, isLoading } = useListCodes({
    page,
    limit: 12,
    ...(debouncedSearch ? { search: debouncedSearch } : {}),
    ...(category ? { category } : {}),
  });

  const handleSearchChange = (val: string) => {
    setSearch(val);
    if (searchTimeout) clearTimeout(searchTimeout);
    const t = setTimeout(() => { setDebouncedSearch(val); setPage(1); }, 400);
    setSearchTimeout(t);
  };

  const handleCategory = (cat: string) => {
    setCategory((prev) => (prev === cat ? undefined : cat));
    setPage(1);
  };

  return (
    <div>
      {/* Page header */}
      <div
        className="px-8 py-8"
        style={{ background: "linear-gradient(135deg, #312E81 0%, #4338CA 100%)" }}
      >
        <div className="max-w-6xl mx-auto">
          <h1 className="text-2xl font-bold text-white mb-1">Browse Codes</h1>
          <p className="text-white/60 text-sm mb-5">
            {data?.total != null ? `${data.total} referral codes available` : "Discover codes shared by the community"}
          </p>

          {/* Search bar */}
          <div className="relative max-w-xl">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              type="text"
              placeholder="Search codes, brands, deals…"
              value={search}
              onChange={(e) => handleSearchChange(e.target.value)}
              className="w-full h-11 pl-10 pr-10 rounded-xl bg-white text-gray-900 placeholder-gray-400 text-sm outline-none focus:ring-2 focus:ring-white/30"
            />
            {search && (
              <button
                onClick={() => handleSearchChange("")}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-8 py-6">
        {/* Daily limit banner */}
        {atDailyLimit && (
          <div className="mb-4 px-4 py-3 rounded-xl bg-destructive/10 border border-destructive/20 text-sm text-destructive font-medium flex items-center justify-between">
            <span>Daily claim limit reached ({requestsToday}/{dailyLimit})</span>
            <Button size="sm" variant="destructive" asChild>
              <a href="/upgrade">Upgrade to Pro</a>
            </Button>
          </div>
        )}

        {/* Category filter */}
        <div className="flex flex-wrap gap-2 mb-6">
          {CATEGORIES.map((cat) => {
            const active = category === cat;
            const color = getCategoryColor(cat);
            return (
              <button
                key={cat}
                onClick={() => handleCategory(cat)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold border transition-all"
                style={
                  active
                    ? { backgroundColor: color, borderColor: color, color: "white" }
                    : { backgroundColor: color + "10", borderColor: color + "30", color }
                }
              >
                <span
                  className="w-1.5 h-1.5 rounded-full"
                  style={{ backgroundColor: active ? "white" : color }}
                />
                {cat}
              </button>
            );
          })}
          {category && (
            <button
              onClick={() => setCategory(undefined)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium border border-dashed text-muted-foreground hover:text-foreground hover:border-foreground transition-colors"
            >
              <X className="w-3 h-3" /> Clear
            </button>
          )}
        </div>

        {/* Grid */}
        {isLoading ? (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {Array.from({ length: 9 }).map((_, i) => (
              <div key={i} className="rounded-xl border p-4 space-y-3">
                <Skeleton className="h-4 w-24" />
                <Skeleton className="h-5 w-full" />
                <Skeleton className="h-4 w-3/4" />
                <Skeleton className="h-10 w-full rounded-lg" />
                <Skeleton className="h-9 w-full rounded-lg" />
              </div>
            ))}
          </div>
        ) : data?.codes.length === 0 ? (
          <div className="text-center py-20">
            <div className="w-16 h-16 rounded-2xl bg-muted mx-auto flex items-center justify-center mb-4">
              <Inbox className="w-7 h-7 text-muted-foreground" />
            </div>
            <h3 className="font-semibold text-lg mb-2">No codes found</h3>
            <p className="text-muted-foreground text-sm">
              {search ? "Try a different search term" : category ? "No codes in this category yet" : "No codes posted yet"}
            </p>
          </div>
        ) : (
          <>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {data?.codes.map((code) => (
                <CodeCard key={code.id} code={code} />
              ))}
            </div>

            {data && data.totalPages > 1 && (
              <div className="flex items-center justify-between mt-8">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setPage((p) => p - 1)}
                  disabled={page === 1}
                  className="gap-2"
                >
                  <ChevronLeft className="w-4 h-4" /> Previous
                </Button>
                <span className="text-sm text-muted-foreground">
                  Page {page} of {data.totalPages}
                </span>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setPage((p) => p + 1)}
                  disabled={page >= data.totalPages}
                  className="gap-2"
                >
                  Next <ChevronRight className="w-4 h-4" />
                </Button>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}

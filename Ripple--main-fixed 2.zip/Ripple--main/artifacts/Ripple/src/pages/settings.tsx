import { useGetMe } from "@workspace/api-client-react";
import { useUser, useClerk } from "@clerk/react";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Crown, LogOut, Shield, Zap, Tag } from "lucide-react";
import { Link } from "wouter";

export function Settings() {
  const { user } = useUser();
  const { signOut } = useClerk();
  const { data: me, isLoading } = useGetMe();

  const isPro = me?.tier === "pro";
  const requestsToday = me?.requestsToday ?? 0;
  const dailyLimit = me?.dailyRequestLimit ?? 5;
  const weeklyPostsUsed = me?.codesPostedThisWeek ?? 0;
  const weeklyLimit = me?.weeklyPostLimit ?? 2;

  const initial = (user?.fullName || user?.emailAddresses?.[0]?.emailAddress || "U")[0].toUpperCase();

  return (
    <div>
      {/* Gradient profile header */}
      <div
        className="px-8 pt-10 pb-8 flex items-end gap-6"
        style={{ background: "linear-gradient(135deg, #312E81 0%, #4338CA 100%)" }}
      >
        <div className="w-16 h-16 rounded-full bg-white/20 border-2 border-white/30 flex items-center justify-center text-white text-2xl font-bold shrink-0 overflow-hidden">
          {user?.imageUrl
            ? <img src={user.imageUrl} alt="Avatar" className="w-full h-full object-cover" />
            : initial}
        </div>
        <div className="pb-1">
          <h1 className="text-xl font-bold text-white leading-tight">{user?.fullName || "User"}</h1>
          <p className="text-white/60 text-sm">{me?.email}</p>
          <div
            className={`inline-flex items-center gap-1.5 mt-2 px-2.5 py-1 rounded-full text-xs font-semibold ${
              isPro ? "bg-yellow-400 text-yellow-900" : "bg-white/15 text-white/80"
            }`}
          >
            {isPro && <Crown className="w-3 h-3" />}
            {isPro ? "Pro Member" : "Free Tier"}
          </div>
        </div>
      </div>

      <div className="max-w-2xl mx-auto px-8 py-8 space-y-4">
        {isLoading ? (
          <div className="space-y-4">
            <Skeleton className="h-32 rounded-xl" />
            <Skeleton className="h-40 rounded-xl" />
          </div>
        ) : (
          <>
            {/* Usage limits */}
            {!isPro && (
              <div className="rounded-xl border bg-card p-6 space-y-5">
                <h3 className="font-semibold text-base">Usage limits</h3>

                {dailyLimit !== null && (
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2 text-sm font-medium">
                        <Zap className="w-3.5 h-3.5 text-primary" /> Daily claims
                      </div>
                      <span className="text-sm font-bold">{requestsToday}/{dailyLimit}</span>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div
                        className="h-full rounded-full bg-primary transition-all"
                        style={{ width: `${Math.min((requestsToday / dailyLimit) * 100, 100)}%` }}
                      />
                    </div>
                    <p className="text-xs text-muted-foreground">Resets at midnight</p>
                  </div>
                )}

                {weeklyLimit !== null && (
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2 text-sm font-medium">
                        <Tag className="w-3.5 h-3.5 text-primary" /> Weekly posts
                      </div>
                      <span className="text-sm font-bold">{weeklyPostsUsed}/{weeklyLimit}</span>
                    </div>
                    <div className="h-2 bg-muted rounded-full overflow-hidden">
                      <div
                        className="h-full rounded-full bg-primary transition-all"
                        style={{ width: `${Math.min((weeklyPostsUsed / weeklyLimit) * 100, 100)}%` }}
                      />
                    </div>
                    <p className="text-xs text-muted-foreground">Resets every Sunday</p>
                  </div>
                )}

                <div className="pt-2 border-t">
                  <Link href="/upgrade">
                    <Button className="w-full gap-2 font-semibold">
                      <Crown className="w-4 h-4" /> Upgrade to Pro — Remove all limits
                    </Button>
                  </Link>
                </div>
              </div>
            )}

            {isPro && (
              <div
                className="rounded-xl p-6 text-white"
                style={{ background: "linear-gradient(135deg, #3730A3, #5B21B6)" }}
              >
                <div className="flex items-center gap-3 mb-2">
                  <Crown className="w-5 h-5 text-yellow-300" />
                  <span className="font-semibold">Pro Plan Active</span>
                </div>
                <p className="text-sm text-white/70 mb-4">
                  Unlimited posts, unlimited claims, and no ads.
                </p>
                <Button variant="outline" size="sm" disabled className="border-white/20 text-white/60">
                  Billing portal (requires Stripe)
                </Button>
              </div>
            )}

            {/* Account info */}
            <div className="rounded-xl border bg-card p-6">
              <h3 className="font-semibold text-base mb-4">Account</h3>
              <div className="flex items-center gap-2 text-sm text-muted-foreground bg-muted/40 rounded-lg p-3">
                <Shield className="w-3.5 h-3.5 shrink-0" />
                Account created {me?.createdAt ? new Date(me.createdAt).toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" }) : "—"}
              </div>
            </div>

            {/* Sign out */}
            <div className="rounded-xl border bg-card p-6">
              <Button
                variant="outline"
                className="w-full gap-2 text-muted-foreground border-destructive/20 hover:bg-destructive/5 hover:text-destructive"
                onClick={() => signOut({ redirectUrl: "/" })}
                data-testid="btn-logout"
              >
                <LogOut className="w-4 h-4" /> Sign Out
              </Button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

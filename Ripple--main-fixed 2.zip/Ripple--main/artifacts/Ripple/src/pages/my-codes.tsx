import { useState } from "react";
import { useGetMyCodes, useGetMe } from "@workspace/api-client-react";
import { CodeCard } from "@/components/code-card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "wouter";
import { PlusCircle, ChevronLeft, ChevronRight, Tag } from "lucide-react";
import { queryClient } from "@/lib/queryClient";

export function MyCodes() {
  const [page, setPage] = useState(1);
  const { data: me } = useGetMe();
  const { data, isLoading } = useGetMyCodes({ page, limit: 12 });

  const isFree = !me || me.tier === "free";
  const weeklyPostsUsed = me?.codesPostedThisWeek ?? 0;
  const weeklyLimit = me?.weeklyPostLimit ?? 2;
  const pct = weeklyLimit ? Math.min((weeklyPostsUsed / weeklyLimit) * 100, 100) : 0;

  return (
    <div>
      {/* Header */}
      <div
        className="px-8 py-8"
        style={{ background: "linear-gradient(135deg, #312E81 0%, #4338CA 100%)" }}
      >
        <div className="max-w-6xl mx-auto flex items-end justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-white mb-1">My Codes</h1>
            <p className="text-white/60 text-sm">Codes you've shared with the community</p>
          </div>
          <Link href="/post">
            <Button className="gap-2 bg-white text-primary hover:bg-white/90 font-semibold shrink-0">
              <PlusCircle className="w-4 h-4" /> Post Code
            </Button>
          </Link>
        </div>

        {/* Weekly usage bar */}
        {isFree && me && weeklyLimit !== null && (
          <div className="max-w-6xl mx-auto mt-5">
            <div className="flex items-center justify-between mb-2 text-sm">
              <span className="text-white/70">Weekly posts</span>
              <span className="text-white font-semibold">{weeklyPostsUsed}/{weeklyLimit}</span>
            </div>
            <div className="h-1.5 bg-white/20 rounded-full overflow-hidden">
              <div
                className="h-full rounded-full bg-white transition-all"
                style={{ width: `${pct}%` }}
              />
            </div>
          </div>
        )}
      </div>

      <div className="max-w-6xl mx-auto px-8 py-8">
        {isLoading ? (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="rounded-xl border p-4 space-y-3">
                <Skeleton className="h-4 w-24" />
                <Skeleton className="h-5 w-full" />
                <Skeleton className="h-4 w-3/4" />
                <Skeleton className="h-9 w-full rounded-lg" />
              </div>
            ))}
          </div>
        ) : data?.codes.length === 0 ? (
          <div className="text-center py-20">
            <div className="w-16 h-16 rounded-2xl bg-primary/10 mx-auto flex items-center justify-center mb-4">
              <Tag className="w-7 h-7 text-primary" />
            </div>
            <h3 className="font-semibold text-lg mb-2">No codes posted yet</h3>
            <p className="text-muted-foreground text-sm mb-6">Share your first referral code with the community</p>
            <Link href="/post">
              <Button className="gap-2">
                <PlusCircle className="w-4 h-4" /> Post Your First Code
              </Button>
            </Link>
          </div>
        ) : (
          <>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {data?.codes.map((code) => (
                <CodeCard
                  key={code.id}
                  code={code}
                  onDelete={() => queryClient.invalidateQueries({ queryKey: ["/api/users/me/codes"] })}
                />
              ))}
            </div>

            {data && data.totalPages > 1 && (
              <div className="flex items-center justify-between mt-8">
                <Button variant="outline" size="sm" onClick={() => setPage((p) => p - 1)} disabled={page === 1} className="gap-2">
                  <ChevronLeft className="w-4 h-4" /> Previous
                </Button>
                <span className="text-sm text-muted-foreground">Page {page} of {data.totalPages}</span>
                <Button variant="outline" size="sm" onClick={() => setPage((p) => p + 1)} disabled={page >= data.totalPages} className="gap-2">
                  Next <ChevronRight className="w-4 h-4" />
                </Button>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}

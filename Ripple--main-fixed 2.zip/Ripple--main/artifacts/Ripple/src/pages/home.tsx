import { Link } from "wouter";
import { useGetStats } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { ArrowRight, Tag, Shield, Zap, Lock, Check } from "lucide-react";
import { getCategoryColor } from "@/lib/categories";

function RippleMark({ size = 28, color = "#0EA5E9" }: { size?: number; color?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 28 28" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="14" cy="14" r="4" fill={color} />
      <circle cx="14" cy="14" r="7.5" stroke={color} strokeWidth="1.8" opacity="0.7" />
      <circle cx="14" cy="14" r="11.5" stroke={color} strokeWidth="1.4" opacity="0.4" />
      <circle cx="14" cy="14" r="13.5" stroke={color} strokeWidth="1" opacity="0.2" />
    </svg>
  );
}

export function Home() {
  const { data: stats } = useGetStats();

  return (
    <div className="min-h-[100dvh] bg-background">
      {/* Nav */}
      <header className="border-b bg-white/90 backdrop-blur sticky top-0 z-10">
        <div className="max-w-6xl mx-auto px-6 h-14 flex items-center justify-between">
          <div className="flex items-center gap-2.5 text-primary">
            <RippleMark size={26} color="#0EA5E9" />
            <span style={{ fontFamily: "'Nunito', sans-serif", fontWeight: 800, fontSize: "1.1rem" }}>Ripple</span>
          </div>
          <div className="flex items-center gap-2">
            <Link href="/sign-in">
              <Button variant="ghost" size="sm" className="text-muted-foreground">Sign In</Button>
            </Link>
            <Link href="/sign-up">
              <Button size="sm" className="font-semibold">Get Started</Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Hero — gradient */}
      <section
        className="relative overflow-hidden text-white"
        style={{ background: "linear-gradient(135deg, #0369A1 0%, #0284C7 50%, #0EA5E9 100%)" }}
      >
        {/* Subtle grid overlay */}
        <div
          className="absolute inset-0 opacity-[0.04]"
          style={{
            backgroundImage: "linear-gradient(white 1px, transparent 1px), linear-gradient(90deg, white 1px, transparent 1px)",
            backgroundSize: "40px 40px",
          }}
        />
        <div className="relative max-w-6xl mx-auto px-6 py-24 text-center">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/15 text-white/90 text-sm font-medium mb-8 border border-white/20">
            <Zap className="w-3.5 h-3.5 text-yellow-300" />
            The community referral marketplace
          </div>
          <h1 className="text-5xl md:text-6xl font-extrabold tracking-tight mb-6 leading-tight" style={{ fontFamily: "'Nunito', sans-serif" }}>
            Find codes.<br />Share codes.
          </h1>
          <p className="text-xl text-white/70 max-w-xl mx-auto mb-10">
            Post your referral codes, set claim limits, and let the community discover real deals — verified and fair.
          </p>
          <div className="flex items-center justify-center gap-4 flex-wrap">
            <Link href="/sign-up">
              <Button size="lg" className="gap-2 font-semibold px-8 bg-white text-primary hover:bg-white/90 h-12">
                Start for Free <ArrowRight className="w-4 h-4" />
              </Button>
            </Link>
            <Link href="/browse">
              <Button size="lg" variant="outline" className="border-white/30 text-white hover:bg-white/10 h-12">
                Browse Codes
              </Button>
            </Link>
          </div>

          {/* Stats */}
          {stats && (
            <div className="mt-14 flex items-center justify-center gap-10 md:gap-16">
              {[
                { val: stats.totalCodes.toLocaleString(), label: "Active Codes" },
                { val: stats.totalClaims.toLocaleString(), label: "Total Claims" },
                { val: `${stats.topCategories.length}+`, label: "Categories" },
              ].map(({ val, label }, i) => (
                <div key={i} className="text-center">
                  <div className="text-3xl font-extrabold text-white">{val}</div>
                  <div className="text-sm text-white/55 mt-0.5">{label}</div>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* How it works */}
      <section className="max-w-6xl mx-auto px-6 py-20">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-3">How it works</h2>
          <p className="text-muted-foreground">Three steps to start saving</p>
        </div>
        <div className="grid md:grid-cols-3 gap-8">
          {[
            { step: "01", icon: Tag, title: "Post your code", desc: "Share any referral or affiliate code. Set a claim limit so only the right number of people can use it." },
            { step: "02", icon: Shield, title: "Verified accounts", desc: "Strict identity verification ensures fair access. No duplicate accounts, no abuse." },
            { step: "03", icon: Zap, title: "Claim and save", desc: "Browse by category, claim what you need, and the actual code is revealed instantly." },
          ].map(({ step, icon: Icon, title, desc }) => (
            <div key={step} className="relative">
              <div className="text-5xl font-black text-muted/50 mb-4 select-none">{step}</div>
              <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-4">
                <Icon className="w-5 h-5 text-primary" />
              </div>
              <h3 className="font-semibold text-lg mb-2">{title}</h3>
              <p className="text-muted-foreground text-sm leading-relaxed">{desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Categories */}
      {stats && stats.topCategories.length > 0 && (
        <section className="border-y bg-muted/30">
          <div className="max-w-6xl mx-auto px-6 py-16">
            <h2 className="text-2xl font-bold text-center mb-8">Popular categories</h2>
            <div className="flex flex-wrap gap-3 justify-center">
              {stats.topCategories.map((cat) => {
                const color = getCategoryColor(cat.category);
                return (
                  <Link href="/browse" key={cat.category}>
                    <div
                      className="flex items-center gap-2 px-4 py-2 rounded-full border cursor-pointer hover:shadow-sm transition-shadow text-sm font-medium"
                      style={{
                        borderColor: color + "40",
                        backgroundColor: color + "10",
                        color,
                      }}
                    >
                      <span className="w-2 h-2 rounded-full" style={{ backgroundColor: color }} />
                      {cat.category}
                      <span className="ml-1 text-xs opacity-60">{cat.count}</span>
                    </div>
                  </Link>
                );
              })}
            </div>
          </div>
        </section>
      )}

      {/* Pricing */}
      <section className="max-w-6xl mx-auto px-6 py-20">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-3">Simple pricing</h2>
          <p className="text-muted-foreground">Start free, upgrade when you need more</p>
        </div>
        <div className="grid md:grid-cols-2 gap-6 max-w-2xl mx-auto">
          {/* Free */}
          <div className="border-2 rounded-2xl p-8 bg-card">
            <div className="font-semibold text-base mb-1 text-muted-foreground">Free</div>
            <div className="text-5xl font-extrabold mb-1">$0</div>
            <div className="text-sm text-muted-foreground mb-8">Forever free</div>
            <ul className="space-y-3 mb-8">
              {["5 code claims / day", "2 code posts / week", "All categories", "Ad-supported"].map((f) => (
                <li key={f} className="flex items-center gap-3 text-sm text-muted-foreground">
                  <div className="w-4 h-4 rounded-full bg-muted flex items-center justify-center shrink-0">
                    <div className="w-1.5 h-1.5 rounded-full bg-muted-foreground" />
                  </div>
                  {f}
                </li>
              ))}
            </ul>
            <Link href="/sign-up">
              <Button variant="outline" className="w-full">Get Started Free</Button>
            </Link>
          </div>

          {/* Pro */}
          <div
            className="rounded-2xl p-8 text-white relative overflow-hidden"
            style={{ background: "linear-gradient(135deg, #0284C7, #0EA5E9)" }}
          >
            <div className="absolute top-4 right-4 px-2.5 py-1 bg-yellow-400 text-yellow-900 text-xs font-bold rounded-full">
              Popular
            </div>
            <div className="font-semibold text-base mb-1 text-white/80">Pro</div>
            <div className="text-5xl font-extrabold mb-1">$9.99</div>
            <div className="text-sm text-white/60 mb-8">per month</div>
            <ul className="space-y-3 mb-8">
              {["Unlimited daily claims", "Unlimited weekly posts", "No ads", "Priority support"].map((f) => (
                <li key={f} className="flex items-center gap-3 text-sm text-white/85">
                  <Check className="w-4 h-4 text-yellow-300 shrink-0" />
                  {f}
                </li>
              ))}
            </ul>
            <Link href="/sign-up">
              <Button className="w-full bg-white text-primary hover:bg-white/90 font-semibold">
                Upgrade to Pro
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t">
        <div className="max-w-6xl mx-auto px-6 py-6 flex items-center justify-between text-sm text-muted-foreground">
          <div className="flex items-center gap-2 text-foreground">
            <RippleMark size={18} color="#0EA5E9" />
            <span style={{ fontFamily: "'Nunito', sans-serif", fontWeight: 700 }}>Ripple</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Lock className="w-3 h-3" /> Strict 1 account per person
          </div>
        </div>
      </footer>
    </div>
  );
}

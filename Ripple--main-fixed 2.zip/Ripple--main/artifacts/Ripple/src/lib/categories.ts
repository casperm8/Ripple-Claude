export const CATEGORY_COLORS: Record<string, string> = {
  finance: "#0EA5E9",
  "food & dining": "#EF4444",
  food: "#EF4444",
  crypto: "#F59E0B",
  technology: "#6366F1",
  tech: "#6366F1",
  travel: "#10B981",
  entertainment: "#8B5CF6",
  productivity: "#3B82F6",
  shopping: "#F59E0B",
  health: "#14B8A6",
  gaming: "#EC4899",
  beauty: "#EC4899",
  other: "#64748B",
};

export function getCategoryColor(cat: string): string {
  return CATEGORY_COLORS[cat.toLowerCase()] ?? "#64748B";
}

export function fmtCategory(cat: string): string {
  return cat
    .split(/[\s_-]/)
    .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
    .join(" ");
}

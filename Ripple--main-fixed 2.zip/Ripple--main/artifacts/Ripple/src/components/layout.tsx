import { Link, useLocation } from "wouter";
import { useUser, useClerk } from "@clerk/react";
import { Button } from "@/components/ui/button";
import { LayoutDashboard, PlusCircle, Tag, List, Settings, Crown, LogOut, Zap } from "lucide-react";
import { useGetMe } from "@workspace/api-client-react";

function RippleLogo({ size = 28 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 28 28" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="14" cy="14" r="4" fill="white" />
      <circle cx="14" cy="14" r="7.5" stroke="white" strokeWidth="1.8" opacity="0.75" />
      <circle cx="14" cy="14" r="11.5" stroke="white" strokeWidth="1.4" opacity="0.4" />
      <circle cx="14" cy="14" r="13.5" stroke="white" strokeWidth="1" opacity="0.2" />
    </svg>
  );
}

export function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const { user } = useUser();
  const { signOut } = useClerk();
  const { data: me } = useGetMe();
  const isPro = me?.tier === "pro";

  const navItems = [
    { href: "/browse", label: "Browse", icon: LayoutDashboard },
    { href: "/post", label: "Post Code", icon: PlusCircle },
    { href: "/my-codes", label: "My Codes", icon: Tag },
    { href: "/my-claims", label: "My Claims", icon: List },
    { href: "/settings", label: "Settings", icon: Settings },
  ];

  const initial = (user?.fullName || user?.emailAddresses?.[0]?.emailAddress || "U")[0].toUpperCase();

  return (
    <div className="min-h-[100dvh] flex flex-col md:flex-row bg-background">
      {/* Sidebar */}
      <aside
        className="w-full md:w-60 flex flex-col md:min-h-screen flex-shrink-0"
        style={{ background: "linear-gradient(180deg, #0369A1 0%, #0284C7 40%, #0EA5E9 100%)" }}
      >
        {/* Logo */}
        <div className="p-5 pb-4">
          <Link href="/browse" className="flex items-center gap-2.5 font-bold text-lg text-white tracking-tight">
            <div className="w-7 h-7 rounded-lg bg-white/20 flex items-center justify-center">
              <RippleLogo size={22} />
            </div>
            <span style={{ fontFamily: "'Nunito', sans-serif", fontWeight: 800 }}>Ripple</span>
          </Link>
        </div>

        {/* Nav */}
        <nav className="flex-1 px-3 space-y-0.5">
          {navItems.map((item) => {
            const isActive = location === item.href || location.startsWith(item.href + "/");
            return (
              <Link key={item.href} href={item.href}>
                <button
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-100 text-left ${
                    isActive
                      ? "bg-white text-[#0284C7] shadow-sm"
                      : "text-white/75 hover:text-white hover:bg-white/10"
                  }`}
                  data-testid={`nav-${item.label.toLowerCase().replace(/\s+/g, "-")}`}
                >
                  <item.icon className="w-4 h-4 shrink-0" />
                  {item.label}
                </button>
              </Link>
            );
          })}
        </nav>

        {/* Upgrade nudge */}
        {!isPro && (
          <div className="mx-3 mb-3 p-3 rounded-xl bg-white/10 border border-white/15">
            <div className="flex items-center gap-2 mb-1.5">
              <Zap className="w-3.5 h-3.5 text-yellow-300" />
              <span className="text-xs font-semibold text-white">Go Pro</span>
            </div>
            <p className="text-xs text-white/60 mb-2.5 leading-relaxed">Unlimited codes & claims. No ads.</p>
            <Link href="/upgrade">
              <button className="w-full py-1.5 rounded-lg bg-white text-[#0284C7] text-xs font-semibold hover:bg-white/90 transition-colors">
                Upgrade
              </button>
            </Link>
          </div>
        )}

        {/* User */}
        <div className="p-3 border-t border-white/15">
          <div className="flex items-center justify-between px-1">
            <div className="flex items-center gap-2 overflow-hidden">
              <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center text-white text-sm font-bold shrink-0 overflow-hidden">
                {user?.imageUrl
                  ? <img src={user.imageUrl} alt="Avatar" className="w-full h-full object-cover" />
                  : initial}
              </div>
              <div className="truncate min-w-0">
                <p className="text-sm font-medium text-white truncate leading-tight">{user?.fullName || "User"}</p>
                {isPro && (
                  <span className="text-[10px] text-yellow-300 font-semibold flex items-center gap-0.5">
                    <Crown className="w-2.5 h-2.5" /> Pro
                  </span>
                )}
              </div>
            </div>
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8 text-white/60 hover:text-white hover:bg-white/10"
              onClick={() => signOut({ redirectUrl: "/" })}
              title="Sign out"
              data-testid="btn-logout"
            >
              <LogOut className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </aside>

      {/* Main */}
      <main className="flex-1 overflow-y-auto min-h-[100dvh]">
        {children}
      </main>
    </div>
  );
}

import { useState } from "react";
import { Code, ClaimResult, useClaimCode, useDeleteCode } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Check, Copy, Trash2, Tag } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import { getCategoryColor, fmtCategory } from "@/lib/categories";

export function CodeCard({
  code,
  showActions = true,
  onDelete,
}: {
  code: Code;
  showActions?: boolean;
  onDelete?: () => void;
}) {
  const { toast } = useToast();
  const claimMutation = useClaimCode();
  const deleteMutation = useDeleteCode();
  const [revealedValue, setRevealedValue] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  const catColor = getCategoryColor(code.category);
  const isAvailable = code.claimCount < code.maxClaims && !code.isExpired;
  const slotsLeft = code.maxClaims - code.claimCount;
  const pct = Math.min((code.claimCount / code.maxClaims) * 100, 100);
  const isFull = slotsLeft <= 0;

  const handleClaim = () => {
    claimMutation.mutate(
      { id: code.id },
      {
        onSuccess: (data: ClaimResult) => {
          setRevealedValue(data.code);
          toast({ title: "Code Unlocked!", description: "Your code is ready to use." });
          queryClient.invalidateQueries({ queryKey: ["/api/codes"] });
          queryClient.invalidateQueries({ queryKey: ["/api/users/me/codes"] });
          queryClient.invalidateQueries({ queryKey: ["/api/users/me/claims"] });
        },
        onError: (err: any) => {
          toast({ title: "Claim Failed", description: err.message || "Failed to claim code.", variant: "destructive" });
        },
      }
    );
  };

  const handleCopy = async () => {
    if (revealedValue) {
      await navigator.clipboard.writeText(revealedValue);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
      toast({ title: "Copied!" });
    }
  };

  const handleDelete = () => {
    if (!confirm("Remove this code?")) return;
    deleteMutation.mutate(
      { id: code.id },
      {
        onSuccess: () => {
          toast({ title: "Code Deleted" });
          if (onDelete) onDelete();
          queryClient.invalidateQueries({ queryKey: ["/api/users/me/codes"] });
          queryClient.invalidateQueries({ queryKey: ["/api/codes"] });
        },
      }
    );
  };

  return (
    <div
      className="flex flex-col bg-card border rounded-xl overflow-hidden hover:shadow-md transition-shadow duration-200"
      style={{ borderLeftWidth: 3, borderLeftColor: catColor }}
    >
      <div className="flex-1 p-4 space-y-3">
        {/* Top row */}
        <div className="flex items-center justify-between gap-2">
          <div
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold"
            style={{ backgroundColor: catColor + "18", color: catColor }}
          >
            <span
              className="w-1.5 h-1.5 rounded-full"
              style={{ backgroundColor: catColor }}
            />
            {fmtCategory(code.category)}
          </div>
          <div className="flex items-center gap-2">
            {!isFull && !code.isExpired && (
              <span className="text-xs text-muted-foreground font-medium">{slotsLeft} left</span>
            )}
            {(isFull || code.isExpired) && (
              <span className="text-xs font-semibold text-destructive">
                {code.isExpired ? "Expired" : "Full"}
              </span>
            )}
            {code.isMine && showActions && (
              <button
                onClick={handleDelete}
                disabled={deleteMutation.isPending}
                className="p-1 rounded hover:bg-destructive/10 text-muted-foreground hover:text-destructive transition-colors"
                data-testid={`btn-delete-${code.id}`}
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>

        {/* Title + description */}
        <div>
          <h3 className="font-semibold text-base leading-snug line-clamp-1 text-foreground mb-1">
            {code.title}
          </h3>
          <p className="text-sm text-muted-foreground line-clamp-2 leading-relaxed">
            {code.description}
          </p>
        </div>

        {/* Revealed / placeholder */}
        {revealedValue ? (
          <div
            className="flex items-center gap-2 px-3 py-2 rounded-lg"
            style={{ backgroundColor: catColor + "12" }}
          >
            <Tag className="w-3.5 h-3.5 shrink-0" style={{ color: catColor }} />
            <code
              className="text-sm font-bold tracking-widest flex-1"
              style={{ color: catColor }}
            >
              {revealedValue}
            </code>
            <button
              onClick={handleCopy}
              className="p-1 rounded hover:bg-black/5 transition-colors"
            >
              {copied
                ? <Check className="w-3.5 h-3.5 text-green-600" />
                : <Copy className="w-3.5 h-3.5 text-muted-foreground" />}
            </button>
          </div>
        ) : code.isClaimedByMe ? (
          <div
            className="px-3 py-2 rounded-lg text-xs font-semibold text-center"
            style={{ backgroundColor: catColor + "10", color: catColor }}
          >
            Already claimed — see My Claims
          </div>
        ) : (
          <div className="h-9 flex items-center justify-center rounded-lg border border-dashed bg-muted/30">
            <span className="text-muted-foreground font-mono tracking-widest text-xs">••••••••</span>
          </div>
        )}

        {/* Progress */}
        <div className="space-y-1">
          <div className="h-1.5 bg-muted rounded-full overflow-hidden">
            <div
              className="h-full rounded-full transition-all"
              style={{
                width: `${pct}%`,
                backgroundColor: isFull ? "hsl(var(--destructive))" : catColor,
              }}
            />
          </div>
          <div className="flex justify-between text-xs text-muted-foreground">
            <span>{code.posterName}</span>
            <span>{code.claimCount}/{code.maxClaims} claimed</span>
          </div>
        </div>
      </div>

      {/* Claim button */}
      {showActions && !revealedValue && !code.isClaimedByMe && !code.isMine && (
        <div className="px-4 pb-4">
          <Button
            className="w-full font-semibold text-sm h-9"
            disabled={!isAvailable || claimMutation.isPending}
            onClick={handleClaim}
            data-testid={`btn-claim-${code.id}`}
            style={isAvailable ? { backgroundColor: catColor, color: "white" } : {}}
          >
            {claimMutation.isPending ? "Unlocking…" : isAvailable ? "Get Code" : "Unavailable"}
          </Button>
        </div>
      )}
    </div>
  );
}

/**
 * Clerk appearance config regression tests
 *
 * These tests lock down the values in clerkAppearance (App.tsx) so that
 * any future edit — to colorPrimary, gradients, cardBox styles, or border-radius
 * — surfaces as a failing test before the change ships.
 *
 * Covered:
 *  1. Sign-in page background matches the sky-blue gradient defined in AuthPageShell
 *  2. Clerk card wrapper (cardBox) keeps its rounded-2xl border-radius override
 *  3. Clerk card wrapper (cardBox) keeps its shadow-lg shadow override
 *  4. Sign-up page background matches the same sky-blue gradient (AuthPageShell is shared)
 *  5. Sign-up card wrapper (cardBox) keeps its rounded-2xl border-radius override
 *  6. Sign-up card wrapper (cardBox) keeps its shadow-lg shadow override
 *
 * Run: pnpm --filter @workspace/referral-hub test:e2e
 */

import { test, expect } from "@playwright/test";

/* ── helpers ─────────────────────────────────────────────────────────────── */

/**
 * Return the value of a CSS custom-property-aware computed style property
 * for the first element matching `selector`.
 */
async function computedStyle(
  page: import("@playwright/test").Page,
  selector: string,
  property: string,
): Promise<string> {
  return page.evaluate(
    ([sel, prop]) => {
      const el = document.querySelector(sel);
      if (!el) return "";
      return window.getComputedStyle(el).getPropertyValue(prop).trim();
    },
    [selector, property] as [string, string],
  );
}

/* ── Sign-in page appearance ─────────────────────────────────────────────── */

test.describe("Clerk appearance config — sign-in page", () => {
  test.beforeEach(async ({ page }) => {
    await page.goto("/sign-in");
    await page.waitForLoadState("networkidle");
  });

  test("background matches the expected sky-blue gradient", async ({ page }) => {
    /**
     * AuthPageShell wraps the Clerk <SignIn> component with an inline-style gradient:
     * linear-gradient(135deg, #0369A1 0%, #0284C7 50%, #0EA5E9 100%).
     * Browsers normalize inline hex colours to rgb() when reading them back via
     * element.style, so we locate the shell div by its distinctive Tailwind class
     * (min-h-[100dvh]) and check getComputedStyle().backgroundImage for the 135deg
     * direction and the three stop colours expressed as their RGB equivalents:
     *   #0369A1 → rgb(3, 105, 161)
     *   #0284C7 → rgb(2, 132, 199)
     *   #0EA5E9 → rgb(14, 165, 233)
     */
    const bgImage = await page.evaluate(() => {
      const shell = Array.from(document.querySelectorAll<HTMLElement>("div")).find((d) =>
        d.classList.contains("min-h-\\[100dvh\\]") || d.className.includes("min-h-[100dvh]"),
      );
      if (!shell) return "";
      return window.getComputedStyle(shell).backgroundImage;
    });

    expect(
      bgImage,
      "Auth shell backgroundImage should be a 135deg linear-gradient. " +
        "If empty, AuthPageShell was removed or the shell div class changed.",
    ).toMatch(/linear-gradient/);

    expect(bgImage, "Gradient should be angled at 135deg").toMatch(/135deg/);

    // Colour stops as RGB — browser normalises hex to rgb() when reading computed styles
    expect(bgImage, "Gradient should contain the first stop #0369A1 (rgb 3 105 161)").toMatch(
      /3,\s*105,\s*161/,
    );
    expect(bgImage, "Gradient should contain the mid-stop #0284C7 (rgb 2 132 199)").toMatch(
      /2,\s*132,\s*199/,
    );
    expect(bgImage, "Gradient should contain the end-stop #0EA5E9 (rgb 14 165 233)").toMatch(
      /14,\s*165,\s*233/,
    );
  });

  test("Clerk cardBox has correct border-radius override (rounded-2xl)", async ({ page }) => {
    /**
     * clerkAppearance.elements.cardBox is set to include "rounded-2xl" (border-radius: 1rem).
     * If that class is removed or replaced the card will revert to Clerk's default radius.
     * This test checks the computed border-radius of the element that Clerk wraps its card in.
     */
    const radius = await page.evaluate(() => {
      const divs = Array.from(document.querySelectorAll<HTMLElement>("div"));
      for (const d of divs) {
        if (
          d.classList.contains("rounded-2xl") &&
          (d.classList.contains("shadow-lg") || d.classList.contains("overflow-hidden"))
        ) {
          return window.getComputedStyle(d).borderRadius;
        }
      }
      return "";
    });

    // rounded-2xl = border-radius: 1rem = 16px
    expect(
      radius,
      'cardBox border-radius should be 1rem / 16px (Tailwind rounded-2xl). ' +
        'If empty, the "rounded-2xl" class was removed from clerkAppearance.elements.cardBox.',
    ).toMatch(/^(1rem|16px)$/);
  });

  test("Clerk cardBox has shadow-lg shadow override", async ({ page }) => {
    /**
     * clerkAppearance.elements.cardBox includes "shadow-lg" so the Clerk card
     * floats above the gradient background. If that class is removed the card
     * will appear flat. This test verifies the box-shadow is non-zero.
     */
    const shadow = await page.evaluate(() => {
      const divs = Array.from(document.querySelectorAll<HTMLElement>("div"));
      for (const d of divs) {
        if (d.classList.contains("shadow-lg")) {
          return window.getComputedStyle(d).boxShadow;
        }
      }
      return "";
    });

    expect(
      shadow,
      'cardBox box-shadow should be non-empty (Tailwind shadow-lg). ' +
        'If empty, the "shadow-lg" class was removed from clerkAppearance.elements.cardBox.',
    ).not.toBe("");

    // Tailwind shadow-lg produces a multi-value box-shadow; it must not be "none"
    expect(shadow, "cardBox box-shadow should not be 'none'").not.toBe("none");
  });

  test("primary action button colour matches colorPrimary (#0EA5E9)", async ({ page }) => {
    /**
     * clerkAppearance.variables.colorPrimary is set to "#0EA5E9" (sky-500).
     * Clerk uses this to tint the primary "Continue" button. Changing colorPrimary
     * without updating this test will make the regression visible.
     */
    const btnBg = await page.evaluate(() => {
      const btn = document.querySelector<HTMLElement>(
        'button[data-localization-key="formButtonPrimary"]',
      );
      if (!btn) return "";
      return window.getComputedStyle(btn).backgroundColor;
    });

    // #0EA5E9 → rgb(14, 165, 233)
    expect(
      btnBg,
      "Clerk primary button background should be sky-blue #0EA5E9 (rgb 14 165 233). " +
        "If this fails, clerkAppearance.variables.colorPrimary was changed.",
    ).toContain("14, 165, 233");
  });
});

/* ── Sign-up page appearance ─────────────────────────────────────────────── */

test.describe("Clerk appearance config — sign-up page", () => {
  test.beforeEach(async ({ page }) => {
    await page.goto("/sign-up");
    await page.waitForLoadState("networkidle");
  });

  test("background matches the expected sky-blue gradient", async ({ page }) => {
    /**
     * AuthPageShell is shared between <SignIn> and <SignUp>. It applies the same
     * inline-style gradient: linear-gradient(135deg, #0369A1 0%, #0284C7 50%, #0EA5E9 100%).
     * This test mirrors the sign-in assertion so that removing or modifying
     * AuthPageShell on either route is caught immediately.
     *
     * Browsers normalize inline hex colours to rgb() when reading them back via
     * element.style, so we locate the shell div by its distinctive Tailwind class
     * (min-h-[100dvh]) and check getComputedStyle().backgroundImage for the 135deg
     * direction and the three stop colours expressed as their RGB equivalents:
     *   #0369A1 → rgb(3, 105, 161)
     *   #0284C7 → rgb(2, 132, 199)
     *   #0EA5E9 → rgb(14, 165, 233)
     */
    const bgImage = await page.evaluate(() => {
      const shell = Array.from(document.querySelectorAll<HTMLElement>("div")).find((d) =>
        d.classList.contains("min-h-\\[100dvh\\]") || d.className.includes("min-h-[100dvh]"),
      );
      if (!shell) return "";
      return window.getComputedStyle(shell).backgroundImage;
    });

    expect(
      bgImage,
      "Auth shell backgroundImage should be a 135deg linear-gradient. " +
        "If empty, AuthPageShell was removed or the shell div class changed.",
    ).toMatch(/linear-gradient/);

    expect(bgImage, "Gradient should be angled at 135deg").toMatch(/135deg/);

    // Colour stops as RGB — browser normalises hex to rgb() when reading computed styles
    expect(bgImage, "Gradient should contain the first stop #0369A1 (rgb 3 105 161)").toMatch(
      /3,\s*105,\s*161/,
    );
    expect(bgImage, "Gradient should contain the mid-stop #0284C7 (rgb 2 132 199)").toMatch(
      /2,\s*132,\s*199/,
    );
    expect(bgImage, "Gradient should contain the end-stop #0EA5E9 (rgb 14 165 233)").toMatch(
      /14,\s*165,\s*233/,
    );
  });

  test("Clerk cardBox has correct border-radius override (rounded-2xl)", async ({ page }) => {
    /**
     * clerkAppearance.elements.cardBox is set to include "rounded-2xl" (border-radius: 1rem).
     * The same shared clerkAppearance object is applied to <SignUp> via ClerkProvider.
     * This test ensures the class is not accidentally dropped from cardBox for the sign-up route.
     */
    const radius = await page.evaluate(() => {
      const divs = Array.from(document.querySelectorAll<HTMLElement>("div"));
      for (const d of divs) {
        if (
          d.classList.contains("rounded-2xl") &&
          (d.classList.contains("shadow-lg") || d.classList.contains("overflow-hidden"))
        ) {
          return window.getComputedStyle(d).borderRadius;
        }
      }
      return "";
    });

    // rounded-2xl = border-radius: 1rem = 16px
    expect(
      radius,
      'cardBox border-radius should be 1rem / 16px (Tailwind rounded-2xl). ' +
        'If empty, the "rounded-2xl" class was removed from clerkAppearance.elements.cardBox.',
    ).toMatch(/^(1rem|16px)$/);
  });

  test("Clerk cardBox has shadow-lg shadow override", async ({ page }) => {
    /**
     * clerkAppearance.elements.cardBox includes "shadow-lg" so the Clerk card
     * floats above the gradient background. The sign-up page shares this config
     * via the same clerkAppearance object passed to ClerkProvider.
     */
    const shadow = await page.evaluate(() => {
      const divs = Array.from(document.querySelectorAll<HTMLElement>("div"));
      for (const d of divs) {
        if (d.classList.contains("shadow-lg")) {
          return window.getComputedStyle(d).boxShadow;
        }
      }
      return "";
    });

    expect(
      shadow,
      'cardBox box-shadow should be non-empty (Tailwind shadow-lg). ' +
        'If empty, the "shadow-lg" class was removed from clerkAppearance.elements.cardBox.',
    ).not.toBe("");

    // Tailwind shadow-lg produces a multi-value box-shadow; it must not be "none"
    expect(shadow, "cardBox box-shadow should not be 'none'").not.toBe("none");
  });

  test("primary action button colour matches colorPrimary (#0EA5E9)", async ({ page }) => {
    /**
     * clerkAppearance.variables.colorPrimary is set to "#0EA5E9" (sky-500).
     * Clerk uses this to tint the primary action button on the sign-up form.
     * The sign-up step may render the button under a different data-localization-key
     * than the sign-in form (e.g. "signUp.start.action__signUp" vs "formButtonPrimary"),
     * so we try the generic key first and fall back to any <button type="submit">
     * inside the Clerk card before giving up.
     *
     * Changing clerkAppearance.variables.colorPrimary without updating this assertion
     * will make the regression visible.
     */
    const btnBg = await page.evaluate(() => {
      // Try the generic Clerk primary-button key used across all form steps
      let btn = document.querySelector<HTMLElement>(
        'button[data-localization-key="formButtonPrimary"]',
      );
      // Fall back to any submit button rendered inside the Clerk card wrapper
      if (!btn) {
        btn = document.querySelector<HTMLElement>(
          '[class*="cl-card"] button[type="submit"], [class*="cl-cardBox"] button[type="submit"]',
        );
      }
      if (!btn) return "";
      return window.getComputedStyle(btn).backgroundColor;
    });

    // #0EA5E9 → rgb(14, 165, 233)
    expect(
      btnBg,
      "Clerk primary button background on /sign-up should be sky-blue #0EA5E9 (rgb 14 165 233). " +
        "If this fails, clerkAppearance.variables.colorPrimary was changed.",
    ).toContain("14, 165, 233");
  });
});

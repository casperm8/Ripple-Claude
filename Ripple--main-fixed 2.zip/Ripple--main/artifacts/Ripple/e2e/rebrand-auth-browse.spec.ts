/**
 * Ripple rebrand — auth and browse screen regression tests
 *
 * Verifies that after the Ripple rebrand the sign-in page and browse
 * (authenticated) flow still work correctly, with the correct sky-blue
 * appearance and no missing-style console errors.
 *
 * Run: pnpm --filter @workspace/referral-hub test:e2e
 *
 * The browse-screen test requires a signed-in user.  It uses Clerk's
 * Testing Token mechanism (CLERK_TESTING_TOKEN env var) if available; when
 * running locally against a dev instance without a token it skips the
 * authenticated section and only checks the public redirect behaviour.
 */

import { test, expect, type Page } from "@playwright/test";

/* ── helpers ─────────────────────────────────────────────────────────────── */

/** Assert no console error mentions missing CSS, fonts or styles. */
async function expectNoStyleErrors(page: Page) {
  const errors: string[] = [];
  page.on("console", (msg) => {
    if (msg.type() === "error") {
      const text = msg.text();
      if (/font|css|style|404|failed to load/i.test(text)) {
        errors.push(text);
      }
    }
  });
  // small settle so any pending network errors surface
  await page.waitForTimeout(500);
  expect(
    errors,
    `Style/font console errors found: ${errors.join(" | ")}`,
  ).toHaveLength(0);
}

/** Compute the background-color or gradient of the first element matching the selector. */
async function getBackground(page: Page, selector: string): Promise<string> {
  return page.evaluate((sel) => {
    const el = document.querySelector(sel);
    if (!el) return "";
    const style = window.getComputedStyle(el);
    return style.background || style.backgroundImage || style.backgroundColor;
  }, selector);
}

/* ── Landing page ────────────────────────────────────────────────────────── */

test.describe("Landing page — Ripple branding", () => {
  test("shows Ripple logo, sky-blue hero and correct CTAs", async ({ page }) => {
    const consoleErrors: string[] = [];
    page.on("console", (msg) => {
      if (msg.type() === "error") consoleErrors.push(msg.text());
    });

    await page.goto("/");
    await page.waitForLoadState("networkidle");

    /* Ripple logo / wordmark in sticky nav */
    await expect(page.getByRole("link", { name: /ripple/i }).first()).toBeVisible();

    /* Hero headline */
    await expect(page.getByText("Find codes.", { exact: false })).toBeVisible();
    await expect(page.getByText("Share codes.", { exact: false })).toBeVisible();

    /* CTAs */
    await expect(page.getByRole("link", { name: /sign in/i })).toBeVisible();
    await expect(page.getByRole("link", { name: /get started/i })).toBeVisible();

    /* Sky-blue hero gradient — the hero section has an inline style */
    const heroStyle = await page.evaluate(() => {
      const sections = Array.from(document.querySelectorAll("section"));
      for (const s of sections) {
        if ((s as HTMLElement).style?.background?.includes("0369A1")) return (s as HTMLElement).style.background;
      }
      return "";
    });
    expect(heroStyle, "Hero section should have sky-blue gradient").toContain("0369A1");

    /* No missing-style errors */
    const styleErrors = consoleErrors.filter((e) =>
      /font|css|style|404|failed to load/i.test(e),
    );
    expect(styleErrors, `Unexpected style errors: ${styleErrors}`).toHaveLength(0);
  });
});

/* ── Sign-in page ────────────────────────────────────────────────────────── */

test.describe("Sign-in page — Ripple branding", () => {
  test("loads with sky-blue background and Clerk form", async ({ page }) => {
    const consoleErrors: string[] = [];
    page.on("console", (msg) => {
      if (msg.type() === "error") consoleErrors.push(msg.text());
    });

    await page.goto("/sign-in");
    await page.waitForLoadState("networkidle");

    /* Clerk card/form is rendered */
    await expect(page.getByText(/sign in to ripple/i)).toBeVisible();
    await expect(page.getByLabel(/email address/i)).toBeVisible();
    await expect(page.getByRole("button", { name: /continue/i })).toBeVisible();

    /* Auth shell has sky-blue gradient */
    const shellStyle = await page.evaluate(() => {
      const divs = Array.from(document.querySelectorAll("div"));
      for (const d of divs) {
        if ((d as HTMLElement).style?.background?.includes("0369A1")) {
          return (d as HTMLElement).style.background;
        }
      }
      return "";
    });
    expect(shellStyle, "Auth shell should have sky-blue gradient").toContain("0369A1");

    /* Clerk Continue button inherits sky-blue primary colour */
    const btnBg = await page.evaluate(() => {
      const btn = document.querySelector('button[data-localization-key="formButtonPrimary"]') as HTMLElement | null;
      if (!btn) return "";
      return window.getComputedStyle(btn).backgroundColor;
    });
    // sky-blue #0EA5E9 → rgb(14, 165, 233)
    expect(btnBg, "Continue button should have sky-blue background").toContain("14, 165, 233");

    /* No style/font errors */
    const styleErrors = consoleErrors.filter((e) =>
      /font|css|style|404|failed to load/i.test(e),
    );
    expect(styleErrors, `Unexpected style errors: ${styleErrors}`).toHaveLength(0);
  });

  test("Sign Up link navigates to /sign-up", async ({ page }) => {
    await page.goto("/sign-in");
    await page.waitForLoadState("networkidle");
    await page.getByRole("link", { name: /sign up/i }).click();
    await expect(page).toHaveURL(/sign-up/);
  });
});

/* ── Protected-route redirect ─────────────────────────────────────────────── */

test.describe("Browse route — auth protection", () => {
  test("unauthenticated access to /browse redirects to /sign-in", async ({ page }) => {
    await page.goto("/browse");
    await page.waitForLoadState("networkidle");
    await expect(page).toHaveURL(/sign-in/);
  });
});

/* ── Authenticated browse (sidebar) ──────────────────────────────────────── */

test.describe("Browse page — Ripple sidebar (authenticated)", () => {
  /**
   * This test uses Clerk's backend-signed testing token to bypass the auth UI
   * and land directly on the protected /browse route.
   *
   * When CLERK_TESTING_TOKEN is not set (local dev), the test is skipped
   * rather than failing, because the auth UI path is already covered by the
   * sign-in page tests above and by the E2E runTest verification.
   */
  test("sidebar shows Ripple logo, sky-blue gradient and nav items", async ({ page }) => {
    const token = process.env.CLERK_TESTING_TOKEN;
    if (!token) {
      test.skip(true, "CLERK_TESTING_TOKEN not set — skip authenticated browse test");
      return;
    }

    /* Inject Clerk testing token cookie before navigating */
    await page.context().addCookies([
      { name: "__clerk_testing_token", value: token, domain: "localhost", path: "/" },
    ]);

    await page.goto("/browse");
    await page.waitForLoadState("networkidle");

    /* Should stay on /browse (not redirect) */
    await expect(page).toHaveURL(/browse/);

    /* Sidebar is visible */
    const sidebar = page.locator("aside");
    await expect(sidebar).toBeVisible();

    /* "Ripple" wordmark in sidebar */
    await expect(sidebar.getByText("Ripple")).toBeVisible();

    /* Sky-blue sidebar gradient */
    const sidebarStyle = await page.evaluate(() => {
      const aside = document.querySelector("aside") as HTMLElement | null;
      return aside ? aside.style.background : "";
    });
    expect(sidebarStyle, "Sidebar should have sky-blue gradient").toContain("0369A1");

    /* Nav items */
    for (const label of ["Browse", "Post Code", "My Codes", "My Claims", "Settings"]) {
      await expect(sidebar.getByText(label)).toBeVisible();
    }

    /* No style/font console errors */
    const errors: string[] = [];
    page.on("console", (msg) => {
      if (msg.type() === "error" && /font|css|style|404|failed to load/i.test(msg.text())) {
        errors.push(msg.text());
      }
    });
    await page.waitForTimeout(500);
    expect(errors).toHaveLength(0);
  });
});

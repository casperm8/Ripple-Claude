import { useRef, useEffect, type RefObject } from "react";

/**
 * Signals to the PDF exporter that this board component is fully rendered
 * and ready to be captured.
 *
 * Sets `data-export-ready="1"` on the returned ref's element after `delayMs`
 * milliseconds. The exporter's `waitForBoardReady` watches for this attribute
 * via a MutationObserver and proceeds as soon as it appears, instead of
 * relying on a fixed timer.
 *
 * Choose `delayMs` based on the board's animation budget:
 *  - Static boards (no animations): 50 ms
 *  - Boards whose animations freeze in PDF-export mode: 200–300 ms
 *  - Boards with one-shot animations that must complete: animation duration + buffer
 *
 * Usage:
 *   const exportRef = useBoardExportReady(200);
 *   return <div ref={exportRef} style={S.page}>…</div>;
 */
export function useBoardExportReady(delayMs = 200): RefObject<HTMLDivElement | null> {
  const ref = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const timer = setTimeout(() => {
      if (ref.current) {
        ref.current.dataset.exportReady = "1";
      }
    }, delayMs);

    return () => {
      clearTimeout(timer);
    };
  }, [delayMs]);

  return ref;
}

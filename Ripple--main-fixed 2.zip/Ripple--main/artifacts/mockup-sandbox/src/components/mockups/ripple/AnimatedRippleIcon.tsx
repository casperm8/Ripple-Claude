import { motion, useReducedMotion } from "framer-motion";
import type { Easing } from "framer-motion";
import { usePdfExport } from "../../../PdfExportContext";

export const RIPPLE_RINGS = [
  { delay: 0,    baseOpacity: 0.7  },
  { delay: 0.55, baseOpacity: 0.35 },
  { delay: 1.1,  baseOpacity: 0.15 },
];

export function getRippleRingProps(
  baseOpacity: number,
  delay: number,
  shouldReduce: boolean | null,
) {
  return {
    animate: shouldReduce
      ? { opacity: baseOpacity }
      : { opacity: [baseOpacity, baseOpacity * 0.12, baseOpacity], scale: [1, 1.07, 1] },
    transition: { duration: 2.6, delay, repeat: Infinity, ease: "easeInOut" as Easing },
    style: { transformBox: "fill-box" as const, transformOrigin: "center" as const },
  };
}

const RING_R_FRACTIONS  = [0.57, 0.86, 0.96];
const RING_SW_FRACTIONS = [0.071, 0.054, 0.036];

export default function AnimatedRippleIcon({
  color = "#0EA5E9",
  size = 28,
}: {
  color?: string;
  size?: number;
}) {
  const shouldReduce = useReducedMotion();
  const isPdfExport = usePdfExport();
  const cx = size / 2;
  const cy = size / 2;
  const coreR = size * 0.143;

  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} fill="none">
      <circle cx={cx} cy={cy} r={coreR} fill={color} />
      {RIPPLE_RINGS.map((ring, i) => {
        const { animate, transition, style } = getRippleRingProps(ring.baseOpacity, ring.delay, shouldReduce || isPdfExport);
        return (
          <motion.circle
            key={i}
            cx={cx}
            cy={cy}
            r={(size / 2) * RING_R_FRACTIONS[i]}
            stroke={color}
            strokeWidth={size * RING_SW_FRACTIONS[i]}
            style={style}
            animate={animate}
            transition={transition}
          />
        );
      })}
    </svg>
  );
}

import { motion, useReducedMotion } from "framer-motion";
import AnimatedRippleIcon, { RIPPLE_RINGS, getRippleRingProps } from "./AnimatedRippleIcon";
import { useBoardExportReady } from "../../../hooks/useBoardExportReady";
import { usePdfExport } from "../../../PdfExportContext";

const S: Record<string, React.CSSProperties> = {
  page: {
    background: "#F0FAFF",
    fontFamily: "'Inter', sans-serif",
    color: "#0F172A",
    minHeight: "100vh",
    padding: "48px 56px",
    boxSizing: "border-box",
  },
  header: {
    marginBottom: 48,
    borderBottom: "2px solid #E0F4FE",
    paddingBottom: 24,
  },
  boardLabel: {
    fontFamily: "'Nunito', sans-serif",
    fontSize: 13,
    fontWeight: 700,
    letterSpacing: "0.12em",
    textTransform: "uppercase" as const,
    color: "#0EA5E9",
    marginBottom: 8,
  },
  boardTitle: {
    fontFamily: "'Nunito', sans-serif",
    fontSize: 32,
    fontWeight: 800,
    color: "#0F172A",
    margin: 0,
    lineHeight: 1.2,
  },
  sectionTitle: {
    fontFamily: "'Nunito', sans-serif",
    fontSize: 16,
    fontWeight: 800,
    color: "#0F172A",
    marginBottom: 16,
    marginTop: 0,
    letterSpacing: "-0.01em",
  },
  card: {
    background: "#FFFFFF",
    borderRadius: 16,
    padding: 28,
    boxShadow: "0 1px 3px rgba(14,165,233,0.08), 0 4px 16px rgba(14,165,233,0.06)",
  },
};

function AnimatedWordmarkSVG({
  color = "#0EA5E9",
  textColor = "#0F172A",
  size = 1,
}: {
  color?: string;
  textColor?: string;
  size?: number;
}) {
  const shouldReduce = useReducedMotion();
  const isPdfExport = usePdfExport();
  const rings = [
    { r: 12, sw: 2.5, ...RIPPLE_RINGS[0] },
    { r: 20, sw: 2,   ...RIPPLE_RINGS[1] },
    { r: 23, sw: 1.2, ...RIPPLE_RINGS[2] },
  ];
  return (
    <svg
      width={220 * size}
      height={48 * size}
      viewBox="0 0 220 48"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <circle cx="24" cy="24" r="6" fill={color} />
      {rings.map((ring, i) => {
        const { animate, transition, style } = getRippleRingProps(ring.baseOpacity, ring.delay, shouldReduce || isPdfExport);
        return (
          <motion.circle
            key={i}
            cx="24"
            cy="24"
            r={ring.r}
            stroke={color}
            strokeWidth={ring.sw}
            style={style}
            animate={animate}
            transition={transition}
          />
        );
      })}
      <text
        x="54"
        y="34"
        fontFamily="'Nunito', sans-serif"
        fontWeight="800"
        fontSize="28"
        fill={textColor}
        letterSpacing="-0.5"
      >
        Ripple
      </text>
    </svg>
  );
}

function StaticWordmarkSVG({
  color = "#0EA5E9",
  textColor = "#0F172A",
  size = 1,
}: {
  color?: string;
  textColor?: string;
  size?: number;
}) {
  return (
    <svg
      width={220 * size}
      height={48 * size}
      viewBox="0 0 220 48"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <circle cx="24" cy="24" r="6" fill={color} />
      <circle cx="24" cy="24" r="12" stroke={color} strokeWidth="2.5" opacity="0.7" />
      <circle cx="24" cy="24" r="20" stroke={color} strokeWidth="2" opacity="0.35" />
      <circle cx="24" cy="24" r="23" stroke={color} strokeWidth="1.2" opacity="0.15" />
      <text x="54" y="34" fontFamily="'Nunito', sans-serif" fontWeight="800" fontSize="28" fill={textColor} letterSpacing="-0.5">Ripple</text>
    </svg>
  );
}

function AnimatedIconTextSVG({
  color = "#0EA5E9",
  textColor = "#0F172A",
}: {
  color?: string;
  textColor?: string;
}) {
  const shouldReduce = useReducedMotion();
  const isPdfExport = usePdfExport();
  const rings = [
    { r: 14, sw: 2.5, ...RIPPLE_RINGS[0] },
    { r: 23, sw: 2,   ...RIPPLE_RINGS[1] },
  ];
  return (
    <svg
      width="160"
      height="56"
      viewBox="0 0 160 56"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <circle cx="28" cy="28" r="7" fill={color} />
      {rings.map((ring, i) => {
        const { animate, transition, style } = getRippleRingProps(ring.baseOpacity, ring.delay, shouldReduce || isPdfExport);
        return (
          <motion.circle
            key={i}
            cx="28"
            cy="28"
            r={ring.r}
            stroke={color}
            strokeWidth={ring.sw}
            style={style}
            animate={animate}
            transition={transition}
          />
        );
      })}
      <text x="60" y="24" fontFamily="'Nunito', sans-serif" fontWeight="800" fontSize="22" fill={textColor} letterSpacing="-0.3">Ripple</text>
      <text x="60" y="40" fontFamily="'Inter', sans-serif" fontWeight="400" fontSize="11" fill="#64748B" letterSpacing="0.08em">REFERRAL COMMUNITY</text>
    </svg>
  );
}

function AnimatedAppIconSVG({ size = 80 }: { size?: number }) {
  const shouldReduce = useReducedMotion();
  const isPdfExport = usePdfExport();
  const s = size / 80;
  const cx = size / 2;
  const cy = size / 2;
  const rings = [
    { r: 19 * s, sw: 3 * s,   ...RIPPLE_RINGS[0] },
    { r: 30 * s, sw: 2.5 * s, ...RIPPLE_RINGS[1] },
    { r: 38 * s, sw: 2 * s,   ...RIPPLE_RINGS[2] },
  ];
  return (
    <svg
      width={size}
      height={size}
      viewBox={`0 0 ${size} ${size}`}
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <rect width={size} height={size} rx={18 * s} fill="url(#appGradAnim)" />
      <defs>
        <linearGradient
          id="appGradAnim"
          x1="0"
          y1="0"
          x2={size}
          y2={size}
          gradientUnits="userSpaceOnUse"
        >
          <stop offset="0%" stopColor="#38BDF8" />
          <stop offset="100%" stopColor="#0284C7" />
        </linearGradient>
      </defs>
      <circle cx={cx} cy={cy} r={10 * s} fill="white" />
      {rings.map((ring, i) => {
        const { animate, transition, style } = getRippleRingProps(ring.baseOpacity, ring.delay, shouldReduce || isPdfExport);
        return (
          <motion.circle
            key={i}
            cx={cx}
            cy={cy}
            r={ring.r}
            stroke="white"
            strokeWidth={ring.sw}
            style={style}
            animate={animate}
            transition={transition}
          />
        );
      })}
    </svg>
  );
}

const svgSource = `<svg width="220" height="48" viewBox="0 0 220 48"
     fill="none" xmlns="http://www.w3.org/2000/svg">
  <!-- Ripple icon mark -->
  <circle cx="24" cy="24" r="6" fill="#0EA5E9"/>
  <circle cx="24" cy="24" r="12" stroke="#0EA5E9"
          stroke-width="2.5" opacity="0.7"/>
  <circle cx="24" cy="24" r="20" stroke="#0EA5E9"
          stroke-width="2" opacity="0.35"/>
  <circle cx="24" cy="24" r="23" stroke="#0EA5E9"
          stroke-width="1.2" opacity="0.15"/>
  <!-- Wordmark -->
  <text x="54" y="34"
        font-family="'Nunito', sans-serif"
        font-weight="800" font-size="28"
        fill="#0F172A" letter-spacing="-0.5">Ripple</text>
</svg>`;

function LogoOnBg({
  bg,
  label,
  children,
}: {
  bg: string;
  label: string;
  children: React.ReactNode;
}) {
  return (
    <div>
      <div
        style={{
          background: bg,
          borderRadius: 12,
          padding: 28,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          minHeight: 80,
          boxShadow:
            bg === "#FFFFFF" ? "inset 0 0 0 1px rgba(0,0,0,0.06)" : undefined,
        }}
      >
        {children}
      </div>
      <p
        style={{
          fontFamily: "'Inter', sans-serif",
          fontSize: 11,
          color: "#94A3B8",
          marginTop: 6,
          marginBottom: 0,
          textAlign: "center" as const,
        }}
      >
        {label}
      </p>
    </div>
  );
}

export default function Board2LogoConcepts() {
  const exportRef = useBoardExportReady(500);
  return (
    <div ref={exportRef} style={S.page}>
      <div style={S.header}>
        <div style={S.boardLabel}>Board 2 of 4 — Ripple Brand Kit</div>
        <h1 style={S.boardTitle}>Logo Concepts</h1>
      </div>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "1fr 1fr",
          gap: 24,
          marginBottom: 32,
        }}
      >
        <div style={S.card}>
          <h3 style={S.sectionTitle}>A — Wordmark</h3>
          <p
            style={{
              fontFamily: "'Inter', sans-serif",
              fontSize: 13,
              color: "#64748B",
              marginBottom: 20,
              marginTop: 0,
            }}
          >
            Full logotype: ripple-wave icon + "Ripple" in Nunito 800
          </p>
          <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
            <LogoOnBg bg="#FFFFFF" label="On white">
              <AnimatedWordmarkSVG />
            </LogoOnBg>
            <LogoOnBg bg="#0F172A" label="On dark">
              <AnimatedWordmarkSVG textColor="#FFFFFF" />
            </LogoOnBg>
            <LogoOnBg bg="#0EA5E9" label="On primary">
              <AnimatedWordmarkSVG color="#FFFFFF" textColor="#FFFFFF" />
            </LogoOnBg>
          </div>
        </div>

        <div style={S.card}>
          <h3 style={S.sectionTitle}>B — Icon + Text Horizontal Lockup</h3>
          <p
            style={{
              fontFamily: "'Inter', sans-serif",
              fontSize: 13,
              color: "#64748B",
              marginBottom: 20,
              marginTop: 0,
            }}
          >
            Larger icon with tagline — for headers and profile sections
          </p>
          <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
            <LogoOnBg bg="#F0FAFF" label="On brand background">
              <AnimatedIconTextSVG />
            </LogoOnBg>
            <LogoOnBg bg="#0F172A" label="On dark">
              <AnimatedIconTextSVG color="#38BDF8" textColor="#F8FAFC" />
            </LogoOnBg>
            <LogoOnBg bg="#FFFFFF" label="On white">
              <AnimatedIconTextSVG />
            </LogoOnBg>
          </div>
        </div>
      </div>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "1fr 1fr",
          gap: 24,
          marginBottom: 32,
        }}
      >
        <div style={S.card}>
          <h3 style={S.sectionTitle}>C — Icon Only Mark</h3>
          <p
            style={{
              fontFamily: "'Inter', sans-serif",
              fontSize: 13,
              color: "#64748B",
              marginBottom: 20,
              marginTop: 0,
            }}
          >
            Concentric arcs / ripple motif — standalone mark and favicon
          </p>
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "1fr 1fr 1fr",
              gap: 12,
              marginBottom: 20,
            }}
          >
            <LogoOnBg bg="#FFFFFF" label="On white">
              <AnimatedRippleIcon size={56} />
            </LogoOnBg>
            <LogoOnBg bg="#F0FAFF" label="On bg">
              <AnimatedRippleIcon size={56} />
            </LogoOnBg>
            <LogoOnBg bg="#0F172A" label="On dark">
              <AnimatedRippleIcon color="#38BDF8" size={56} />
            </LogoOnBg>
          </div>
          <div style={{ borderTop: "1px solid #F1F5F9", paddingTop: 16 }}>
            <p
              style={{
                fontFamily: "'Inter', sans-serif",
                fontSize: 11,
                color: "#94A3B8",
                marginBottom: 10,
                marginTop: 0,
                letterSpacing: "0.06em",
                textTransform: "uppercase" as const,
              }}
            >
              32px Favicon Preview
            </p>
            <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
              <div
                style={{
                  background: "#FFFFFF",
                  padding: 4,
                  borderRadius: 4,
                  boxShadow: "0 1px 3px rgba(0,0,0,0.1)",
                }}
              >
                <AnimatedRippleIcon size={32} />
              </div>
              <div
                style={{ background: "#0F172A", padding: 4, borderRadius: 4 }}
              >
                <AnimatedRippleIcon color="#38BDF8" size={32} />
              </div>
              <div
                style={{
                  background: "#F0FAFF",
                  padding: 4,
                  borderRadius: 4,
                  boxShadow: "inset 0 0 0 1px rgba(0,0,0,0.06)",
                }}
              >
                <AnimatedRippleIcon size={32} />
              </div>
              <span
                style={{
                  fontFamily: "'Inter', sans-serif",
                  fontSize: 12,
                  color: "#94A3B8",
                }}
              >
                32 × 32px
              </span>
            </div>
          </div>
        </div>

        <div style={S.card}>
          <h3 style={S.sectionTitle}>D — Rounded-Square App Icon</h3>
          <p
            style={{
              fontFamily: "'Inter', sans-serif",
              fontSize: 13,
              color: "#64748B",
              marginBottom: 20,
              marginTop: 0,
            }}
          >
            iOS/Android app store icon — gradient background with white ripple
            mark
          </p>
          <div
            style={{
              display: "flex",
              gap: 24,
              alignItems: "flex-start",
              marginBottom: 20,
            }}
          >
            <div style={{ textAlign: "center" as const }}>
              <AnimatedAppIconSVG size={120} />
              <p
                style={{
                  fontFamily: "'Inter', sans-serif",
                  fontSize: 11,
                  color: "#94A3B8",
                  margin: "8px 0 0",
                }}
              >
                120 × 120px
              </p>
            </div>
            <div style={{ textAlign: "center" as const }}>
              <AnimatedAppIconSVG size={80} />
              <p
                style={{
                  fontFamily: "'Inter', sans-serif",
                  fontSize: 11,
                  color: "#94A3B8",
                  margin: "8px 0 0",
                }}
              >
                80 × 80px
              </p>
            </div>
            <div style={{ textAlign: "center" as const }}>
              <AnimatedAppIconSVG size={48} />
              <p
                style={{
                  fontFamily: "'Inter', sans-serif",
                  fontSize: 11,
                  color: "#94A3B8",
                  margin: "8px 0 0",
                }}
              >
                48 × 48px
              </p>
            </div>
            <div style={{ textAlign: "center" as const }}>
              <AnimatedAppIconSVG size={32} />
              <p
                style={{
                  fontFamily: "'Inter', sans-serif",
                  fontSize: 11,
                  color: "#94A3B8",
                  margin: "8px 0 0",
                }}
              >
                32 × 32px
              </p>
            </div>
          </div>
          <div style={{ background: "#F8FAFC", borderRadius: 10, padding: 12 }}>
            <p
              style={{
                fontFamily: "'Inter', sans-serif",
                fontSize: 11,
                color: "#64748B",
                margin: 0,
              }}
            >
              Gradient: <strong>#38BDF8 → #0284C7</strong> (135°) · Corner
              radius: 22.5% · Mark: white
            </p>
          </div>
        </div>
      </div>

      <div style={{ marginBottom: 24 }}>
        <h2
          style={{
            fontFamily: "'Nunito', sans-serif",
            fontSize: 18,
            fontWeight: 800,
            color: "#0F172A",
            marginBottom: 16,
            marginTop: 0,
          }}
        >
          Design Tokens — Export
        </h2>
        <div
          style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 24 }}
        >
          <div style={S.card}>
            <h3
              style={{
                fontFamily: "'Nunito', sans-serif",
                fontWeight: 700,
                fontSize: 13,
                color: "#64748B",
                letterSpacing: "0.08em",
                textTransform: "uppercase" as const,
                marginBottom: 12,
                marginTop: 0,
              }}
            >
              CSS Custom Properties
            </h3>
            <pre
              style={{
                background: "#0F172A",
                color: "#7DD3FC",
                borderRadius: 10,
                padding: 14,
                fontSize: 11,
                lineHeight: 1.7,
                overflowX: "auto" as const,
                fontFamily: "'JetBrains Mono', monospace",
                margin: 0,
                whiteSpace: "pre-wrap" as const,
              }}
            >{`:root {
  --ripple-primary:      #0EA5E9;
  --ripple-primary-dark: #0369A1;
  --ripple-accent:       #F97316;
  --ripple-bg:           #F0FAFF;
  --ripple-surface:      #FFFFFF;
  --ripple-text:         #0F172A;
  --ripple-font-display: 'Nunito', sans-serif;
  --ripple-font-body:    'Inter', sans-serif;
  --ripple-radius-sm:    8px;
  --ripple-radius-md:    12px;
  --ripple-radius-lg:    20px;
  --ripple-radius-xl:    28px;
  /* App icon gradient */
  --ripple-icon-grad-from: #38BDF8;
  --ripple-icon-grad-to:   #0284C7;
  --ripple-icon-radius:    22.5%; /* ~18px on 80px icon */
}`}</pre>
          </div>
          <div style={S.card}>
            <h3
              style={{
                fontFamily: "'Nunito', sans-serif",
                fontWeight: 700,
                fontSize: 13,
                color: "#64748B",
                letterSpacing: "0.08em",
                textTransform: "uppercase" as const,
                marginBottom: 12,
                marginTop: 0,
              }}
            >
              Tailwind Config — theme.extend
            </h3>
            <pre
              style={{
                background: "#0F172A",
                color: "#86EFAC",
                borderRadius: 10,
                padding: 14,
                fontSize: 11,
                lineHeight: 1.7,
                overflowX: "auto" as const,
                fontFamily: "'JetBrains Mono', monospace",
                margin: 0,
                whiteSpace: "pre-wrap" as const,
              }}
            >{`// tailwind.config.ts
export default {
  theme: {
    extend: {
      colors: {
        ripple: {
          primary: '#0EA5E9',
          'primary-dark': '#0369A1',
          accent:  '#F97316',
          bg:      '#F0FAFF',
          surface: '#FFFFFF',
          text:    '#0F172A',
        },
      },
      fontFamily: {
        display: ["'Nunito'", 'sans-serif'],
        body:    ["'Inter'",  'sans-serif'],
      },
      borderRadius: {
        'ripple-sm': '8px',
        'ripple-md': '12px',
        'ripple-lg': '20px',
        'ripple-xl': '28px',
      },
      backgroundImage: {
        'ripple-icon': 'linear-gradient(135deg,#38BDF8,#0284C7)',
      },
    },
  },
};`}</pre>
          </div>
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 24 }}>
        <div style={S.card}>
          <h3 style={S.sectionTitle}>Single-Color / Monochrome Versions</h3>
          <p
            style={{
              fontFamily: "'Inter', sans-serif",
              fontSize: 13,
              color: "#64748B",
              marginBottom: 20,
              marginTop: 0,
            }}
          >
            For print, embossing, single-ink contexts
          </p>
          <div
            style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}
          >
            <LogoOnBg bg="#FFFFFF" label="Monochrome black">
              <StaticWordmarkSVG color="#0F172A" textColor="#0F172A" size={0.8} />
            </LogoOnBg>
            <LogoOnBg bg="#0F172A" label="Monochrome white">
              <StaticWordmarkSVG color="#FFFFFF" textColor="#FFFFFF" size={0.8} />
            </LogoOnBg>
            <LogoOnBg bg="#E2E8F0" label="Greyscale mid">
              <StaticWordmarkSVG color="#64748B" textColor="#334155" size={0.8} />
            </LogoOnBg>
            <LogoOnBg bg="#0EA5E9" label="Brand blue (single)">
              <StaticWordmarkSVG color="#FFFFFF" textColor="#FFFFFF" size={0.8} />
            </LogoOnBg>
          </div>
        </div>

        <div style={S.card}>
          <h3 style={S.sectionTitle}>SVG Source — Wordmark (Export Ready)</h3>
          <p
            style={{
              fontFamily: "'Inter', sans-serif",
              fontSize: 13,
              color: "#64748B",
              marginBottom: 16,
              marginTop: 0,
            }}
          >
            Copy and paste the inline SVG into your project
          </p>
          <pre
            style={{
              background: "#0F172A",
              color: "#7DD3FC",
              borderRadius: 10,
              padding: 16,
              fontSize: 11,
              lineHeight: 1.7,
              overflowX: "auto" as const,
              fontFamily: "'JetBrains Mono', monospace",
              margin: 0,
              whiteSpace: "pre-wrap" as const,
            }}
          >
            {svgSource}
          </pre>
        </div>
      </div>
    </div>
  );
}

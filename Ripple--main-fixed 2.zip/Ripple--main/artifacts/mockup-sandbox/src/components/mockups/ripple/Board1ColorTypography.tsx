import { useBoardExportReady } from "../../../hooks/useBoardExportReady";

const tokens = {
  primary: "#0EA5E9",
  accent: "#F97316",
  background: "#F0FAFF",
  surface: "#FFFFFF",
  text: "#0F172A",
  neutrals: [
    { shade: "50",  hex: "#F0FAFF", oklch: "oklch(97% 0.02 220)" },
    { shade: "100", hex: "#E0F4FE", oklch: "oklch(94% 0.04 220)" },
    { shade: "200", hex: "#BAE6FD", oklch: "oklch(88% 0.07 220)" },
    { shade: "300", hex: "#7DD3FC", oklch: "oklch(80% 0.11 220)" },
    { shade: "400", hex: "#38BDF8", oklch: "oklch(72% 0.15 220)" },
    { shade: "500", hex: "#0EA5E9", oklch: "oklch(67% 0.19 220)" },
    { shade: "600", hex: "#0284C7", oklch: "oklch(57% 0.18 220)" },
    { shade: "700", hex: "#0369A1", oklch: "oklch(48% 0.16 220)" },
    { shade: "800", hex: "#075985", oklch: "oklch(39% 0.13 220)" },
    { shade: "900", hex: "#0C4A6E", oklch: "oklch(30% 0.10 220)" },
  ],
};

const S: Record<string, React.CSSProperties> = {
  page: {
    background: "#F0FAFF",
    fontFamily: "'Inter', sans-serif",
    color: "#0F172A",
    minHeight: "100vh",
    padding: "48px 56px",
    boxSizing: "border-box",
  },
  header: {
    marginBottom: 48,
    borderBottom: "2px solid #E0F4FE",
    paddingBottom: 24,
  },
  boardLabel: {
    fontFamily: "'Nunito', sans-serif",
    fontSize: 13,
    fontWeight: 700,
    letterSpacing: "0.12em",
    textTransform: "uppercase" as const,
    color: "#0EA5E9",
    marginBottom: 8,
  },
  boardTitle: {
    fontFamily: "'Nunito', sans-serif",
    fontSize: 32,
    fontWeight: 800,
    color: "#0F172A",
    margin: 0,
    lineHeight: 1.2,
  },
  sectionTitle: {
    fontFamily: "'Nunito', sans-serif",
    fontSize: 18,
    fontWeight: 800,
    color: "#0F172A",
    marginBottom: 20,
    marginTop: 0,
    letterSpacing: "-0.01em",
  },
  section: {
    marginBottom: 48,
  },
  grid2: {
    display: "grid",
    gridTemplateColumns: "1fr 1fr",
    gap: 32,
    marginBottom: 48,
  },
  card: {
    background: "#FFFFFF",
    borderRadius: 16,
    padding: 24,
    boxShadow: "0 1px 3px rgba(14,165,233,0.08), 0 4px 16px rgba(14,165,233,0.06)",
  },
};

function SwatchRow({ hex, label, oklch, textDark = true }: { hex: string; label: string; oklch: string; textDark?: boolean }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 16, marginBottom: 14 }}>
      <div style={{
        width: 56, height: 56, borderRadius: 12,
        background: hex,
        boxShadow: "inset 0 0 0 1px rgba(0,0,0,0.08)",
        flexShrink: 0,
      }} />
      <div>
        <div style={{ fontFamily: "'Nunito', sans-serif", fontWeight: 700, fontSize: 15, color: "#0F172A" }}>{label}</div>
        <div style={{ fontFamily: "'Inter', sans-serif", fontSize: 13, color: "#475569", fontWeight: 500 }}>{hex}</div>
        <div style={{ fontFamily: "'Inter', sans-serif", fontSize: 12, color: "#94A3B8" }}>{oklch}</div>
      </div>
    </div>
  );
}

function NeutralRamp() {
  return (
    <div style={S.section}>
      <h3 style={S.sectionTitle}>Neutral Scale — Tinted toward Primary Hue 220</h3>
      <div style={{ display: "flex", borderRadius: 16, overflow: "hidden", boxShadow: "0 2px 12px rgba(14,165,233,0.10)" }}>
        {tokens.neutrals.map((n) => {
          const isDark = parseInt(n.shade) >= 600;
          return (
            <div key={n.shade} style={{
              flex: 1,
              background: n.hex,
              padding: "20px 8px 16px",
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              gap: 4,
            }}>
              <span style={{
                fontFamily: "'Nunito', sans-serif",
                fontWeight: 800,
                fontSize: 13,
                color: isDark ? "rgba(255,255,255,0.9)" : "#0F172A",
              }}>{n.shade}</span>
              <span style={{
                fontFamily: "'Inter', sans-serif",
                fontSize: 10,
                color: isDark ? "rgba(255,255,255,0.6)" : "#475569",
                writingMode: "vertical-rl" as const,
                textOrientation: "mixed" as const,
                letterSpacing: "0.04em",
              }}>{n.hex}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function TypeSpecimen() {
  const typeRows = [
    { role: "Display", font: "Nunito", weight: 800, size: 48, text: "Find codes. Share codes.", note: "display / 48px / 800" },
    { role: "H1", font: "Nunito", weight: 700, size: 36, text: "Every referral creates a ripple.", note: "h1 / 36px / 700" },
    { role: "H2", font: "Nunito", weight: 700, size: 28, text: "Join the community today.", note: "h2 / 28px / 700" },
    { role: "H3", font: "Nunito", weight: 600, size: 22, text: "Your referral codes, all in one place.", note: "h3 / 22px / 600" },
    { role: "Body", font: "Inter", weight: 400, size: 16, text: "Share your unique codes with the community and start earning rewards together.", note: "body / 16px / 400" },
    { role: "Small", font: "Inter", weight: 400, size: 14, text: "Use this code at checkout to save 20% on your first order.", note: "small / 14px / 400" },
    { role: "Caption", font: "Inter", weight: 500, size: 12, text: "REFERRAL CODE • EXPIRES IN 30 DAYS", note: "caption / 12px / 500 uppercase" },
  ];

  return (
    <div style={{ ...S.card, marginBottom: 48 }}>
      <h3 style={{ ...S.sectionTitle, marginBottom: 8 }}>Type Specimen</h3>
      <p style={{ fontFamily: "'Inter', sans-serif", fontSize: 13, color: "#64748B", marginBottom: 28, marginTop: 0 }}>
        Display &amp; headings: <strong>Nunito</strong> — Body &amp; UI: <strong>Inter</strong>
      </p>
      <div style={{ display: "flex", flexDirection: "column", gap: 0 }}>
        {typeRows.map((row, i) => (
          <div key={row.role} style={{
            padding: "18px 0",
            borderBottom: i < typeRows.length - 1 ? "1px solid #F1F5F9" : "none",
            display: "grid",
            gridTemplateColumns: "90px 1fr 180px",
            gap: 16,
            alignItems: "baseline",
          }}>
            <span style={{
              fontFamily: "'Inter', sans-serif",
              fontSize: 11,
              fontWeight: 600,
              letterSpacing: "0.08em",
              textTransform: "uppercase" as const,
              color: "#94A3B8",
              alignSelf: "center",
            }}>{row.role}</span>
            <span style={{
              fontFamily: `'${row.font}', sans-serif`,
              fontWeight: row.weight,
              fontSize: row.size,
              lineHeight: 1.2,
              color: "#0F172A",
              letterSpacing: row.role === "Caption" ? "0.1em" : undefined,
              textTransform: row.role === "Caption" ? "uppercase" as const : undefined,
            }}>{row.text}</span>
            <span style={{
              fontFamily: "'Inter', sans-serif",
              fontSize: 11,
              color: "#94A3B8",
              alignSelf: "center",
              textAlign: "right" as const,
            }}>{row.note}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function ContrastAudit() {
  const pairs = [
    { bg: "#0F172A", fg: "#FFFFFF", bgName: "Text/900", fgName: "White", ratio: "18.1:1", aa: true, aaa: true },
    { bg: "#0EA5E9", fg: "#FFFFFF", bgName: "Primary/500", fgName: "White", ratio: "3.0:1", aa: false, aaa: false, note: "Use for large text only" },
    { bg: "#0369A1", fg: "#FFFFFF", bgName: "Primary/700", fgName: "White", ratio: "5.9:1", aa: true, aaa: false },
    { bg: "#F97316", fg: "#FFFFFF", bgName: "Accent/500", fgName: "White", ratio: "3.1:1", aa: false, aaa: false, note: "Use for large text only" },
    { bg: "#F97316", fg: "#0F172A", bgName: "Accent/500", fgName: "Text", ratio: "4.6:1", aa: true, aaa: false },
    { bg: "#F0FAFF", fg: "#0F172A", bgName: "Background", fgName: "Text", ratio: "17.4:1", aa: true, aaa: true },
    { bg: "#FFFFFF", fg: "#475569", bgName: "Surface", fgName: "Muted", ratio: "4.7:1", aa: true, aaa: false },
  ];

  return (
    <div style={S.card}>
      <h3 style={S.sectionTitle}>WCAG AA Contrast Audit</h3>
      <div style={{ overflowX: "auto" as const }}>
        <table style={{ width: "100%", borderCollapse: "collapse", fontFamily: "'Inter', sans-serif", fontSize: 13 }}>
          <thead>
            <tr style={{ borderBottom: "2px solid #E2E8F0" }}>
              {["Preview", "Background", "Foreground", "Ratio", "AA", "AAA", "Notes"].map(h => (
                <th key={h} style={{ padding: "8px 12px", textAlign: "left" as const, color: "#64748B", fontWeight: 600, fontSize: 11, letterSpacing: "0.06em", textTransform: "uppercase" as const }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {pairs.map((p, i) => (
              <tr key={i} style={{ borderBottom: "1px solid #F1F5F9" }}>
                <td style={{ padding: "10px 12px" }}>
                  <div style={{
                    width: 80, height: 32, borderRadius: 8,
                    background: p.bg,
                    display: "flex", alignItems: "center", justifyContent: "center",
                    color: p.fg,
                    fontWeight: 700,
                    fontSize: 13,
                    fontFamily: "'Nunito', sans-serif",
                    boxShadow: "inset 0 0 0 1px rgba(0,0,0,0.08)",
                  }}>Aa</div>
                </td>
                <td style={{ padding: "10px 12px" }}>
                  <span style={{ display: "inline-flex", alignItems: "center", gap: 6 }}>
                    <span style={{ width: 14, height: 14, borderRadius: 4, background: p.bg, display: "inline-block", boxShadow: "inset 0 0 0 1px rgba(0,0,0,0.15)" }} />
                    {p.bgName}
                  </span>
                </td>
                <td style={{ padding: "10px 12px" }}>
                  <span style={{ display: "inline-flex", alignItems: "center", gap: 6 }}>
                    <span style={{ width: 14, height: 14, borderRadius: 4, background: p.fg, display: "inline-block", boxShadow: "inset 0 0 0 1px rgba(0,0,0,0.15)" }} />
                    {p.fgName}
                  </span>
                </td>
                <td style={{ padding: "10px 12px", fontWeight: 600, color: p.aa ? "#0F172A" : "#DC2626" }}>{p.ratio}</td>
                <td style={{ padding: "10px 12px" }}>
                  <span style={{
                    display: "inline-block", padding: "2px 8px", borderRadius: 999,
                    background: p.aa ? "#DCFCE7" : "#FEE2E2",
                    color: p.aa ? "#166534" : "#991B1B",
                    fontWeight: 700, fontSize: 11,
                  }}>{p.aa ? "Pass" : "Fail"}</span>
                </td>
                <td style={{ padding: "10px 12px" }}>
                  <span style={{
                    display: "inline-block", padding: "2px 8px", borderRadius: 999,
                    background: p.aaa ? "#DCFCE7" : "#F1F5F9",
                    color: p.aaa ? "#166534" : "#64748B",
                    fontWeight: 700, fontSize: 11,
                  }}>{p.aaa ? "Pass" : "—"}</span>
                </td>
                <td style={{ padding: "10px 12px", color: "#94A3B8", fontSize: 12 }}>{p.note || ""}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function DarkModeSection() {
  const darkBg = "#0F1829";
  const darkSurface = "#162035";
  const darkBorder = "#1E3048";

  return (
    <div style={{ marginBottom: 0 }}>
      <h3 style={S.sectionTitle}>Dark Mode Variant</h3>
      <div style={{
        background: darkBg,
        borderRadius: 20,
        padding: 32,
        boxShadow: "0 8px 32px rgba(0,0,0,0.4)",
      }}>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 16, marginBottom: 24 }}>
          {[
            { label: "Background", hex: "#0F1829", oklch: "oklch(15% 0.01 220)" },
            { label: "Surface", hex: "#162035", oklch: "oklch(20% 0.02 220)" },
            { label: "Border", hex: "#1E3048", oklch: "oklch(28% 0.04 220)" },
            { label: "Text Primary", hex: "#F8FAFC", oklch: "oklch(98% 0.01 220)" },
            { label: "Text Muted", hex: "#94A3B8", oklch: "oklch(64% 0.05 220)" },
            { label: "Primary", hex: "#38BDF8", oklch: "oklch(80% 0.11 220)" },
          ].map(item => (
            <div key={item.label} style={{ display: "flex", alignItems: "center", gap: 12 }}>
              <div style={{
                width: 40, height: 40, borderRadius: 10, background: item.hex,
                border: "1px solid rgba(255,255,255,0.1)", flexShrink: 0,
              }} />
              <div>
                <div style={{ fontFamily: "'Nunito', sans-serif", fontWeight: 700, fontSize: 12, color: "#F8FAFC" }}>{item.label}</div>
                <div style={{ fontFamily: "'Inter', sans-serif", fontSize: 10, color: "#64748B" }}>{item.hex}</div>
              </div>
            </div>
          ))}
        </div>
        <div style={{
          background: darkSurface,
          borderRadius: 14,
          padding: 20,
          border: `1px solid ${darkBorder}`,
        }}>
          <p style={{ fontFamily: "'Nunito', sans-serif", fontWeight: 800, fontSize: 22, color: "#F8FAFC", margin: "0 0 8px" }}>
            Every referral creates a ripple.
          </p>
          <p style={{ fontFamily: "'Inter', sans-serif", fontSize: 14, color: "#94A3B8", margin: "0 0 16px" }}>
            Share your code with the community and start earning together.
          </p>
          <div style={{ display: "flex", gap: 10 }}>
            <button style={{
              background: "#0EA5E9", color: "#FFFFFF",
              fontFamily: "'Nunito', sans-serif", fontWeight: 700, fontSize: 14,
              border: "none", borderRadius: 10, padding: "10px 20px", cursor: "pointer",
            }}>Share my code</button>
            <button style={{
              background: "transparent", color: "#94A3B8",
              fontFamily: "'Inter', sans-serif", fontWeight: 500, fontSize: 14,
              border: `1px solid ${darkBorder}`, borderRadius: 10, padding: "10px 20px", cursor: "pointer",
            }}>Browse codes</button>
          </div>
        </div>
        <div style={{ marginTop: 16, padding: "12px 16px", background: "rgba(14,165,233,0.1)", borderRadius: 10, border: "1px solid rgba(14,165,233,0.2)" }}>
          <p style={{ fontFamily: "'Inter', sans-serif", fontSize: 12, color: "#7DD3FC", margin: 0 }}>
            Dark mode uses oklch(15-20% 0.01-0.03 220) backgrounds, keeping the teal hue consistent. Primary color lightens to /400 (#38BDF8) for legibility.
          </p>
        </div>
      </div>
    </div>
  );
}

export default function Board1ColorTypography() {
  const exportRef = useBoardExportReady(50);
  return (
    <div ref={exportRef} style={S.page}>
      <div style={S.header}>
        <div style={S.boardLabel}>Board 1 of 4 — Ripple Brand Kit</div>
        <h1 style={S.boardTitle}>Color &amp; Typography</h1>
      </div>

      <div style={S.grid2}>
        <div style={S.card}>
          <h3 style={S.sectionTitle}>Core Palette</h3>
          <SwatchRow hex="#0EA5E9" label="Primary" oklch="oklch(67% 0.19 220)" />
          <SwatchRow hex="#F97316" label="Accent" oklch="oklch(68% 0.21 50)" />
          <SwatchRow hex="#F0FAFF" label="Background" oklch="oklch(97% 0.02 220)" />
          <SwatchRow hex="#FFFFFF" label="Surface" oklch="oklch(100% 0 0)" />
          <SwatchRow hex="#0F172A" label="Text" oklch="oklch(15% 0.02 264)" />
        </div>

        <div style={S.card}>
          <h3 style={S.sectionTitle}>Design Tokens — CSS Custom Properties</h3>
          <pre style={{
            background: "#0F172A",
            color: "#7DD3FC",
            borderRadius: 10,
            padding: 16,
            fontSize: 12,
            lineHeight: 1.7,
            overflowX: "auto" as const,
            fontFamily: "'JetBrains Mono', monospace",
            margin: 0,
          }}>{`:root {
  --color-primary: #0EA5E9;
  --color-primary-oklch: oklch(67% 0.19 220);
  --color-accent:  #F97316;
  --color-accent-oklch: oklch(68% 0.21 50);
  --color-bg:      #F0FAFF;
  --color-surface: #FFFFFF;
  --color-text:    #0F172A;

  --font-display: 'Nunito', sans-serif;
  --font-body:    'Inter', sans-serif;

  --radius-sm: 8px;
  --radius-md: 12px;
  --radius-lg: 20px;
  --radius-xl: 28px;
}`}</pre>
        </div>
      </div>

      <NeutralRamp />
      <TypeSpecimen />
      <ContrastAudit />

      <div style={{ marginTop: 48 }}>
        <DarkModeSection />
      </div>

      <div style={{ marginTop: 48 }}>
        <h2 style={{ ...S.sectionTitle, marginBottom: 16 }}>Design Tokens — Export</h2>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 24 }}>
          <div style={S.card}>
            <h3 style={{ fontFamily: "'Nunito', sans-serif", fontWeight: 700, fontSize: 14, color: "#64748B", letterSpacing: "0.08em", textTransform: "uppercase" as const, marginBottom: 12, marginTop: 0 }}>CSS Custom Properties</h3>
            <pre style={{ background: "#0F172A", color: "#7DD3FC", borderRadius: 10, padding: 16, fontSize: 12, lineHeight: 1.7, overflowX: "auto" as const, fontFamily: "'JetBrains Mono', monospace", margin: 0, whiteSpace: "pre-wrap" as const }}>{`:root {
  /* Core palette */
  --ripple-primary:    #0EA5E9; /* oklch(67% 0.19 220) */
  --ripple-primary-dark: #0369A1; /* oklch(48% 0.16 220) */
  --ripple-accent:     #F97316; /* oklch(68% 0.21 50) */
  --ripple-bg:         #F0FAFF; /* oklch(97% 0.02 220) */
  --ripple-surface:    #FFFFFF;
  --ripple-text:       #0F172A; /* oklch(15% 0.02 264) */
  --ripple-text-muted: #64748B;

  /* Neutral scale — hue 220 tinted */
  --ripple-neutral-50:  #F0FAFF;
  --ripple-neutral-100: #E0F4FE;
  --ripple-neutral-200: #BAE6FD;
  --ripple-neutral-300: #7DD3FC;
  --ripple-neutral-400: #38BDF8;
  --ripple-neutral-500: #0EA5E9;
  --ripple-neutral-600: #0284C7;
  --ripple-neutral-700: #0369A1;
  --ripple-neutral-800: #075985;
  --ripple-neutral-900: #0C4A6E;

  /* Typography */
  --ripple-font-display: 'Nunito', sans-serif;
  --ripple-font-body:    'Inter', sans-serif;
  --ripple-font-code:    'JetBrains Mono', monospace;

  /* Spacing / radius */
  --ripple-radius-sm: 8px;
  --ripple-radius-md: 12px;
  --ripple-radius-lg: 20px;
  --ripple-radius-xl: 28px;
}`}</pre>
          </div>
          <div style={S.card}>
            <h3 style={{ fontFamily: "'Nunito', sans-serif", fontWeight: 700, fontSize: 14, color: "#64748B", letterSpacing: "0.08em", textTransform: "uppercase" as const, marginBottom: 12, marginTop: 0 }}>Tailwind Config — theme.extend</h3>
            <pre style={{ background: "#0F172A", color: "#86EFAC", borderRadius: 10, padding: 16, fontSize: 12, lineHeight: 1.7, overflowX: "auto" as const, fontFamily: "'JetBrains Mono', monospace", margin: 0, whiteSpace: "pre-wrap" as const }}>{`// tailwind.config.ts
import type { Config } from 'tailwindcss';

export default {
  theme: {
    extend: {
      colors: {
        ripple: {
          primary: '#0EA5E9',
          'primary-dark': '#0369A1',
          accent:  '#F97316',
          bg:      '#F0FAFF',
          surface: '#FFFFFF',
          text:    '#0F172A',
          muted:   '#64748B',
          neutral: {
            50:  '#F0FAFF', 100: '#E0F4FE',
            200: '#BAE6FD', 300: '#7DD3FC',
            400: '#38BDF8', 500: '#0EA5E9',
            600: '#0284C7', 700: '#0369A1',
            800: '#075985', 900: '#0C4A6E',
          },
        },
      },
      fontFamily: {
        display: ["'Nunito'", 'sans-serif'],
        body:    ["'Inter'",  'sans-serif'],
        code:    ["'JetBrains Mono'", 'monospace'],
      },
      borderRadius: {
        'ripple-sm': '8px',  'ripple-md': '12px',
        'ripple-lg': '20px', 'ripple-xl': '28px',
      },
    },
  },
} satisfies Config;`}</pre>
          </div>
        </div>
      </div>
    </div>
  );
}

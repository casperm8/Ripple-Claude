import AnimatedRippleIcon from "./AnimatedRippleIcon";
import { useBoardExportReady } from "../../../hooks/useBoardExportReady";

const S: Record<string, React.CSSProperties> = {
  page: {
    background: "#F0FAFF",
    fontFamily: "'Inter', sans-serif",
    color: "#0F172A",
    minHeight: "100vh",
    padding: "48px 56px",
    boxSizing: "border-box",
  },
  header: {
    marginBottom: 48,
    borderBottom: "2px solid #E0F4FE",
    paddingBottom: 24,
  },
  boardLabel: {
    fontFamily: "'Nunito', sans-serif",
    fontSize: 13,
    fontWeight: 700,
    letterSpacing: "0.12em",
    textTransform: "uppercase" as const,
    color: "#0EA5E9",
    marginBottom: 8,
  },
  boardTitle: {
    fontFamily: "'Nunito', sans-serif",
    fontSize: 32,
    fontWeight: 800,
    color: "#0F172A",
    margin: 0,
    lineHeight: 1.2,
  },
  sectionTitle: {
    fontFamily: "'Nunito', sans-serif",
    fontSize: 20,
    fontWeight: 800,
    color: "#0F172A",
    marginBottom: 20,
    marginTop: 0,
  },
  subSectionTitle: {
    fontFamily: "'Nunito', sans-serif",
    fontSize: 14,
    fontWeight: 700,
    color: "#64748B",
    marginBottom: 12,
    marginTop: 0,
    letterSpacing: "0.08em",
    textTransform: "uppercase" as const,
  },
  card: {
    background: "#FFFFFF",
    borderRadius: 16,
    padding: 28,
    boxShadow: "0 1px 3px rgba(14,165,233,0.08), 0 4px 16px rgba(14,165,233,0.06)",
  },
};

function DoRow({ type, color, colorName, bg, context, rule }: {
  type: "do" | "dont"; color: string; colorName: string; bg: string; context: string; rule: string;
}) {
  const isDo = type === "do";
  return (
    <div style={{
      display: "flex",
      gap: 14,
      padding: "14px 0",
      borderBottom: "1px solid #F1F5F9",
    }}>
      <div style={{
        width: 48, height: 48, borderRadius: 12, background: bg,
        display: "flex", alignItems: "center", justifyContent: "center",
        flexShrink: 0,
        boxShadow: "inset 0 0 0 1px rgba(0,0,0,0.06)",
      }}>
        <div style={{ width: 24, height: 24, borderRadius: 6, background: color }} />
      </div>
      <div style={{ flex: 1 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 4 }}>
          <span style={{
            display: "inline-block",
            width: 20, height: 20, borderRadius: 999,
            background: isDo ? "#DCFCE7" : "#FEE2E2",
            color: isDo ? "#16A34A" : "#DC2626",
            fontWeight: 800, fontSize: 12,
            textAlign: "center" as const, lineHeight: "20px",
          }}>{isDo ? "✓" : "✗"}</span>
          <span style={{ fontFamily: "'Nunito', sans-serif", fontWeight: 700, fontSize: 14, color: colorName === "#0EA5E9" ? "#0EA5E9" : "#0F172A" }}>{colorName}</span>
          <span style={{ fontFamily: "'Inter', sans-serif", fontSize: 12, color: "#94A3B8" }}>in {context}</span>
        </div>
        <p style={{ fontFamily: "'Inter', sans-serif", fontSize: 13, color: isDo ? "#166534" : "#991B1B", margin: 0 }}>{rule}</p>
      </div>
    </div>
  );
}

function ColorUsageSection() {
  return (
    <div style={{ ...S.card, marginBottom: 32 }}>
      <h2 style={S.sectionTitle}>Color Usage Rules</h2>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 32 }}>
        <div>
          <h3 style={S.subSectionTitle}>Do</h3>
          <DoRow type="do" color="#0EA5E9" colorName="#0EA5E9 Primary" bg="#F0FAFF" context="interactive elements" rule="Use Primary for buttons, links, and interactive UI — it guides action." />
          <DoRow type="do" color="#F97316" colorName="#F97316 Accent" bg="#FFF7ED" context="CTAs & rewards" rule="Use Accent exclusively for CTAs, reward badges, and celebratory moments." />
          <DoRow type="do" color="#0369A1" colorName="#0369A1 Primary/700" bg="#F0FAFF" context="body text on light" rule="Use Primary/700 or darker for body text on white/light backgrounds — passes AA." />
          <DoRow type="do" color="#0F172A" colorName="#0F172A Text" bg="#F8FAFC" context="headings" rule="Use near-black for headings and high-emphasis text at all sizes." />
        </div>
        <div>
          <h3 style={S.subSectionTitle}>Don't</h3>
          <DoRow type="dont" color="#0EA5E9" colorName="#0EA5E9 Primary/500" bg="#FFFFFF" context="small body text" rule="Don't use Primary/500 for small body text on white — 3.0:1 fails AA." />
          <DoRow type="dont" color="#F97316" colorName="#F97316 Accent" bg="#FFFFFF" context="body copy" rule="Don't use Accent for body copy — reserve it for rewards and CTAs only." />
          <DoRow type="dont" color="#BAE6FD" colorName="#BAE6FD Neutral/200" bg="#F0FAFF" context="text or borders" rule="Don't use light neutrals (/50–/200) as text — insufficient contrast." />
          <DoRow type="dont" color="#F97316" colorName="#F97316 Accent" bg="#0EA5E9" context="primary bg" rule="Don't layer Accent on Primary — both colors compete visually." />
        </div>
      </div>
    </div>
  );
}

function TypographySection() {
  const rows = [
    { role: "Display", font: "Nunito 800", size: "48px / 52px", usage: "Hero headlines, splash screens" },
    { role: "H1", font: "Nunito 700", size: "36px / 44px", usage: "Page titles, section heroes" },
    { role: "H2", font: "Nunito 700", size: "28px / 36px", usage: "Section headings" },
    { role: "H3", font: "Nunito 600", size: "22px / 30px", usage: "Card titles, subsections" },
    { role: "Body Large", font: "Inter 400", size: "18px / 28px", usage: "Lead copy, onboarding text" },
    { role: "Body", font: "Inter 400", size: "16px / 24px", usage: "Default body — min size web" },
    { role: "Body Small", font: "Inter 400", size: "14px / 20px", usage: "Secondary info — min size mobile" },
    { role: "Caption", font: "Inter 500", size: "12px / 16px", usage: "Labels, timestamps, metadata" },
    { role: "Code", font: "JetBrains Mono 600", size: "14px / 20px", usage: "Referral codes, tokens" },
  ];

  return (
    <div style={{ ...S.card, marginBottom: 32 }}>
      <h2 style={S.sectionTitle}>Typography Hierarchy</h2>
      <table style={{ width: "100%", borderCollapse: "collapse", fontFamily: "'Inter', sans-serif", fontSize: 13 }}>
        <thead>
          <tr style={{ borderBottom: "2px solid #E2E8F0" }}>
            {["Role", "Font", "Size / Line-height", "Usage"].map(h => (
              <th key={h} style={{ padding: "8px 12px", textAlign: "left" as const, color: "#64748B", fontWeight: 600, fontSize: 11, letterSpacing: "0.06em", textTransform: "uppercase" as const }}>{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row, i) => (
            <tr key={row.role} style={{ borderBottom: "1px solid #F1F5F9", background: i % 2 === 0 ? "#FFFFFF" : "#FAFCFF" }}>
              <td style={{ padding: "10px 12px", fontFamily: "'Nunito', sans-serif", fontWeight: 700, color: "#0F172A" }}>{row.role}</td>
              <td style={{ padding: "10px 12px", fontFamily: "'JetBrains Mono', monospace", fontSize: 12, color: "#0EA5E9" }}>{row.font}</td>
              <td style={{ padding: "10px 12px", color: "#475569" }}>{row.size}</td>
              <td style={{ padding: "10px 12px", color: "#64748B" }}>{row.usage}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function VoiceToneSection() {
  const examples = [
    {
      context: "Headline",
      icon: "✨",
      copy: "Find codes. Share codes. Earn together.",
      note: "Active verbs, short rhythm, communal — feels like an invitation, not a pitch.",
    },
    {
      context: "Onboarding Success",
      icon: "🎉",
      copy: "You're in! Drop your first code and start earning with the community.",
      note: "Celebratory but direct. Immediate call to action. 'You're in' triggers belonging.",
    },
    {
      context: "Error State",
      icon: "😬",
      copy: "Oops! Something went sideways. Try again?",
      note: "Light, human, never alarming. Question mark invites — doesn't demand.",
    },
    {
      context: "Empty State",
      icon: "🌊",
      copy: "The community is waiting for your codes — drop your first one!",
      note: "Frames the empty state as potential, not absence. Exclamation energizes.",
    },
    {
      context: "CTA",
      icon: "📤",
      copy: "Share my code",
      note: "Personal possessive ('my') — the user owns their code. Short, actionable.",
    },
  ];

  return (
    <div style={{ ...S.card, marginBottom: 32 }}>
      <h2 style={S.sectionTitle}>Voice &amp; Tone</h2>
      <div style={{
        background: "#F0FAFF",
        borderRadius: 12,
        padding: "16px 20px",
        marginBottom: 24,
        borderLeft: "4px solid #0EA5E9",
      }}>
        <p style={{ fontFamily: "'Nunito', sans-serif", fontWeight: 700, fontSize: 15, color: "#0F172A", margin: "0 0 6px" }}>
          Brand voice: Enthusiastic &amp; Social
        </p>
        <p style={{ fontFamily: "'Inter', sans-serif", fontSize: 13, color: "#475569", margin: 0 }}>
          Community-first, celebratory, reward-forward. Friendly and energetic without being loud. Speak like a friend who found a great deal — not a marketer.
        </p>
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 0 }}>
        {examples.map((ex, i) => (
          <div key={ex.context} style={{
            padding: "16px 0",
            borderBottom: i < examples.length - 1 ? "1px solid #F1F5F9" : "none",
            display: "grid",
            gridTemplateColumns: "130px 1fr",
            gap: 20,
            alignItems: "start",
          }}>
            <div>
              <span style={{ fontFamily: "'Inter', sans-serif", fontSize: 10, fontWeight: 600, letterSpacing: "0.08em", textTransform: "uppercase" as const, color: "#94A3B8" }}>{ex.context}</span>
            </div>
            <div>
              <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 6 }}>
                <span style={{ fontSize: 18 }}>{ex.icon}</span>
                <span style={{ fontFamily: "'Nunito', sans-serif", fontWeight: 700, fontSize: 16, color: "#0F172A" }}>"{ex.copy}"</span>
              </div>
              <p style={{ fontFamily: "'Inter', sans-serif", fontSize: 13, color: "#64748B", margin: 0, paddingLeft: 28 }}>{ex.note}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function MotionSection() {
  const specRows = [
    { property: "Duration", value: "2.6 s", note: "Full pulse cycle per ring" },
    { property: "Easing", value: "ease-in-out", note: "Smooth enter and exit — no abrupt stops" },
    { property: "Stagger", value: "0.55 s", note: "Delay between ring 1 → 2 → 3" },
    { property: "Scale", value: "1 → 1.07 → 1", note: "Subtle breath — keeps icon contained" },
    { property: "Opacity", value: "base → ×0.12 → base", note: "Each ring fades at its own base opacity" },
    { property: "Repeat", value: "Infinity", note: "Loops forever while icon is visible" },
    { property: "Reduced-motion", value: "opacity fixed, no scale/animation", note: "Rings shown static; no movement" },
  ];

  const rings = [
    { label: "Ring 1 (inner)", delay: "0 s", opacity: "0.70", r: "57% of radius", stroke: "7.1% of size" },
    { label: "Ring 2 (mid)", delay: "0.55 s", opacity: "0.35", r: "86% of radius", stroke: "5.4% of size" },
    { label: "Ring 3 (outer)", delay: "1.10 s", opacity: "0.15", r: "96% of radius", stroke: "3.6% of size" },
  ];

  return (
    <div style={{ ...S.card, marginBottom: 32 }}>
      <h2 style={S.sectionTitle}>Motion &amp; Animation</h2>

      <div style={{ display: "grid", gridTemplateColumns: "280px 1fr", gap: 32, marginBottom: 32 }}>
        <div>
          <h3 style={S.subSectionTitle}>Live Demo</h3>
          <div style={{
            background: "linear-gradient(135deg, #F0FAFF 0%, #E0F4FE 100%)",
            borderRadius: 16,
            display: "flex",
            flexDirection: "column" as const,
            alignItems: "center",
            justifyContent: "center",
            gap: 24,
            padding: "32px 24px",
            border: "1px solid #BAE6FD",
          }}>
            <AnimatedRippleIcon size={96} color="#0EA5E9" />
            <div style={{ textAlign: "center" as const }}>
              <p style={{ fontFamily: "'Nunito', sans-serif", fontWeight: 700, fontSize: 13, color: "#0369A1", margin: "0 0 4px" }}>
                Ripple-wave animation
              </p>
              <p style={{ fontFamily: "'Inter', sans-serif", fontSize: 11, color: "#64748B", margin: 0 }}>
                3 rings · 2.6 s cycle · 0.55 s stagger
              </p>
            </div>
            <div style={{ display: "flex", gap: 20, alignItems: "center" }}>
              <div style={{ textAlign: "center" as const }}>
                <AnimatedRippleIcon size={48} color="#0EA5E9" />
                <p style={{ fontFamily: "'Inter', sans-serif", fontSize: 10, color: "#94A3B8", margin: "6px 0 0", textAlign: "center" as const }}>48 px</p>
              </div>
              <div style={{ textAlign: "center" as const }}>
                <AnimatedRippleIcon size={32} color="#0EA5E9" />
                <p style={{ fontFamily: "'Inter', sans-serif", fontSize: 10, color: "#94A3B8", margin: "6px 0 0", textAlign: "center" as const }}>32 px</p>
              </div>
              <div style={{ textAlign: "center" as const }}>
                <AnimatedRippleIcon size={24} color="#0EA5E9" />
                <p style={{ fontFamily: "'Inter', sans-serif", fontSize: 10, color: "#94A3B8", margin: "6px 0 0", textAlign: "center" as const }}>24 px</p>
              </div>
            </div>
          </div>
        </div>

        <div>
          <h3 style={S.subSectionTitle}>Animation Spec</h3>
          <table style={{ width: "100%", borderCollapse: "collapse" as const, fontFamily: "'Inter', sans-serif", fontSize: 12 }}>
            <thead>
              <tr style={{ borderBottom: "2px solid #E2E8F0" }}>
                {["Property", "Value", "Rationale"].map(h => (
                  <th key={h} style={{ padding: "7px 10px", textAlign: "left" as const, color: "#64748B", fontWeight: 600, fontSize: 11, letterSpacing: "0.06em", textTransform: "uppercase" as const }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {specRows.map((row, i) => (
                <tr key={row.property} style={{ borderBottom: "1px solid #F1F5F9", background: i % 2 === 0 ? "#FFFFFF" : "#FAFCFF" }}>
                  <td style={{ padding: "9px 10px", fontFamily: "'Nunito', sans-serif", fontWeight: 700, color: "#0F172A" }}>{row.property}</td>
                  <td style={{ padding: "9px 10px", fontFamily: "'JetBrains Mono', monospace", fontSize: 11, color: "#0EA5E9", whiteSpace: "nowrap" as const }}>{row.value}</td>
                  <td style={{ padding: "9px 10px", color: "#64748B" }}>{row.note}</td>
                </tr>
              ))}
            </tbody>
          </table>

          <h3 style={{ ...S.subSectionTitle, marginTop: 24 }}>Per-Ring Values</h3>
          <table style={{ width: "100%", borderCollapse: "collapse" as const, fontFamily: "'Inter', sans-serif", fontSize: 12 }}>
            <thead>
              <tr style={{ borderBottom: "2px solid #E2E8F0" }}>
                {["Ring", "Delay", "Base Opacity", "Radius", "Stroke"].map(h => (
                  <th key={h} style={{ padding: "7px 10px", textAlign: "left" as const, color: "#64748B", fontWeight: 600, fontSize: 11, letterSpacing: "0.06em", textTransform: "uppercase" as const }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {rings.map((ring, i) => (
                <tr key={ring.label} style={{ borderBottom: "1px solid #F1F5F9", background: i % 2 === 0 ? "#FFFFFF" : "#FAFCFF" }}>
                  <td style={{ padding: "9px 10px", fontFamily: "'Nunito', sans-serif", fontWeight: 700, color: "#0F172A", fontSize: 12 }}>{ring.label}</td>
                  <td style={{ padding: "9px 10px", fontFamily: "'JetBrains Mono', monospace", fontSize: 11, color: "#0EA5E9" }}>{ring.delay}</td>
                  <td style={{ padding: "9px 10px", fontFamily: "'JetBrains Mono', monospace", fontSize: 11, color: "#0EA5E9" }}>{ring.opacity}</td>
                  <td style={{ padding: "9px 10px", color: "#64748B" }}>{ring.r}</td>
                  <td style={{ padding: "9px 10px", color: "#64748B" }}>{ring.stroke}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 24, marginBottom: 28 }}>
        <div style={{ background: "#F0FFF4", border: "1px solid #BBF7D0", borderRadius: 12, padding: "16px 20px" }}>
          <h3 style={{ fontFamily: "'Nunito', sans-serif", fontWeight: 800, fontSize: 13, color: "#15803D", margin: "0 0 12px", letterSpacing: "0.06em", textTransform: "uppercase" as const }}>
            ✓ Animate these
          </h3>
          {[
            "Ripple icon rings (scale + opacity pulse)",
            "Icon core dot (static — no animation needed)",
            "Notification badge appear / dismiss (fade in)",
            "Reward confetti burst (one-shot, non-looping)",
          ].map((item, i) => (
            <div key={i} style={{ display: "flex", gap: 8, alignItems: "flex-start", marginBottom: 8 }}>
              <span style={{ color: "#16A34A", fontWeight: 800, fontSize: 13, flexShrink: 0, marginTop: 1 }}>✓</span>
              <span style={{ fontFamily: "'Inter', sans-serif", fontSize: 13, color: "#166534" }}>{item}</span>
            </div>
          ))}
        </div>

        <div style={{ background: "#FFF1F2", border: "1px solid #FECDD3", borderRadius: 12, padding: "16px 20px" }}>
          <h3 style={{ fontFamily: "'Nunito', sans-serif", fontWeight: 800, fontSize: 13, color: "#B91C1C", margin: "0 0 12px", letterSpacing: "0.06em", textTransform: "uppercase" as const }}>
            ✗ Keep static
          </h3>
          {[
            "Wordmark — 'Ripple' text must never pulse or scale",
            "Body copy and headings — no motion on text",
            "Buttons at rest — only animate on hover/press",
            "Page backgrounds — no breathing or parallax effects",
          ].map((item, i) => (
            <div key={i} style={{ display: "flex", gap: 8, alignItems: "flex-start", marginBottom: 8 }}>
              <span style={{ color: "#DC2626", fontWeight: 800, fontSize: 13, flexShrink: 0, marginTop: 1 }}>✗</span>
              <span style={{ fontFamily: "'Inter', sans-serif", fontSize: 13, color: "#991B1B" }}>{item}</span>
            </div>
          ))}
        </div>
      </div>

      <div style={{
        background: "#0F172A",
        borderRadius: 12,
        padding: 16,
      }}>
        <h3 style={{ fontFamily: "'Nunito', sans-serif", fontWeight: 700, fontSize: 12, color: "#94A3B8", letterSpacing: "0.08em", textTransform: "uppercase" as const, margin: "0 0 10px" }}>
          Framer Motion — canonical implementation
        </h3>
        <pre style={{
          fontFamily: "'JetBrains Mono', monospace",
          fontSize: 11,
          color: "#7DD3FC",
          margin: 0,
          lineHeight: 1.7,
          whiteSpace: "pre-wrap" as const,
        }}>{`const RINGS = [
  { delay: 0,    baseOpacity: 0.70 },  // inner
  { delay: 0.55, baseOpacity: 0.35 },  // mid
  { delay: 1.10, baseOpacity: 0.15 },  // outer
];

// prefers-reduced-motion: rings shown static, no scale or loop
const shouldReduce = useReducedMotion();

<motion.circle
  animate={shouldReduce
    ? { opacity: ring.baseOpacity }
    : { opacity: [base, base * 0.12, base], scale: [1, 1.07, 1] }}
  transition={{ duration: 2.6, delay: ring.delay, repeat: Infinity, ease: "easeInOut" }}
  style={{ transformBox: "fill-box", transformOrigin: "center" }}
/>`}</pre>
      </div>
    </div>
  );
}

function AccessibilitySection() {
  return (
    <div style={S.card}>
      <h2 style={S.sectionTitle}>Accessibility Standards</h2>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 32 }}>
        <div>
          <h3 style={S.subSectionTitle}>Minimum Font Sizes</h3>
          <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            {[
              { platform: "Web", min: "16px body", detail: "12px min for captions/labels" },
              { platform: "iOS", min: "14px body", detail: "11px min, prefer Dynamic Type" },
              { platform: "Android", min: "14sp body", detail: "12sp min, support text scaling" },
            ].map(item => (
              <div key={item.platform} style={{
                background: "#F8FAFC",
                borderRadius: 10,
                padding: "12px 16px",
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
              }}>
                <span style={{ fontFamily: "'Nunito', sans-serif", fontWeight: 700, fontSize: 14, color: "#0F172A" }}>{item.platform}</span>
                <div style={{ textAlign: "right" as const }}>
                  <p style={{ fontFamily: "'JetBrains Mono', monospace", fontWeight: 600, fontSize: 13, color: "#0EA5E9", margin: 0 }}>{item.min}</p>
                  <p style={{ fontFamily: "'Inter', sans-serif", fontSize: 11, color: "#94A3B8", margin: 0 }}>{item.detail}</p>
                </div>
              </div>
            ))}
          </div>

          <h3 style={{ ...S.subSectionTitle, marginTop: 24 }}>Touch Targets</h3>
          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            {[
              { platform: "iOS (Apple HIG)", size: "44 × 44pt", note: "Minimum tappable area" },
              { platform: "Android (Material 3)", size: "48 × 48dp", note: "Minimum touch target" },
              { platform: "Ripple standard", size: "48 × 48px", note: "Applies to all share & copy buttons" },
            ].map(item => (
              <div key={item.platform} style={{ display: "flex", gap: 14, alignItems: "center" }}>
                <div style={{
                  width: 40, height: 40,
                  border: "2px dashed #BAE6FD",
                  borderRadius: 10,
                  display: "flex", alignItems: "center", justifyContent: "center",
                  flexShrink: 0,
                }}>
                  <div style={{ width: 24, height: 24, background: "#0EA5E9", borderRadius: 6 }} />
                </div>
                <div>
                  <p style={{ fontFamily: "'Nunito', sans-serif", fontWeight: 700, fontSize: 13, color: "#0F172A", margin: 0 }}>{item.platform}</p>
                  <p style={{ fontFamily: "'Inter', sans-serif", fontSize: 12, color: "#64748B", margin: 0 }}>{item.size} — {item.note}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div>
          <h3 style={S.subSectionTitle}>Motion — prefers-reduced-motion</h3>
          <div style={{
            background: "#0F172A",
            borderRadius: 12,
            padding: 16,
            marginBottom: 20,
          }}>
            <pre style={{
              fontFamily: "'JetBrains Mono', monospace",
              fontSize: 12,
              color: "#7DD3FC",
              margin: 0,
              lineHeight: 1.7,
              whiteSpace: "pre-wrap" as const,
            }}>{`@media (prefers-reduced-motion: reduce) {
  * {
    animation-duration: 0.01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 0.01ms !important;
    scroll-behavior: auto !important;
  }
}

/* Ripple-specific: disable wave animations */
.ripple-wave-animation {
  animation: none;
}

/* Fade-only alternative */
@media (prefers-reduced-motion: no-preference) {
  .ripple-wave-animation {
    animation: ripple-expand 1.2s ease-out;
  }
}`}</pre>
          </div>

          <h3 style={S.subSectionTitle}>Icon Clarity at 24px</h3>
          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            {[
              { rule: "Stroke weight ≥ 1.5px", note: "Ensure legibility at minimum size" },
              { rule: "Filled vs outlined", note: "Use filled icons for active states, outlined for inactive" },
              { rule: "Optical sizing", note: "Scale from 16px (compact) to 32px (touch) — test all" },
              { rule: "Color contrast", note: "Icon against bg must meet WCAG AA (4.5:1 for <24px)" },
              { rule: "Label pairing", note: "All icons in nav must have visible text labels (mobile)" },
            ].map((item, i) => (
              <div key={i} style={{ display: "flex", gap: 10, alignItems: "flex-start" }}>
                <div style={{
                  width: 20, height: 20,
                  borderRadius: 999,
                  background: "#DCFCE7",
                  color: "#16A34A",
                  fontWeight: 800, fontSize: 12,
                  display: "flex", alignItems: "center", justifyContent: "center",
                  flexShrink: 0,
                  marginTop: 1,
                }}>✓</div>
                <div>
                  <span style={{ fontFamily: "'Nunito', sans-serif", fontWeight: 700, fontSize: 13, color: "#0F172A" }}>{item.rule}</span>
                  <span style={{ fontFamily: "'Inter', sans-serif", fontSize: 12, color: "#64748B" }}> — {item.note}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

export default function Board4Guidelines() {
  const exportRef = useBoardExportReady(200);
  return (
    <div ref={exportRef} style={S.page}>
      <div style={S.header}>
        <div style={S.boardLabel}>Board 4 of 4 — Ripple Brand Kit</div>
        <h1 style={S.boardTitle}>Brand Guidelines</h1>
      </div>

      <ColorUsageSection />
      <TypographySection />
      <VoiceToneSection />
      <MotionSection />
      <AccessibilitySection />

      <div style={{ marginTop: 32 }}>
        <h2 style={{ ...S.sectionTitle, marginBottom: 16 }}>Design Tokens — Export</h2>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 24 }}>
          <div style={S.card}>
            <h3 style={{ fontFamily: "'Nunito', sans-serif", fontWeight: 700, fontSize: 13, color: "#64748B", letterSpacing: "0.08em", textTransform: "uppercase" as const, marginBottom: 12, marginTop: 0 }}>CSS Custom Properties</h3>
            <pre style={{ background: "#0F172A", color: "#7DD3FC", borderRadius: 10, padding: 14, fontSize: 11, lineHeight: 1.7, overflowX: "auto" as const, fontFamily: "'JetBrains Mono', monospace", margin: 0, whiteSpace: "pre-wrap" as const }}>{`:root {
  /* Brand palette */
  --ripple-primary:      #0EA5E9; /* oklch(67% 0.19 220) */
  --ripple-primary-dark: #0369A1; /* oklch(48% 0.16 220) */
  --ripple-accent:       #F97316; /* oklch(68% 0.21 50) */
  --ripple-bg:           #F0FAFF; /* oklch(97% 0.02 220) */
  --ripple-surface:      #FFFFFF;
  --ripple-text:         #0F172A; /* oklch(15% 0.02 264) */
  --ripple-text-muted:   #64748B;

  /* Typography */
  --ripple-font-display: 'Nunito', sans-serif;
  --ripple-font-body:    'Inter', sans-serif;
  --ripple-font-code:    'JetBrains Mono', monospace;

  /* Min sizes per guidelines */
  --ripple-text-min-web:    16px;
  --ripple-text-min-mobile: 14px;
  --ripple-text-min-caption: 12px;

  /* Touch targets per guidelines */
  --ripple-touch-target: 48px; /* 44pt iOS / 48dp Android */
  --ripple-radius-sm: 8px;
  --ripple-radius-md: 12px;
  --ripple-radius-lg: 20px;
}`}</pre>
          </div>
          <div style={S.card}>
            <h3 style={{ fontFamily: "'Nunito', sans-serif", fontWeight: 700, fontSize: 13, color: "#64748B", letterSpacing: "0.08em", textTransform: "uppercase" as const, marginBottom: 12, marginTop: 0 }}>Tailwind Config — theme.extend</h3>
            <pre style={{ background: "#0F172A", color: "#86EFAC", borderRadius: 10, padding: 14, fontSize: 11, lineHeight: 1.7, overflowX: "auto" as const, fontFamily: "'JetBrains Mono', monospace", margin: 0, whiteSpace: "pre-wrap" as const }}>{`// tailwind.config.ts
export default {
  theme: {
    extend: {
      colors: {
        ripple: {
          primary: '#0EA5E9',
          'primary-dark': '#0369A1',
          accent:  '#F97316',
          bg:      '#F0FAFF',
          surface: '#FFFFFF',
          text:    '#0F172A',
          muted:   '#64748B',
          neutral: {
            50:  '#F0FAFF', 500: '#0EA5E9',
            700: '#0369A1', 900: '#0C4A6E',
          },
        },
      },
      fontFamily: {
        display: ["'Nunito'", 'sans-serif'],
        body:    ["'Inter'",  'sans-serif'],
        code:    ["'JetBrains Mono'", 'monospace'],
      },
      fontSize: {
        /* Accessibility minimums */
        'ripple-min-web':    ['16px', { lineHeight: '24px' }],
        'ripple-min-mobile': ['14px', { lineHeight: '20px' }],
        'ripple-caption':    ['12px', { lineHeight: '16px' }],
      },
      minHeight: { 'touch': '48px' },
      minWidth:  { 'touch': '48px' },
      borderRadius: {
        'ripple-sm': '8px',
        'ripple-md': '12px',
        'ripple-lg': '20px',
      },
    },
  },
};`}</pre>
          </div>
        </div>
      </div>
    </div>
  );
}

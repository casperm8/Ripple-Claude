import { useState } from "react";
import { motion, useReducedMotion, AnimatePresence } from "framer-motion";
import AnimatedRippleIcon from "./AnimatedRippleIcon";
import { useBoardExportReady } from "../../../hooks/useBoardExportReady";

const S: Record<string, React.CSSProperties> = {
  page: {
    background: "#F0FAFF",
    fontFamily: "'Inter', sans-serif",
    color: "#0F172A",
    minHeight: "100vh",
    padding: "48px 56px",
    boxSizing: "border-box",
  },
  header: {
    marginBottom: 48,
    borderBottom: "2px solid #E0F4FE",
    paddingBottom: 24,
  },
  boardLabel: {
    fontFamily: "'Nunito', sans-serif",
    fontSize: 13,
    fontWeight: 700,
    letterSpacing: "0.12em",
    textTransform: "uppercase" as const,
    color: "#0EA5E9",
    marginBottom: 8,
  },
  boardTitle: {
    fontFamily: "'Nunito', sans-serif",
    fontSize: 32,
    fontWeight: 800,
    color: "#0F172A",
    margin: 0,
    lineHeight: 1.2,
  },
  sectionTitle: {
    fontFamily: "'Nunito', sans-serif",
    fontSize: 15,
    fontWeight: 800,
    color: "#94A3B8",
    marginBottom: 12,
    marginTop: 0,
    letterSpacing: "0.08em",
    textTransform: "uppercase" as const,
  },
};

const AppIconSmall = () => (
  <svg width="32" height="32" viewBox="0 0 32 32" fill="none">
    <rect width="32" height="32" rx="8" fill="url(#appGrad3)" />
    <defs>
      <linearGradient id="appGrad3" x1="0" y1="0" x2="32" y2="32">
        <stop offset="0%" stopColor="#38BDF8" />
        <stop offset="100%" stopColor="#0284C7" />
      </linearGradient>
    </defs>
    <circle cx="16" cy="16" r="4.5" fill="white" />
    <circle cx="16" cy="16" r="8.5" stroke="white" strokeWidth="1.5" opacity="0.75" />
    <circle cx="16" cy="16" r="13" stroke="white" strokeWidth="1.2" opacity="0.35" />
  </svg>
);

const StarIcon = () => (
  <svg width="14" height="14" viewBox="0 0 14 14" fill="#F97316">
    <path d="M7 1l1.5 4h4l-3.3 2.4L10.3 12 7 9.8 3.7 12l1.1-4.6L1.5 5h4z"/>
  </svg>
);

const ShareIcon = () => (
  <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.8">
    <path d="M12 2.5a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3zM4 6.5a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3zm8 4a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3zm-8-4l8-4m0 8l-8-4" />
  </svg>
);

const CopyIcon = () => (
  <svg width="14" height="14" viewBox="0 0 14 14" fill="none" stroke="currentColor" strokeWidth="1.8">
    <rect x="5" y="5" width="8" height="8" rx="1.5" />
    <path d="M9 5V3.5A1.5 1.5 0 0 0 7.5 2h-5A1.5 1.5 0 0 0 1 3.5v5A1.5 1.5 0 0 0 2.5 10H4" />
  </svg>
);

const codes = [
  {
    platform: "Airbnb",
    platformColor: "#FF5A5F",
    code: "RIPPLE20",
    reward: "Save $20 on your first stay",
    sharer: "Jordan M.",
    saves: 48,
    hot: true,
  },
  {
    platform: "Robinhood",
    platformColor: "#00C805",
    code: "RIP-INVEST",
    reward: "Free stock worth up to $200",
    sharer: "Alex K.",
    saves: 132,
    hot: false,
  },
  {
    platform: "DoorDash",
    platformColor: "#FF3008",
    code: "RIPPLE50",
    reward: "50% off first 2 orders",
    sharer: "Sam T.",
    saves: 89,
    hot: true,
  },
];

function RippleBurst({ color = "#F97316" }: { color?: string }) {
  return (
    <AnimatePresence>
      {[0, 1, 2].map((i) => (
        <motion.span
          key={i}
          style={{
            position: "absolute",
            inset: 0,
            borderRadius: 8,
            border: `2px solid ${color}`,
            pointerEvents: "none",
          }}
          initial={{ opacity: 0.8, scale: 1 }}
          animate={{ opacity: 0, scale: 2.2 }}
          exit={{}}
          transition={{ duration: 0.6, delay: i * 0.15, ease: "easeOut" }}
        />
      ))}
    </AnimatePresence>
  );
}

function PhoneMockup() {
  const shouldReduce = useReducedMotion();
  const [activeShare, setActiveShare] = useState<string | null>(null);

  function handleShare(code: string) {
    if (shouldReduce) return;
    setActiveShare(code);
    setTimeout(() => setActiveShare(null), 800);
  }

  return (
    <div style={{
      width: 320,
      background: "#FFFFFF",
      borderRadius: 36,
      boxShadow: "0 24px 64px rgba(14,165,233,0.18), 0 4px 16px rgba(0,0,0,0.08)",
      overflow: "hidden",
      border: "6px solid #0F172A",
      flexShrink: 0,
    }}>
      <div style={{ background: "#0F172A", height: 32, display: "flex", justifyContent: "center", alignItems: "center", paddingTop: 4 }}>
        <div style={{ width: 80, height: 6, background: "#1E293B", borderRadius: 999 }} />
      </div>

      <div style={{
        background: "linear-gradient(135deg, #0EA5E9 0%, #0284C7 100%)",
        padding: "16px 20px 24px",
      }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 16 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <AnimatedRippleIcon color="white" size={28} />
            <span style={{ fontFamily: "'Nunito', sans-serif", fontWeight: 800, fontSize: 18, color: "white" }}>Ripple</span>
          </div>
          <div style={{
            width: 34, height: 34, borderRadius: 999,
            background: "rgba(255,255,255,0.2)",
            display: "flex", alignItems: "center", justifyContent: "center",
          }}>
            <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
              <path d="M9 2a5 5 0 1 0 0 10A5 5 0 0 0 9 2zM2 16c0-2.8 3.1-5 7-5s7 2.2 7 5" stroke="white" strokeWidth="1.8" strokeLinecap="round"/>
            </svg>
          </div>
        </div>
        <p style={{ fontFamily: "'Nunito', sans-serif", fontWeight: 700, fontSize: 15, color: "rgba(255,255,255,0.9)", margin: "0 0 6px" }}>
          Good morning, Taylor!
        </p>
        <p style={{ fontFamily: "'Inter', sans-serif", fontSize: 13, color: "rgba(255,255,255,0.7)", margin: 0 }}>
          3 new codes posted today
        </p>
      </div>

      <div style={{ background: "#F0FAFF", padding: "16px 16px 0" }}>
        <div style={{ display: "flex", gap: 8, marginBottom: 16 }}>
          {["All", "Trending", "New", "My Saves"].map((tab, i) => (
            <div key={tab} style={{
              padding: "6px 12px",
              borderRadius: 999,
              background: i === 0 ? "#0EA5E9" : "rgba(14,165,233,0.1)",
              color: i === 0 ? "#FFFFFF" : "#0EA5E9",
              fontFamily: "'Nunito', sans-serif",
              fontWeight: 700,
              fontSize: 12,
            }}>{tab}</div>
          ))}
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {codes.map((code) => (
            <div key={code.code} style={{
              background: "#FFFFFF",
              borderRadius: 14,
              padding: "14px 14px",
              boxShadow: "0 1px 4px rgba(14,165,233,0.08)",
            }}>
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 8 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                  <div style={{
                    width: 28, height: 28, borderRadius: 8,
                    background: code.platformColor + "15",
                    display: "flex", alignItems: "center", justifyContent: "center",
                    flexShrink: 0,
                  }}>
                    <span style={{
                      fontFamily: "'Nunito', sans-serif",
                      fontWeight: 800, fontSize: 10,
                      color: code.platformColor,
                    }}>{code.platform[0]}</span>
                  </div>
                  <div>
                    <p style={{ fontFamily: "'Nunito', sans-serif", fontWeight: 700, fontSize: 12, color: "#0F172A", margin: 0 }}>{code.platform}</p>
                    <p style={{ fontFamily: "'Inter', sans-serif", fontSize: 10, color: "#94A3B8", margin: 0 }}>by {code.sharer}</p>
                  </div>
                </div>
                {code.hot && (
                  <span style={{
                    background: "#FFF7ED",
                    color: "#F97316",
                    fontFamily: "'Nunito', sans-serif",
                    fontWeight: 700,
                    fontSize: 10,
                    padding: "2px 8px",
                    borderRadius: 999,
                  }}>🔥 Hot</span>
                )}
              </div>
              <div style={{
                background: "#F0FAFF",
                borderRadius: 8,
                padding: "8px 10px",
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                marginBottom: 8,
              }}>
                <span style={{ fontFamily: "'JetBrains Mono', monospace", fontWeight: 600, fontSize: 14, color: "#0EA5E9", letterSpacing: "0.06em" }}>{code.code}</span>
                <div style={{ color: "#0EA5E9", display: "flex", alignItems: "center" }}><CopyIcon /></div>
              </div>
              <p style={{ fontFamily: "'Inter', sans-serif", fontSize: 11, color: "#475569", margin: "0 0 10px" }}>{code.reward}</p>
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                <span style={{ fontFamily: "'Inter', sans-serif", fontSize: 10, color: "#94A3B8" }}>{code.saves} saves</span>
                <div style={{ position: "relative" }}>
                  {activeShare === code.code && <RippleBurst />}
                  <motion.button
                    style={{
                      background: "#F97316",
                      color: "#FFFFFF",
                      fontFamily: "'Nunito', sans-serif",
                      fontWeight: 700,
                      fontSize: 11,
                      border: "none",
                      borderRadius: 8,
                      padding: "6px 12px",
                      display: "flex",
                      alignItems: "center",
                      gap: 4,
                      cursor: "pointer",
                      position: "relative",
                    }}
                    whileTap={shouldReduce ? {} : { scale: 0.92 }}
                    onClick={() => handleShare(code.code)}
                  >
                    <ShareIcon /> Share
                  </motion.button>
                </div>
              </div>
            </div>
          ))}
        </div>
        <div style={{ height: 16 }} />
      </div>
    </div>
  );
}

function ShareCard() {
  return (
    <div style={{
      background: "linear-gradient(135deg, #0EA5E9 0%, #0369A1 100%)",
      borderRadius: 24,
      padding: 28,
      color: "white",
      boxShadow: "0 12px 40px rgba(14,165,233,0.3)",
    }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 20 }}>
        <AnimatedRippleIcon color="white" size={32} />
        <div>
          <p style={{ fontFamily: "'Nunito', sans-serif", fontWeight: 800, fontSize: 16, margin: 0 }}>Ripple Referral</p>
          <p style={{ fontFamily: "'Inter', sans-serif", fontSize: 12, color: "rgba(255,255,255,0.7)", margin: 0 }}>Shared by Taylor K.</p>
        </div>
      </div>
      <p style={{ fontFamily: "'Nunito', sans-serif", fontWeight: 800, fontSize: 20, margin: "0 0 6px", lineHeight: 1.3 }}>
        Save $20 on your first Airbnb stay!
      </p>
      <p style={{ fontFamily: "'Inter', sans-serif", fontSize: 14, color: "rgba(255,255,255,0.8)", margin: "0 0 20px" }}>
        Use my code and we both earn rewards
      </p>
      <div style={{
        background: "rgba(255,255,255,0.15)",
        backdropFilter: "blur(8px)",
        borderRadius: 14,
        padding: "14px 18px",
        marginBottom: 20,
        border: "1px solid rgba(255,255,255,0.25)",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
      }}>
        <span style={{ fontFamily: "'JetBrains Mono', monospace", fontWeight: 700, fontSize: 24, letterSpacing: "0.08em" }}>RIPPLE20</span>
        <button style={{
          background: "white",
          color: "#0EA5E9",
          border: "none",
          borderRadius: 10,
          padding: "8px 16px",
          fontFamily: "'Nunito', sans-serif",
          fontWeight: 700,
          fontSize: 13,
          cursor: "pointer",
          display: "flex",
          alignItems: "center",
          gap: 6,
        }}>
          <CopyIcon /> Copy
        </button>
      </div>
      <div style={{ display: "flex", gap: 10 }}>
        {["Messages", "WhatsApp", "Twitter", "More"].map((app, i) => (
          <div key={app} style={{
            flex: 1,
            background: "rgba(255,255,255,0.15)",
            borderRadius: 12,
            padding: "10px 4px",
            textAlign: "center" as const,
            border: "1px solid rgba(255,255,255,0.2)",
          }}>
            <div style={{ fontSize: 20, marginBottom: 4 }}>
              {["💬", "💚", "🐦", "···"][i]}
            </div>
            <p style={{ fontFamily: "'Inter', sans-serif", fontSize: 10, color: "rgba(255,255,255,0.8)", margin: 0 }}>{app}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

function AppStoreListing() {
  return (
    <div style={{
      background: "#FFFFFF",
      borderRadius: 20,
      overflow: "hidden",
      boxShadow: "0 4px 24px rgba(0,0,0,0.10)",
    }}>
      <div style={{
        background: "linear-gradient(135deg, #0EA5E9 0%, #0284C7 100%)",
        padding: "28px 28px 20px",
        display: "flex",
        alignItems: "center",
        gap: 20,
      }}>
        <div style={{
          width: 80, height: 80, borderRadius: 18,
          background: "linear-gradient(135deg, #38BDF8, #0284C7)",
          display: "flex", alignItems: "center", justifyContent: "center",
          boxShadow: "0 4px 16px rgba(0,0,0,0.2)",
        }}>
          <AnimatedRippleIcon color="white" size={44} />
        </div>
        <div style={{ flex: 1 }}>
          <p style={{ fontFamily: "'Nunito', sans-serif", fontWeight: 800, fontSize: 22, color: "white", margin: "0 0 4px" }}>Ripple</p>
          <p style={{ fontFamily: "'Inter', sans-serif", fontSize: 13, color: "rgba(255,255,255,0.8)", margin: "0 0 10px" }}>Referral Code Community</p>
          <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
            <div style={{ display: "flex", gap: 2 }}>
              {[1,2,3,4,5].map(i => <StarIcon key={i} />)}
            </div>
            <span style={{ fontFamily: "'Inter', sans-serif", fontSize: 12, color: "rgba(255,255,255,0.9)" }}>4.9 · 12.4K ratings</span>
          </div>
        </div>
        <button style={{
          background: "white",
          color: "#0EA5E9",
          border: "none",
          borderRadius: 20,
          padding: "8px 22px",
          fontFamily: "'Nunito', sans-serif",
          fontWeight: 800,
          fontSize: 14,
          cursor: "pointer",
        }}>GET</button>
      </div>

      <div style={{ padding: "20px 24px 24px" }}>
        <div style={{ display: "flex", gap: 24, marginBottom: 20 }}>
          {[
            { label: "CATEGORY", value: "Social" },
            { label: "SIZE", value: "34.2 MB" },
            { label: "AGE", value: "4+" },
            { label: "DEVELOPER", value: "Ripple Inc." },
          ].map(item => (
            <div key={item.label}>
              <p style={{ fontFamily: "'Inter', sans-serif", fontSize: 10, fontWeight: 600, color: "#94A3B8", letterSpacing: "0.08em", textTransform: "uppercase" as const, margin: "0 0 2px" }}>{item.label}</p>
              <p style={{ fontFamily: "'Nunito', sans-serif", fontWeight: 700, fontSize: 13, color: "#0F172A", margin: 0 }}>{item.value}</p>
            </div>
          ))}
        </div>

        <p style={{ fontFamily: "'Inter', sans-serif", fontSize: 13, color: "#475569", lineHeight: 1.6, margin: "0 0 16px" }}>
          <strong style={{ color: "#0F172A" }}>Find codes. Share codes. Earn together.</strong><br />
          Ripple is the community for referral codes — discover codes your friends are using, share your own, and start earning rewards together.
        </p>

        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" as const }}>
          {["Referrals", "Savings", "Community", "Rewards", "Sharing"].map(tag => (
            <span key={tag} style={{
              padding: "4px 12px",
              background: "#F0FAFF",
              color: "#0EA5E9",
              borderRadius: 999,
              fontFamily: "'Inter', sans-serif",
              fontWeight: 500,
              fontSize: 12,
            }}>{tag}</span>
          ))}
        </div>
      </div>
    </div>
  );
}

export default function Board3BrandInAction() {
  const exportRef = useBoardExportReady(200);
  return (
    <div ref={exportRef} style={S.page}>
      <div style={S.header}>
        <div style={S.boardLabel}>Board 3 of 4 — Ripple Brand Kit</div>
        <h1 style={S.boardTitle}>Brand in Action</h1>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "320px 1fr", gap: 40, alignItems: "start" }}>
        <div>
          <h3 style={S.sectionTitle}>Home / Feed Screen</h3>
          <PhoneMockup />
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: 32 }}>
          <div>
            <h3 style={S.sectionTitle}>Share Sheet / Referral Card</h3>
            <ShareCard />
          </div>

          <div>
            <h3 style={S.sectionTitle}>App Store Listing</h3>
            <AppStoreListing />
          </div>
        </div>
      </div>

      <div style={{ marginTop: 40 }}>
        <h2 style={{ fontFamily: "'Nunito', sans-serif", fontSize: 20, fontWeight: 800, color: "#0F172A", marginBottom: 16, marginTop: 0 }}>Design Tokens — Export</h2>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 24 }}>
          <div style={{
            background: "#FFFFFF", borderRadius: 16, padding: 24,
            boxShadow: "0 1px 3px rgba(14,165,233,0.08), 0 4px 16px rgba(14,165,233,0.06)",
          }}>
            <h3 style={{ fontFamily: "'Nunito', sans-serif", fontWeight: 700, fontSize: 13, color: "#64748B", letterSpacing: "0.08em", textTransform: "uppercase" as const, marginBottom: 12, marginTop: 0 }}>CSS Custom Properties</h3>
            <pre style={{ background: "#0F172A", color: "#7DD3FC", borderRadius: 10, padding: 14, fontSize: 11, lineHeight: 1.7, overflowX: "auto" as const, fontFamily: "'JetBrains Mono', monospace", margin: 0, whiteSpace: "pre-wrap" as const }}>{`:root {
  --ripple-primary:      #0EA5E9; /* share buttons, links */
  --ripple-primary-dark: #0369A1; /* hover, focus states */
  --ripple-accent:       #F97316; /* CTA share button */
  --ripple-bg:           #F0FAFF; /* feed background */
  --ripple-surface:      #FFFFFF; /* cards */
  --ripple-text:         #0F172A; /* headings */
  --ripple-text-muted:   #64748B; /* secondary text */
  --ripple-code-bg:      #F0FAFF; /* referral code chips */
  --ripple-font-display: 'Nunito', sans-serif;
  --ripple-font-body:    'Inter', sans-serif;
  --ripple-font-code:    'JetBrains Mono', monospace;
  --ripple-radius-card:  14px;
  --ripple-radius-chip:  8px;
  --ripple-radius-sheet: 24px;
}`}</pre>
          </div>
          <div style={{
            background: "#FFFFFF", borderRadius: 16, padding: 24,
            boxShadow: "0 1px 3px rgba(14,165,233,0.08), 0 4px 16px rgba(14,165,233,0.06)",
          }}>
            <h3 style={{ fontFamily: "'Nunito', sans-serif", fontWeight: 700, fontSize: 13, color: "#64748B", letterSpacing: "0.08em", textTransform: "uppercase" as const, marginBottom: 12, marginTop: 0 }}>Tailwind Config — theme.extend</h3>
            <pre style={{ background: "#0F172A", color: "#86EFAC", borderRadius: 10, padding: 14, fontSize: 11, lineHeight: 1.7, overflowX: "auto" as const, fontFamily: "'JetBrains Mono', monospace", margin: 0, whiteSpace: "pre-wrap" as const }}>{`// tailwind.config.ts
export default {
  theme: {
    extend: {
      colors: {
        ripple: {
          primary: '#0EA5E9',
          'primary-dark': '#0369A1',
          accent:  '#F97316',
          bg:      '#F0FAFF',
          surface: '#FFFFFF',
          text:    '#0F172A',
          muted:   '#64748B',
          'code-bg': '#F0FAFF',
        },
      },
      fontFamily: {
        display: ["'Nunito'", 'sans-serif'],
        body:    ["'Inter'",  'sans-serif'],
        code:    ["'JetBrains Mono'", 'monospace'],
      },
      borderRadius: {
        'ripple-card':  '14px',
        'ripple-chip':  '8px',
        'ripple-sheet': '24px',
      },
    },
  },
};`}</pre>
          </div>
        </div>
      </div>
    </div>
  );
}

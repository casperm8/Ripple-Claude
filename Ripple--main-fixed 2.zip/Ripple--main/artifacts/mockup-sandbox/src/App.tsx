import { useEffect, useState, useRef, useCallback, type ComponentType } from "react";
import { createRoot } from "react-dom/client";
import { PdfExportContext } from "./PdfExportContext";

import { modules as discoveredModules } from "./.generated/mockup-components";
import { exportBrandKitPdf, type BoardExportEntry } from "./exportBrandKitPdf";

type ModuleMap = Record<string, () => Promise<Record<string, unknown>>>;

function _resolveComponent(
  mod: Record<string, unknown>,
  name: string,
): ComponentType | undefined {
  const fns = Object.values(mod).filter(
    (v) => typeof v === "function",
  ) as ComponentType[];
  return (
    (mod.default as ComponentType) ||
    (mod.Preview as ComponentType) ||
    (mod[name] as ComponentType) ||
    fns[fns.length - 1]
  );
}

function PreviewRenderer({
  componentPath,
  modules,
}: {
  componentPath: string;
  modules: ModuleMap;
}) {
  const [Component, setComponent] = useState<ComponentType | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;

    setComponent(null);
    setError(null);

    async function loadComponent(): Promise<void> {
      const key = `./components/mockups/${componentPath}.tsx`;
      const loader = modules[key];
      if (!loader) {
        setError(`No component found at ${componentPath}.tsx`);
        return;
      }

      try {
        const mod = await loader();
        if (cancelled) {
          return;
        }
        const name = componentPath.split("/").pop()!;
        const comp = _resolveComponent(mod, name);
        if (!comp) {
          setError(
            `No exported React component found in ${componentPath}.tsx\n\nMake sure the file has at least one exported function component.`,
          );
          return;
        }
        setComponent(() => comp);
      } catch (e) {
        if (cancelled) {
          return;
        }

        const message = e instanceof Error ? e.message : String(e);
        setError(`Failed to load preview.\n${message}`);
      }
    }

    void loadComponent();

    return () => {
      cancelled = true;
    };
  }, [componentPath, modules]);

  if (error) {
    return (
      <pre style={{ color: "red", padding: "2rem", fontFamily: "system-ui" }}>
        {error}
      </pre>
    );
  }

  if (!Component) return null;

  return <Component />;
}

function getBasePath(): string {
  const base = import.meta.env.BASE_URL.replace(/\/$/, "");
  if (base === "") {
    console.warn(
      "[Canvas] BASE_URL resolved to an empty string — BASE_PATH is set to \"/\" " +
      "(or is unset). Copy Link URLs will be rooted at the origin without the " +
      "canvas sub-path prefix. If this canvas is mounted at a sub-path " +
      "(e.g. /__mockup/), set BASE_PATH to that value so copied links " +
      "correctly include the sub-path.",
    );
  }
  return base;
}

function getPreviewExamplePath(): string {
  const basePath = getBasePath();
  return `${basePath}/preview/ComponentName`;
}

const RIPPLE_BOARDS = [
  {
    id: "board1",
    path: "ripple/Board1ColorTypography",
    label: "Board 1",
    title: "Color & Typography",
    description: "Palette, type specimen, contrast audit, dark mode",
    color: "#0EA5E9",
  },
  {
    id: "board2",
    path: "ripple/Board2LogoConcepts",
    label: "Board 2",
    title: "Logo Concepts",
    description: "Wordmark, icon+text, icon-only, app icon, SVG source",
    color: "#0369A1",
  },
  {
    id: "board3",
    path: "ripple/Board3BrandInAction",
    label: "Board 3",
    title: "Brand in Action",
    description: "Mobile feed, share card, app store listing",
    color: "#F97316",
  },
  {
    id: "board4",
    path: "ripple/Board4Guidelines",
    label: "Board 4",
    title: "Brand Guidelines",
    description: "Color rules, type hierarchy, voice & tone, motion guidelines, accessibility",
    color: "#0284C7",
  },
];

/** Maximum ms to wait for a single board to fully render before aborting the export. */
const BOARD_RENDER_TIMEOUT_MS = 8000;
/** Minimum settle time (ms) after images load, to let CSS animations paint. */
const MIN_SETTLE_MS = 400;
/**
 * How long `waitForExportReadySignal` will wait for a board to set
 * `data-export-ready="1"` before falling back to a silent capture.
 * This is intentionally longer than MIN_SETTLE_MS so boards that are slow
 * to signal (e.g. waiting for real animation completion) still get a chance,
 * while boards that don't implement the contract at all are still captured
 * within a bounded window. The outer BOARD_RENDER_TIMEOUT_MS remains the
 * hard cap that aborts the entire render.
 */
const BOARD_READY_WAIT_MS = 3000;

/**
 * Returns the effective board render timeout (ms).
 * E2E tests can call `window.__setBoardRenderTimeout(ms)` before clicking a
 * download button to exercise the timeout/error path without modifying production
 * code paths or relying on URL-parameter forwarding through the dev proxy.
 */
let _testBoardTimeoutOverride: number | null = null;
if (typeof window !== "undefined") {
  (window as unknown as Record<string, unknown>).__setBoardRenderTimeout = (ms: number) => {
    _testBoardTimeoutOverride = typeof ms === "number" && ms > 0 ? ms : null;
  };
  (window as unknown as Record<string, unknown>).__clearBoardRenderTimeout = () => {
    _testBoardTimeoutOverride = null;
  };
}

function getBoardRenderTimeoutMs(): number {
  if (_testBoardTimeoutOverride !== null) return _testBoardTimeoutOverride;
  return BOARD_RENDER_TIMEOUT_MS;
}

type ExportState = "idle" | "loading" | "done" | "partial" | "error";

function BoardDownloadButton({
  board,
  modules,
}: {
  board: (typeof RIPPLE_BOARDS)[number];
  modules: ModuleMap;
}) {
  const [state, setState] = useState<ExportState>("idle");
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const containerRef = useRef<HTMLElement | null>(null);

  const handleDownload = useCallback(async () => {
    setState("loading");
    setErrorMsg(null);
    containerRef.current = null;

    try {
      const el = await renderBoardToElement(modules, board.path, getBoardRenderTimeoutMs());
      containerRef.current = el;

      const slug = board.title.replace(/[^a-zA-Z0-9]+/g, "-");
      await exportBrandKitPdf(
        [{ element: el, title: board.title }],
        undefined,
        `Ripple-${slug}.pdf`,
      );

      setState("done");
      setTimeout(() => setState("idle"), 3000);
    } catch (err) {
      console.error(`PDF export failed for ${board.title}:`, err);
      const msg = err instanceof Error ? err.message : "Export failed";
      setErrorMsg(msg);
      setState("error");
      setTimeout(() => { setState("idle"); setErrorMsg(null); }, 4000);
    } finally {
      if (containerRef.current?.parentNode) {
        containerRef.current.parentNode.removeChild(containerRef.current);
      }
      containerRef.current = null;
    }
  }, [board, modules]);

  const isLoading = state === "loading";
  const label =
    state === "loading"
      ? "…"
      : state === "done"
        ? "✓"
        : state === "error"
          ? "✗"
          : "⬇";

  const bg =
    state === "done"
      ? "#16A34A"
      : state === "error"
        ? "#DC2626"
        : board.color;

  return (
    <button
      onClick={handleDownload}
      disabled={isLoading}
      title={
        state === "done"
          ? "Downloaded!"
          : state === "error"
            ? (errorMsg ?? "Export failed")
            : `Download ${board.title} as PDF`
      }
      style={{
        fontFamily: "'Nunito', sans-serif",
        fontWeight: 700,
        fontSize: 12,
        color: "#FFFFFF",
        background: bg,
        border: "none",
        borderRadius: 6,
        padding: "4px 10px",
        cursor: isLoading ? "not-allowed" : "pointer",
        opacity: isLoading ? 0.7 : 1,
        transition: "background 0.2s, opacity 0.2s",
        whiteSpace: "nowrap",
        display: "flex",
        alignItems: "center",
        gap: 4,
        lineHeight: 1,
      }}
    >
      {isLoading ? (
        <span style={{
          display: "inline-block",
          width: 10,
          height: 10,
          border: "2px solid rgba(255,255,255,0.4)",
          borderTopColor: "#fff",
          borderRadius: "50%",
          animation: "spin 0.7s linear infinite",
        }} />
      ) : label}
      {!isLoading && state === "idle" && "PDF"}
    </button>
  );
}

/**
 * Returns a promise that resolves once the board signals it is ready for
 * capture via `data-export-ready="1"` on a descendant element, or after
 * MIN_SETTLE_MS milliseconds if no signal arrives (fallback for boards that
 * have not yet adopted the readiness contract).
 */
function waitForExportReadySignal(container: HTMLElement): Promise<void> {
  const isReady = () =>
    container.dataset.exportReady === "1" ||
    container.querySelector('[data-export-ready="1"]') !== null;

  if (isReady()) return Promise.resolve();

  return new Promise<void>((resolve) => {
    const observer = new MutationObserver(() => {
      if (isReady()) {
        observer.disconnect();
        clearTimeout(fallbackTimer);
        resolve();
      }
    });
    observer.observe(container, {
      attributes: true,
      subtree: true,
      attributeFilter: ["data-export-ready"],
    });

    const fallbackTimer = setTimeout(() => {
      observer.disconnect();
      resolve();
    }, BOARD_READY_WAIT_MS);
  });
}

/**
 * Waits until all `<img>` elements inside `container` have loaded (or errored),
 * then waits for the board to signal readiness via `data-export-ready="1"`.
 * Falls back to MIN_SETTLE_MS if no signal arrives (e.g. older board components
 * that have not yet adopted the readiness contract).
 */
function waitForBoardReady(container: HTMLElement): Promise<void> {
  return new Promise<void>((resolve, reject) => {
    async function settle(): Promise<void> {
      const images = Array.from(container.querySelectorAll<HTMLImageElement>("img"));
      const pending = images.filter((img) => !img.complete);

      if (pending.length > 0) {
        await Promise.all(
          pending.map(
            (img) =>
              new Promise<void>((res) => {
                img.addEventListener("load", () => res(), { once: true });
                img.addEventListener("error", () => res(), { once: true });
              }),
          ),
        );
      }

      await waitForExportReadySignal(container);
      resolve();
    }

    settle().catch(reject);
  });
}

async function renderBoardToElement(
  modules: ModuleMap,
  boardPath: string,
  timeoutMs = BOARD_RENDER_TIMEOUT_MS,
): Promise<HTMLElement> {
  const key = `./components/mockups/${boardPath}.tsx`;
  const loader = modules[key];
  if (!loader) throw new Error(`No module for ${boardPath}`);

  const mod = await loader();
  const name = boardPath.split("/").pop()!;
  const comp = _resolveComponent(mod, name);
  if (!comp) throw new Error(`No component in ${boardPath}`);

  const container = document.createElement("div");
  container.style.position = "fixed";
  container.style.left = "-9999px";
  container.style.top = "0";
  container.style.width = "1440px";
  container.style.background = "#F0FAFF";
  container.style.zIndex = "-1";
  document.body.appendChild(container);

  const Comp = comp;
  const root = createRoot(container);

  let cancelled = false;

  const renderPromise = (async () => {
    await new Promise<void>((resolve) => {
      root.render(
        <PdfExportContext.Provider value={true}>
          <Comp />
        </PdfExportContext.Provider>,
      );
      requestAnimationFrame(() => requestAnimationFrame(() => resolve()));
    });
    await waitForBoardReady(container);
    if (cancelled) throw new Error("Board render cancelled due to timeout");
    return container;
  })();

  let timeoutId: ReturnType<typeof setTimeout>;
  const timeoutPromise = new Promise<never>((_, reject) => {
    timeoutId = setTimeout(() => {
      cancelled = true;
      reject(
        new Error(
          `Board "${boardPath}" timed out after ${timeoutMs / 1000} s — ` +
          `it may be loading remote fonts or running a long animation.`,
        ),
      );
    }, timeoutMs);
  });

  try {
    return await Promise.race([renderPromise, timeoutPromise]);
  } catch (err) {
    if (container.parentNode) container.parentNode.removeChild(container);
    throw err;
  } finally {
    clearTimeout(timeoutId!);
  }
}

/** Creates an off-screen placeholder element for a board that failed to render. */
function createFailedBoardPlaceholder(title: string): HTMLElement {
  const el = document.createElement("div");
  el.style.cssText =
    "position:fixed;left:-9999px;top:0;width:1440px;height:900px;" +
    "background:#F0FAFF;display:flex;flex-direction:column;" +
    "align-items:center;justify-content:center;gap:12px;z-index:-1;";

  const heading = document.createElement("p");
  heading.textContent = title;
  heading.style.cssText =
    "font-family:sans-serif;font-size:24px;font-weight:700;color:#64748B;margin:0;";

  const sub = document.createElement("p");
  sub.textContent = "This board failed to render and was skipped.";
  sub.style.cssText =
    "font-family:sans-serif;font-size:14px;color:#94A3B8;margin:0;";

  el.appendChild(heading);
  el.appendChild(sub);
  document.body.appendChild(el);
  return el;
}

function ExportButton({ modules }: { modules: ModuleMap }) {
  const [exportState, setExportState] = useState<ExportState>("idle");
  const [progress, setProgress] = useState(0);
  const [failedBoardNames, setFailedBoardNames] = useState<string[]>([]);
  const containersRef = useRef<HTMLElement[]>([]);

  const handleExport = useCallback(async () => {
    setExportState("loading");
    setProgress(0);
    setFailedBoardNames([]);
    containersRef.current = [];

    try {
      const entries: BoardExportEntry[] = [];
      const renderFailures: string[] = [];

      for (let i = 0; i < RIPPLE_BOARDS.length; i++) {
        const board = RIPPLE_BOARDS[i];
        setProgress(Math.round((i / RIPPLE_BOARDS.length) * 70));

        try {
          const el = await renderBoardToElement(modules, board.path, getBoardRenderTimeoutMs());
          containersRef.current.push(el);
          entries.push({ element: el, title: board.title });
        } catch (renderErr) {
          console.error(`[PDF export] Board "${board.title}" failed to render:`, renderErr);
          renderFailures.push(board.title);
          const placeholder = createFailedBoardPlaceholder(board.title);
          containersRef.current.push(placeholder);
          entries.push({ element: placeholder, title: board.title, failed: true });
        }
      }

      const { failedBoards: canvasFailures } = await exportBrandKitPdf(entries, (step, total) => {
        setProgress(70 + Math.round((step / total) * 30));
      });

      const allFailed = [...new Set([...renderFailures, ...canvasFailures])];

      if (allFailed.length === 0) {
        setExportState("done");
        setTimeout(() => setExportState("idle"), 3000);
      } else if (allFailed.length < RIPPLE_BOARDS.length) {
        setFailedBoardNames(allFailed);
        setExportState("partial");
        setTimeout(() => setExportState("idle"), 6000);
      } else {
        setFailedBoardNames(allFailed);
        setExportState("error");
        setTimeout(() => setExportState("idle"), 6000);
      }
    } catch (err) {
      console.error("[PDF export] Unexpected failure:", err);
      setExportState("error");
      setTimeout(() => setExportState("idle"), 4000);
    } finally {
      for (const el of containersRef.current) {
        if (el.parentNode) el.parentNode.removeChild(el);
      }
      containersRef.current = [];
    }
  }, [modules]);

  const isLoading = exportState === "loading";

  const label =
    exportState === "loading"
      ? `Exporting… ${progress}%`
      : exportState === "done"
        ? "✓ Downloaded!"
        : exportState === "partial"
          ? `⚠ Downloaded (${failedBoardNames.length} board${failedBoardNames.length > 1 ? "s" : ""} skipped)`
          : exportState === "error"
            ? failedBoardNames.length > 0
              ? `✗ All boards failed`
              : "✗ Export failed"
            : "⬇ Download PDF";

  const bg =
    exportState === "done"
      ? "#16A34A"
      : exportState === "partial"
        ? "#D97706"
        : exportState === "error"
          ? "#DC2626"
          : "#0EA5E9";

  const tooltip =
    exportState === "partial"
      ? `Skipped: ${failedBoardNames.join(", ")}`
      : exportState === "error" && failedBoardNames.length > 0
        ? `Failed: ${failedBoardNames.join(", ")}`
        : undefined;

  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 4 }}>
      <button
        onClick={handleExport}
        disabled={isLoading}
        title={tooltip}
        style={{
          fontFamily: "'Nunito', sans-serif",
          fontWeight: 700,
          fontSize: 13,
          color: "#FFFFFF",
          background: bg,
          border: "none",
          borderRadius: 10,
          padding: "9px 18px",
          cursor: isLoading ? "not-allowed" : "pointer",
          opacity: isLoading ? 0.8 : 1,
          transition: "background 0.2s, opacity 0.2s",
          whiteSpace: "nowrap",
          display: "flex",
          alignItems: "center",
          gap: 6,
          minWidth: 148,
          justifyContent: "center",
        }}
      >
        {isLoading && (
          <span style={{
            display: "inline-block",
            width: 13,
            height: 13,
            border: "2px solid rgba(255,255,255,0.4)",
            borderTopColor: "#fff",
            borderRadius: "50%",
            animation: "spin 0.7s linear infinite",
          }} />
        )}
        {label}
        <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
      </button>
      {(exportState === "partial" || (exportState === "error" && failedBoardNames.length > 0)) && (
        <p style={{
          fontFamily: "'Inter', sans-serif",
          fontSize: 11,
          color: exportState === "partial" ? "#D97706" : "#DC2626",
          margin: 0,
          textAlign: "right",
          maxWidth: 260,
        }}>
          {exportState === "partial" ? "Skipped" : "Failed"}: {failedBoardNames.join(", ")}
        </p>
      )}
    </div>
  );
}

function BoardCopyLinkButton({
  board,
}: {
  board: (typeof RIPPLE_BOARDS)[number];
}) {
  const [copied, setCopied] = useState(false);
  const [copyFailed, setCopyFailed] = useState(false);
  const [failedUrl, setFailedUrl] = useState<string | null>(null);
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, []);

  const handleCopy = useCallback(async () => {
    const basePath = getBasePath();
    const url = `${window.location.origin}${basePath}/preview/${board.path}`;

    const showResult = (success: boolean) => {
      if (timerRef.current) clearTimeout(timerRef.current);
      if (success) {
        setCopied(true);
        setCopyFailed(false);
        setFailedUrl(null);
        timerRef.current = setTimeout(() => setCopied(false), 2000);
      } else {
        setCopyFailed(true);
        setCopied(false);
        setFailedUrl(url);
        timerRef.current = setTimeout(() => {
          setCopyFailed(false);
          setFailedUrl(null);
        }, 2000);
      }
    };

    try {
      await navigator.clipboard.writeText(url);
      showResult(true);
    } catch {
      // Fallback for browsers that block the Clipboard API
      const ta = document.createElement("textarea");
      ta.value = url;
      ta.style.cssText = "position:fixed;left:-9999px;top:0;opacity:0;";
      document.body.appendChild(ta);
      try {
        ta.focus();
        ta.select();
        const ok = document.execCommand("copy");
        showResult(ok);
      } catch {
        // execCommand unavailable (sandboxed iframe, strict Firefox, etc.)
        showResult(false);
      } finally {
        document.body.removeChild(ta);
      }
    }
  }, [board]);

  return (
    <div style={{ position: "relative", display: "inline-block" }}>
      <button
        onClick={handleCopy}
        aria-label={copied ? "Link copied!" : copyFailed ? "Copy failed" : `Copy link to ${board.title}`}
        title={copied ? "Link copied!" : copyFailed ? "Copy failed" : `Copy link to ${board.title}`}
        style={{
          fontFamily: "'Nunito', sans-serif",
          fontWeight: 700,
          fontSize: 12,
          color: copied ? "#16A34A" : copyFailed ? "#DC2626" : board.color,
          background: copied ? "#16A34A18" : copyFailed ? "#DC262618" : board.color + "12",
          border: "none",
          borderRadius: 6,
          padding: "4px 10px",
          cursor: "pointer",
          transition: "background 0.2s, color 0.2s",
          whiteSpace: "nowrap",
          display: "flex",
          alignItems: "center",
          gap: 4,
          lineHeight: 1,
        }}
      >
        {copied ? (
          <>✓ Copied!</>
        ) : copyFailed ? (
          <>✗ Error</>
        ) : (
        <>
          <svg
            width="11"
            height="11"
            viewBox="0 0 16 16"
            fill="none"
            style={{ flexShrink: 0 }}
          >
            <path
              d="M6.5 3.5H3a1 1 0 0 0-1 1v8a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1v-3.5"
              stroke="currentColor"
              strokeWidth="1.6"
              strokeLinecap="round"
            />
            <path
              d="M9.5 1.5h5v5"
              stroke="currentColor"
              strokeWidth="1.6"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
            <path
              d="M14.5 1.5 8 8"
              stroke="currentColor"
              strokeWidth="1.6"
              strokeLinecap="round"
            />
          </svg>
          Link
        </>
      )}
      </button>
      {failedUrl && (
        <div
          style={{
            position: "absolute",
            top: "calc(100% + 6px)",
            right: 0,
            background: "#1E293B",
            color: "#F1F5F9",
            borderRadius: 6,
            padding: "6px 8px",
            fontSize: 11,
            fontFamily: "'Nunito', sans-serif",
            whiteSpace: "nowrap",
            zIndex: 100,
            boxShadow: "0 4px 12px rgba(0,0,0,0.25)",
            maxWidth: 320,
            overflow: "hidden",
            textOverflow: "ellipsis",
          }}
          title={failedUrl}
        >
          <span style={{ opacity: 0.7, marginRight: 4 }}>Copy manually:</span>
          {failedUrl}
        </div>
      )}
    </div>
  );
}

function RippleCanvasGallery({ modules }: { modules: ModuleMap }) {
  const basePath = getBasePath();

  return (
    <div style={{
      minHeight: "100vh",
      background: "#F0FAFF",
      fontFamily: "'Inter', sans-serif",
      padding: "40px 48px 64px",
      boxSizing: "border-box",
    }}>
      <div style={{
        marginBottom: 40,
        paddingBottom: 24,
        borderBottom: "2px solid #E0F4FE",
        display: "flex",
        alignItems: "center",
        gap: 20,
      }}>
        <svg width="40" height="40" viewBox="0 0 40 40" fill="none">
          <circle cx="20" cy="20" r="5.5" fill="#0EA5E9" />
          <circle cx="20" cy="20" r="11" stroke="#0EA5E9" strokeWidth="2.5" opacity="0.7" />
          <circle cx="20" cy="20" r="17" stroke="#0EA5E9" strokeWidth="2" opacity="0.35" />
          <circle cx="20" cy="20" r="19" stroke="#0EA5E9" strokeWidth="1.2" opacity="0.18" />
        </svg>
        <div>
          <p style={{
            fontFamily: "'Nunito', sans-serif",
            fontWeight: 700,
            fontSize: 12,
            letterSpacing: "0.12em",
            textTransform: "uppercase",
            color: "#0EA5E9",
            margin: "0 0 4px",
          }}>Ripple — Brand Identity Kit</p>
          <h1 style={{
            fontFamily: "'Nunito', sans-serif",
            fontWeight: 800,
            fontSize: 28,
            color: "#0F172A",
            margin: 0,
            lineHeight: 1.2,
          }}>Visual Design System Canvas</h1>
        </div>
        <div style={{ marginLeft: "auto", display: "flex", alignItems: "center", gap: 20 }}>
          <div style={{ textAlign: "right" }}>
            <p style={{ fontFamily: "'Inter', sans-serif", fontSize: 12, color: "#94A3B8", margin: 0 }}>4 boards · June 2026</p>
            <p style={{ fontFamily: "'Nunito', sans-serif", fontSize: 13, fontWeight: 600, color: "#64748B", margin: "2px 0 0" }}>"Every referral creates a ripple."</p>
          </div>
          <ExportButton modules={modules} />
        </div>
      </div>

      <div style={{
        display: "grid",
        gridTemplateColumns: "1fr 1fr",
        gap: 28,
      }}>
        {RIPPLE_BOARDS.map((board) => {
          const iframeUrl = `${basePath}/preview/${board.path}`;
          return (
            <div key={board.id} style={{
              background: "#FFFFFF",
              borderRadius: 20,
              overflow: "hidden",
              boxShadow: "0 2px 8px rgba(14,165,233,0.08), 0 8px 32px rgba(14,165,233,0.06)",
              border: "1px solid #E0F4FE",
              display: "flex",
              flexDirection: "column",
            }}>
              <div style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                padding: "14px 20px",
                background: "#FAFEFF",
                borderBottom: "1px solid #E0F4FE",
              }}>
                <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                  <div style={{
                    width: 10, height: 10, borderRadius: 999,
                    background: board.color,
                  }} />
                  <div>
                    <span style={{
                      fontFamily: "'Inter', sans-serif",
                      fontSize: 10,
                      fontWeight: 600,
                      letterSpacing: "0.08em",
                      textTransform: "uppercase",
                      color: "#94A3B8",
                      marginRight: 8,
                    }}>{board.label}</span>
                    <span style={{
                      fontFamily: "'Nunito', sans-serif",
                      fontWeight: 800,
                      fontSize: 14,
                      color: "#0F172A",
                    }}>{board.title}</span>
                  </div>
                </div>
                <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                  <BoardCopyLinkButton board={board} />
                  <BoardDownloadButton board={board} modules={modules} />
                  <a
                    href={iframeUrl}
                    target="_blank"
                    rel="noreferrer"
                    style={{
                      fontFamily: "'Nunito', sans-serif",
                      fontWeight: 700,
                      fontSize: 12,
                      color: board.color,
                      textDecoration: "none",
                      padding: "4px 10px",
                      borderRadius: 6,
                      background: board.color + "12",
                    }}
                  >
                    Open ↗
                  </a>
                </div>
              </div>

              <div style={{ padding: "0 20px 12px", paddingTop: 10, borderBottom: "1px solid #F0FAFF" }}>
                <p style={{
                  fontFamily: "'Inter', sans-serif",
                  fontSize: 12,
                  color: "#64748B",
                  margin: 0,
                }}>{board.description}</p>
              </div>

              <div style={{ flex: 1, position: "relative", minHeight: 640 }}>
                <iframe
                  src={iframeUrl}
                  title={board.title}
                  style={{
                    width: "100%",
                    height: "100%",
                    minHeight: 640,
                    border: "none",
                    display: "block",
                  }}
                  loading="lazy"
                />
              </div>
            </div>
          );
        })}
      </div>

      <div style={{
        marginTop: 40,
        padding: "20px 28px",
        background: "#FFFFFF",
        borderRadius: 16,
        border: "1px solid #E0F4FE",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
      }}>
        <div>
          <p style={{ fontFamily: "'Nunito', sans-serif", fontWeight: 700, fontSize: 14, color: "#0F172A", margin: "0 0 4px" }}>Design Tokens</p>
          <p style={{ fontFamily: "'Inter', sans-serif", fontSize: 12, color: "#64748B", margin: 0 }}>CSS custom properties and Tailwind config tokens are embedded in each board's source file</p>
        </div>
        <div style={{ display: "flex", gap: 24 }}>
          {[
            { label: "Primary", hex: "#0EA5E9" },
            { label: "Accent", hex: "#F97316" },
            { label: "Background", hex: "#F0FAFF" },
            { label: "Text", hex: "#0F172A" },
          ].map(t => (
            <div key={t.label} style={{ display: "flex", alignItems: "center", gap: 6 }}>
              <div style={{ width: 14, height: 14, borderRadius: 4, background: t.hex, boxShadow: "inset 0 0 0 1px rgba(0,0,0,0.1)" }} />
              <span style={{ fontFamily: "'Inter', sans-serif", fontSize: 12, color: "#64748B" }}>{t.label}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function Gallery() {
  return <RippleCanvasGallery modules={discoveredModules} />;
}

function getPreviewPath(): string | null {
  const basePath = getBasePath();
  const { pathname } = window.location;
  const local =
    basePath && pathname.startsWith(basePath)
      ? pathname.slice(basePath.length) || "/"
      : pathname;
  const match = local.match(/^\/preview\/(.+)$/);
  return match ? match[1] : null;
}

function App() {
  const previewPath = getPreviewPath();

  if (previewPath) {
    return (
      <PreviewRenderer
        componentPath={previewPath}
        modules={discoveredModules}
      />
    );
  }

  return <Gallery />;
}

export default App;

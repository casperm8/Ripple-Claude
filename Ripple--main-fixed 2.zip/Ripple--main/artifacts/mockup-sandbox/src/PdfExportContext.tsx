import { createContext, useContext } from "react";

/**
 * Set to `true` inside the off-screen container used by renderBoardToElement.
 * Components that run framer-motion animations should read this context and
 * render statically (at base/visible values) so the PDF snapshot is clean.
 */
export const PdfExportContext = createContext(false);

export function usePdfExport(): boolean {
  return useContext(PdfExportContext);
}

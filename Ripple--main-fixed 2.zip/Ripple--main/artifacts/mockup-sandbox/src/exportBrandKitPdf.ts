import html2canvas from "html2canvas";
import jsPDF from "jspdf";

export interface BoardExportEntry {
  element: HTMLElement;
  title: string;
  /** Pre-marked failed: rendering never produced a valid element. */
  failed?: boolean;
}

export interface BoardExportResult {
  /** Titles of boards that could not be captured. */
  failedBoards: string[];
}

function addPlaceholderPage(pdf: jsPDF, title: string, w: number, h: number): void {
  pdf.setFillColor(240, 250, 255);
  pdf.rect(0, 0, w, h, "F");

  pdf.setDrawColor(200, 225, 240);
  pdf.setLineWidth(0.5);
  pdf.rect(8, 8, w - 16, h - 16, "S");

  pdf.setFont("helvetica", "bold");
  pdf.setFontSize(14);
  pdf.setTextColor(100, 116, 139);
  pdf.text(title, w / 2, h / 2 - 7, { align: "center" });

  pdf.setFont("helvetica", "normal");
  pdf.setFontSize(9);
  pdf.setTextColor(148, 163, 184);
  pdf.text("This board failed to render and was skipped.", w / 2, h / 2 + 5, { align: "center" });
}

export async function exportBrandKitPdf(
  boards: BoardExportEntry[],
  onProgress?: (step: number, total: number) => void,
  filename = "Ripple-Brand-Kit.pdf",
): Promise<BoardExportResult> {
  const A4_W = 297;
  const A4_H = 210;
  const pdf = new jsPDF({ orientation: "landscape", unit: "mm", format: "a4" });
  const failedBoards: string[] = [];

  for (let i = 0; i < boards.length; i++) {
    const { element, title, failed } = boards[i];
    onProgress?.(i, boards.length);

    if (i > 0) pdf.addPage();

    if (failed) {
      failedBoards.push(title);
      addPlaceholderPage(pdf, title, A4_W, A4_H);
      continue;
    }

    try {
      const canvas = await html2canvas(element, {
        scale: 2,
        useCORS: true,
        allowTaint: true,
        backgroundColor: "#F0FAFF",
        logging: false,
        windowWidth: element.scrollWidth,
        windowHeight: element.scrollHeight,
      });

      const imgData = canvas.toDataURL("image/jpeg", 0.92);
      const imgW = canvas.width;
      const imgH = canvas.height;

      const ratio = Math.min(A4_W / imgW, A4_H / imgH);
      const drawW = imgW * ratio;
      const drawH = imgH * ratio;
      const offsetX = (A4_W - drawW) / 2;
      const offsetY = (A4_H - drawH) / 2;

      pdf.addImage(imgData, "JPEG", offsetX, offsetY, drawW, drawH);
    } catch (err) {
      console.error(`[PDF export] Board "${title}" failed during canvas capture:`, err);
      failedBoards.push(title);
      addPlaceholderPage(pdf, title, A4_W, A4_H);
    }
  }

  onProgress?.(boards.length, boards.length);
  pdf.save(filename);
  return { failedBoards };
}

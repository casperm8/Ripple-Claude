/**
 * PDF Export regression tests — render-wait strategy
 *
 * Verifies that `renderBoardToElement` (which replaced a fixed 600 ms delay
 * with an image-load-aware wait with an 8 s hard timeout and 400 ms settle)
 * works correctly end-to-end for all four Ripple brand boards.
 *
 * Covered scenarios:
 *  1. Per-board "⬇ PDF" buttons — each triggers a real file download and the
 *     resulting PDF file is non-blank (file size > threshold, 1 page).
 *  2. Combined "⬇ Download PDF" button — progresses through "Exporting… X%",
 *     produces a download, and the PDF contains content (4 pages).
 *  3. DOM cleanup — off-screen render containers (position:fixed; left:-9999px)
 *     are removed from the page after each export, not leaked.
 *  4. Timeout error path — when a board's images stall and the timeout fires,
 *     the button surfaces a visible error (✗ state) rather than silently
 *     downloading a blank PDF.
 *
 * The `_boardTimeout` URL param (read by `getBoardRenderTimeoutMs()` in App.tsx)
 * lets tests inject a short timeout without touching production code paths.
 *
 * Run: pnpm --filter @workspace/mockup-sandbox test:e2e
 */

import * as fs from "fs";
import { test, expect } from "@playwright/test";

const BOARDS = [
  { title: "Color & Typography" },
  { title: "Logo Concepts" },
  { title: "Brand in Action" },
  { title: "Brand Guidelines" },
];

/** Maximum ms to wait for a single per-board export download to start. */
const PER_BOARD_EXPORT_TIMEOUT = 20_000;
/** Maximum ms to wait for the combined 4-board export download to start. */
const COMBINED_EXPORT_TIMEOUT = 60_000;
/** Time (ms) to wait after export for DOM cleanup to finish. */
const CLEANUP_SETTLE_MS = 1_500;

/**
 * Minimum acceptable PDF file size (bytes).
 * A jsPDF document with real html2canvas content is well over 50 KB.
 * A near-empty / blank PDF produced by a failed render is typically < 5 KB.
 */
const MIN_PDF_BYTES = 30_000;

/** Parse the number of /Type /Page entries from a PDF buffer (approximate). */
function countPdfPages(buf: Buffer): number {
  const text = buf.toString("latin1");
  const matches = text.match(/\/Type\s*\/Page\b/g);
  return matches ? matches.length : 0;
}

async function waitForPageReady(page: import("@playwright/test").Page): Promise<void> {
  await page.goto("/__mockup");
  await page.waitForLoadState("load");
  await expect(
    page.getByText("Visual Design System Canvas"),
    "Canvas page should load before running PDF tests",
  ).toBeVisible({ timeout: 15_000 });
}

test.describe("PDF Export — render-wait strategy", () => {
  for (const board of BOARDS) {
    test(`per-board export for "${board.title}" produces a non-blank PDF and cleans up DOM`, async ({
      page,
    }) => {
      test.setTimeout(PER_BOARD_EXPORT_TIMEOUT + 15_000);
      await waitForPageReady(page);

      const downloadButton = page.getByTitle(
        `Download ${board.title} as PDF`,
      );
      await expect(
        downloadButton,
        `Per-board ⬇ PDF button for "${board.title}" should be visible`,
      ).toBeVisible();

      const downloadPromise = page.waitForEvent("download", {
        timeout: PER_BOARD_EXPORT_TIMEOUT,
      });

      await downloadButton.click();

      await expect(
        downloadButton,
        `Button for "${board.title}" should enter loading state (disabled) after click`,
      ).toBeDisabled({ timeout: 3_000 });

      const download = await downloadPromise;

      expect(
        download.suggestedFilename(),
        `Download filename for "${board.title}" should match Ripple-<slug>.pdf`,
      ).toMatch(/^Ripple-.+\.pdf$/);

      const filePath = await download.path();
      expect(filePath, "Download should save to a local path").toBeTruthy();

      if (filePath) {
        const { size } = fs.statSync(filePath);
        expect(
          size,
          `PDF for "${board.title}" should be > ${MIN_PDF_BYTES} bytes — a near-zero size means html2canvas produced a blank canvas`,
        ).toBeGreaterThan(MIN_PDF_BYTES);

        const buf = fs.readFileSync(filePath);
        const pages = countPdfPages(buf);
        expect(
          pages,
          `Per-board PDF for "${board.title}" should contain exactly 1 page`,
        ).toBe(1);
      }

      await expect(
        downloadButton,
        `Button for "${board.title}" must re-enable after export completes`,
      ).toBeEnabled({ timeout: 8_000 });

      await page.waitForTimeout(CLEANUP_SETTLE_MS);

      const leakedElements = await page.evaluate(() =>
        Array.from(document.querySelectorAll<HTMLElement>("*")).filter(
          (el) =>
            el.style.position === "fixed" &&
            el.style.left === "-9999px",
        ).length,
      );
      expect(
        leakedElements,
        `No off-screen render containers should remain in DOM after "${board.title}" export`,
      ).toBe(0);
    });
  }

  test("combined download produces a 4-page PDF and cleans up DOM", async ({
    page,
  }) => {
    test.setTimeout(COMBINED_EXPORT_TIMEOUT + 15_000);
    await waitForPageReady(page);

    const exportButton = page.getByRole("button", { name: /⬇ Download PDF/i });
    await expect(
      exportButton,
      "Combined ⬇ Download PDF button should be visible in the header",
    ).toBeVisible();

    const downloadPromise = page.waitForEvent("download", {
      timeout: COMBINED_EXPORT_TIMEOUT,
    });

    await exportButton.click();

    await expect(
      page.getByRole("button", { name: /exporting/i }),
      "Button should show 'Exporting…' progress text while working",
    ).toBeVisible({ timeout: 8_000 });

    const download = await downloadPromise;

    expect(
      download.suggestedFilename(),
      "Combined PDF filename should be Ripple-Brand-Kit.pdf",
    ).toBe("Ripple-Brand-Kit.pdf");

    const filePath = await download.path();
    expect(filePath, "Download should save to a local path").toBeTruthy();

    if (filePath) {
      const { size } = fs.statSync(filePath);
      expect(
        size,
        `Combined PDF should be > ${MIN_PDF_BYTES} bytes — a near-zero size means one or more boards produced a blank canvas`,
      ).toBeGreaterThan(MIN_PDF_BYTES);

      const buf = fs.readFileSync(filePath);
      const pages = countPdfPages(buf);
      expect(
        pages,
        "Combined PDF should contain exactly 4 pages (one per board)",
      ).toBe(4);
    }

    await expect(
      exportButton,
      "Combined export button must return to idle '⬇ Download PDF' state after the export",
    ).toBeVisible({ timeout: 10_000 });

    await page.waitForTimeout(CLEANUP_SETTLE_MS);

    const leakedElements = await page.evaluate(() =>
      Array.from(document.querySelectorAll<HTMLElement>("*")).filter(
        (el) =>
          el.style.position === "fixed" &&
          el.style.left === "-9999px",
      ).length,
    );
    expect(
      leakedElements,
      "No off-screen render containers should remain in DOM after combined export",
    ).toBe(0);

    for (const board of BOARDS) {
      await expect(
        page.getByText(board.title),
        `Board card "${board.title}" should still be visible on the page after export`,
      ).toBeVisible();
    }
  });

  test("timeout error path — a 1 ms render timeout surfaces error on the button, not a silent blank PDF", async ({
    page,
  }) => {
    test.setTimeout(15_000);

    await waitForPageReady(page);

    // window.__setBoardRenderTimeout is registered by App.tsx for e2e testing.
    // Setting it to 1 ms forces the per-board render to always time out
    // (1 ms is shorter than even a single requestAnimationFrame tick),
    // exercising the error path without network interception or proxy issues.
    await page.evaluate(() => {
      (window as unknown as Record<string, unknown>).__setBoardRenderTimeout?.(1);
    });

    const downloadButton = page.getByTitle(
      "Download Color & Typography as PDF",
    );
    await expect(downloadButton, "Per-board ⬇ PDF button should be visible").toBeVisible();

    let downloadFired = false;
    page.once("download", () => { downloadFired = true; });

    await downloadButton.click();

    await expect(
      downloadButton,
      "Button should enter loading state after click",
    ).toBeDisabled({ timeout: 3_000 });

    // When the timeout fires, App.tsx sets state → "error" and puts the error
    // message in the button's `title` attribute. The locator is by title, so
    // we detect error state by looking for any button whose title contains
    // "timed out" (as set by renderBoardToElement's rejection message).
    const errorButton = page.locator('button[title*="timed out"]');
    await expect(
      errorButton,
      "A button should appear with a 'timed out' title — the error was not surfaced correctly",
    ).toBeVisible({ timeout: 5_000 });

    const titleAttr = await errorButton.getAttribute("title");
    expect(
      titleAttr,
      `Error button title should describe a timeout — got: "${titleAttr}"`,
    ).toMatch(/timed out/i);

    expect(
      downloadFired,
      "A file download must NOT be triggered when the board times out — that would be a silent blank PDF",
    ).toBe(false);

    await page.waitForTimeout(CLEANUP_SETTLE_MS);

    const leakedElements = await page.evaluate(() =>
      Array.from(document.querySelectorAll<HTMLElement>("*")).filter(
        (el) =>
          el.style.position === "fixed" &&
          el.style.left === "-9999px",
      ).length,
    );
    expect(
      leakedElements,
      "Off-screen render container must be cleaned up even when the board times out",
    ).toBe(0);
  });
});

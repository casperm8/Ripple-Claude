/**
 * Board 4 description visibility regression test
 *
 * The Board 4 description was extended to include "motion guidelines":
 *   "Color rules, type hierarchy, voice & tone, motion guidelines, accessibility"
 *
 * This test confirms the full description text is visible in the canvas index
 * without truncation, overflow, or clipping, and that surrounding cards are
 * not affected (no layout shift).
 *
 * Run: pnpm --filter @workspace/mockup-sandbox test:e2e
 */

import { test, expect } from "@playwright/test";

const BOARD4_DESCRIPTION =
  "Color rules, type hierarchy, voice & tone, motion guidelines, accessibility";

test.describe("Board 4 — description visibility after update", () => {
  test("Board 4 description is fully visible without truncation", async ({
    page,
  }) => {
    await page.goto("/__mockup");
    await page.waitForLoadState("networkidle");

    const descEl = page.getByText(BOARD4_DESCRIPTION, { exact: true });

    await expect(
      descEl,
      "Board 4 description should be present in the canvas index",
    ).toBeVisible({ timeout: 10_000 });

    const box = await descEl.boundingBox();
    expect(
      box,
      "Board 4 description element should have a measurable bounding box",
    ).not.toBeNull();

    expect(
      box!.width,
      "Board 4 description should have a positive width",
    ).toBeGreaterThan(0);

    expect(
      box!.height,
      "Board 4 description should have a positive height — it must not be clipped to zero",
    ).toBeGreaterThan(0);

    const isClipped = await descEl.evaluate((el) => {
      const rect = el.getBoundingClientRect();
      const parent = el.closest("[style*='overflow']") as HTMLElement | null;
      if (!parent) return false;
      const parentRect = parent.getBoundingClientRect();
      return rect.bottom > parentRect.bottom + 1 || rect.right > parentRect.right + 1;
    });

    expect(
      isClipped,
      "Board 4 description text should not be clipped by a parent overflow container",
    ).toBe(false);
  });

  test("All four board cards are present and no card is taller than the others by more than 50px", async ({
    page,
  }) => {
    await page.goto("/__mockup");
    await page.waitForLoadState("networkidle");

    const descriptions = [
      "Palette, type specimen, contrast audit, dark mode",
      "Wordmark, icon+text, icon-only, app icon, SVG source",
      "Mobile feed, share card, app store listing",
      BOARD4_DESCRIPTION,
    ];

    const heights: number[] = [];
    for (const text of descriptions) {
      const el = page.getByText(text, { exact: true });
      await expect(el, `Description "${text}" should be visible`).toBeVisible({
        timeout: 10_000,
      });
      const box = await el.boundingBox();
      expect(box).not.toBeNull();
      heights.push(box!.height);
    }

    const maxH = Math.max(...heights);
    const minH = Math.min(...heights);
    expect(
      maxH - minH,
      "No card description should be more than 50px taller than the shortest — a big gap signals unexpected wrapping",
    ).toBeLessThanOrEqual(50);
  });
});

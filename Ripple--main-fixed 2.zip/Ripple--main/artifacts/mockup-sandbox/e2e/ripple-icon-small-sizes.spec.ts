import { test, expect } from "@playwright/test";

/**
 * Minimum geometry thresholds that keep each ring visually distinct at
 * small favicon/app-icon sizes.  If AnimatedRippleIcon's ring fractions or
 * stroke-width fractions are changed these assertions will catch regressions.
 *
 * Calibrated against the actual design:
 *   RING_R_FRACTIONS  = [0.57, 0.86, 0.96]
 *   RING_SW_FRACTIONS = [0.071, 0.054, 0.036]
 *
 * At size=32 the tightest center-to-center ring gap is ~1.60 px (outer pair).
 * At size=24 it is ~1.20 px; at size=16 it is ~0.80 px.
 * The threshold below is set to half the minimum observed value, so a
 * meaningful accidental change (e.g. fractions becoming equal) is caught
 * while the intentional close-but-non-overlapping outer-ring design passes.
 */
const THRESHOLDS = {
  /** px – core fill circle must be at least this large or the dot disappears */
  minCoreRadius: 2,
  /** px – every ring stroke-width must be at least this thick */
  minStrokeWidth: 0.8,
  /**
   * px – minimum center-to-center gap between adjacent rings.
   * Current minimum is ~0.80 px (at size=16, outer pair). We use 0.4 px so
   * that rings which accidentally collapse to the same radius (gap → 0) are
   * caught, without failing on the intentional tight outer-ring spacing.
   */
  minRingCenterGap: 0.4,
};

/**
 * Reads the geometry of every <circle> inside the first SVG that is a
 * descendant of `containerSelector`.  Returns:
 *   coreRadius – radius of the filled centre dot
 *   rings      – the three stroke-only circles, sorted by radius ascending
 */
async function readIconGeometryInContainer(
  page: import("@playwright/test").Page,
  containerSelector: string,
  svgWidthAttr: string,
) {
  return page.evaluate(
    ([cSel, width]: [string, string]) => {
      const container = document.querySelector(cSel);
      if (!container) return null;

      const svg = container.querySelector<SVGSVGElement>(
        `svg[width="${width}"]`,
      );
      if (!svg) return null;

      const svgWidth = parseFloat(svg.getAttribute("width") ?? "0");
      const svgHeight = parseFloat(svg.getAttribute("height") ?? "0");

      const circles = Array.from(svg.querySelectorAll("circle"));
      const core = circles.find(
        (c) =>
          !c.getAttribute("stroke") || c.getAttribute("stroke") === "none",
      );
      const rings = circles
        .filter(
          (c) =>
            c.getAttribute("stroke") && c.getAttribute("stroke") !== "none",
        )
        .map((c) => ({
          r: parseFloat(c.getAttribute("r") ?? "0"),
          strokeWidth: parseFloat(c.getAttribute("stroke-width") ?? "0"),
        }))
        .sort((a, b) => a.r - b.r);

      return {
        svgWidth,
        svgHeight,
        coreRadius: parseFloat(core?.getAttribute("r") ?? "0"),
        rings,
      };
    },
    [containerSelector, svgWidthAttr] as [string, string],
  );
}

function assertIconGeometry(
  geo: Awaited<ReturnType<typeof readIconGeometryInContainer>>,
  expectedSize: number,
  label: string,
) {
  expect(geo, `[${label}] Could not read icon geometry — SVG not found`).not.toBeNull();
  if (!geo) return;

  expect(geo.svgWidth, `[${label}] SVG width`).toBe(expectedSize);
  expect(geo.svgHeight, `[${label}] SVG height`).toBe(expectedSize);

  expect(
    geo.coreRadius,
    `[${label}] Core dot radius ${geo.coreRadius.toFixed(2)} px is below ` +
      `minimum ${THRESHOLDS.minCoreRadius} px — the dot would be invisible`,
  ).toBeGreaterThanOrEqual(THRESHOLDS.minCoreRadius);

  expect(geo.rings, `[${label}] Expected 3 rings`).toHaveLength(3);

  for (let i = 0; i < geo.rings.length; i++) {
    const sw = geo.rings[i].strokeWidth;
    expect(
      sw,
      `[${label}] Ring ${i} stroke-width ${sw.toFixed(2)} px is below minimum ` +
        `${THRESHOLDS.minStrokeWidth} px — ring would be sub-pixel`,
    ).toBeGreaterThanOrEqual(THRESHOLDS.minStrokeWidth);
  }

  for (let i = 1; i < geo.rings.length; i++) {
    const gap = geo.rings[i].r - geo.rings[i - 1].r;
    expect(
      gap,
      `[${label}] Center-to-center gap between ring ${i - 1} ` +
        `(r=${geo.rings[i - 1].r.toFixed(2)}) and ring ${i} ` +
        `(r=${geo.rings[i].r.toFixed(2)}) is ${gap.toFixed(2)} px — ` +
        `below minimum ${THRESHOLDS.minRingCenterGap} px; rings may blur together`,
    ).toBeGreaterThan(THRESHOLDS.minRingCenterGap);
  }
}

test.describe("AnimatedRippleIcon – small-size geometry regression guard", () => {
  test("Board 2 – favicon preview SVGs at 32 px have distinguishable rings", async ({
    page,
  }) => {
    await page.goto("/__mockup/preview/ripple/Board2LogoConcepts");
    await page.waitForSelector("text=32px Favicon Preview", { timeout: 15_000 });

    // Scope the SVG lookup to the section that contains the
    // "32px Favicon Preview" label so we only test the correct icons and
    // remain robust if other 32-px SVGs appear elsewhere on the board.
    const sectionHandle = await page
      .locator(
        "xpath=//p[contains(text(),'32px Favicon Preview')]/ancestor::div[.//svg[@width='32']][1]",
      )
      .elementHandle({ timeout: 5_000 });

    expect(
      sectionHandle,
      "Could not locate the 32px favicon preview container on Board 2",
    ).not.toBeNull();

    const sectionId = await page.evaluate((el) => {
      const id = "e2e-favicon-section-" + Date.now();
      (el as HTMLElement).setAttribute("data-e2e", id);
      return id;
    }, sectionHandle!);

    const geo = await readIconGeometryInContainer(
      page,
      `[data-e2e="${sectionId}"]`,
      "32",
    );
    assertIconGeometry(geo, 32, "Board2 size=32");

    // Conditional: if a 16-px icon is present in the favicon section, assert
    // its geometry too. The current design does not include one, but this
    // check protects against regressions if a 16 px preview is added later.
    const has16pxIcon = await page.evaluate(
      ([cSel]: [string]) => {
        const container = document.querySelector(cSel);
        return container
          ? container.querySelector('svg[width="16"]') !== null
          : false;
      },
      [`[data-e2e="${sectionId}"]`] as [string],
    );

    if (has16pxIcon) {
      const geo16 = await readIconGeometryInContainer(
        page,
        `[data-e2e="${sectionId}"]`,
        "16",
      );
      assertIconGeometry(geo16, 16, "Board2 size=16");
    }
  });

  test("Board 4 – guidelines app icon at 24 px has distinguishable rings", async ({
    page,
  }) => {
    await page.goto("/__mockup/preview/ripple/Board4Guidelines");
    await page.waitForSelector("text=24 px", { timeout: 15_000 });

    // Scope to the animation-spec / icon-size row that contains the 24 px label.
    const sectionHandle = await page
      .locator(
        "xpath=//p[normalize-space(text())='24 px']/ancestor::div[.//svg[@width='24']][1]",
      )
      .elementHandle({ timeout: 5_000 });

    expect(
      sectionHandle,
      "Could not locate the 24-px icon section on Board 4",
    ).not.toBeNull();

    const sectionId = await page.evaluate((el) => {
      const id = "e2e-icon-section-" + Date.now();
      (el as HTMLElement).setAttribute("data-e2e", id);
      return id;
    }, sectionHandle!);

    const geo = await readIconGeometryInContainer(
      page,
      `[data-e2e="${sectionId}"]`,
      "24",
    );
    assertIconGeometry(geo, 24, "Board4 size=24");
  });
});

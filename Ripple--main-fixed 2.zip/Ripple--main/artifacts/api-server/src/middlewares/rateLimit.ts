import rateLimit from "express-rate-limit";

/**
 * Baseline limiter applied to all /api traffic. Values are deliberately
 * generous so real users are never affected; this exists only to blunt
 * naive flooding, since there was previously no application-level
 * throttling at all (see threat_model.md, Denial of Service).
 */
export const apiRateLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  limit: 300,
  standardHeaders: true,
  legacyHeaders: false,
  // Load balancer / uptime-monitor health checks can be frequent and don't
  // touch the DB — don't count them against the budget.
  skip: (req) => req.path === "/healthz",
});

/**
 * Tighter limiter for endpoints that are reachable without authentication
 * and run a user-controlled ILIKE search or aggregate query against the DB —
 * cheap for a caller to send, comparatively expensive to serve repeatedly.
 */
export const publicReadRateLimiter = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  limit: 60,
  standardHeaders: true,
  legacyHeaders: false,
});

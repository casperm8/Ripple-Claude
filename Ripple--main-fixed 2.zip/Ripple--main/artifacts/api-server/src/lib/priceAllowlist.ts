/**
 * Returns the set of Stripe price IDs that are approved for Pro access.
 *
 * Set STRIPE_PRO_PRICE_IDS to a comma-separated list of price IDs in the
 * environment (e.g. "price_abc123,price_def456").  At least one entry is
 * required; the server will throw at startup if the variable is missing or
 * empty so the misconfiguration is caught early rather than silently granting
 * or denying access.
 */
export function getApprovedPriceIds(): Set<string> {
  const raw = process.env.STRIPE_PRO_PRICE_IDS ?? "";
  const ids = raw
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);

  if (ids.length === 0) {
    throw new Error(
      "STRIPE_PRO_PRICE_IDS environment variable is not set or is empty. " +
        "Add the comma-separated Stripe price ID(s) for your Pro plan."
    );
  }

  return new Set(ids);
}

/**
 * Returns true when the given price ID is in the approved allowlist.
 */
export function isApprovedPriceId(priceId: string): boolean {
  return getApprovedPriceIds().has(priceId);
}

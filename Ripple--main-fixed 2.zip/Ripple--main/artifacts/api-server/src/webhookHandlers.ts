import { getStripeSync } from "./stripeClient";
import { storage } from "./storage";
import { logger } from "./lib/logger";
import { isApprovedPriceId } from "./lib/priceAllowlist";

export class WebhookHandlers {
  static async processWebhook(payload: Buffer, signature: string): Promise<void> {
    if (!Buffer.isBuffer(payload)) {
      throw new Error(
        "STRIPE WEBHOOK ERROR: Payload must be a Buffer. " +
          "This usually means express.json() parsed the body before reaching this handler."
      );
    }

    const sync = await getStripeSync();
    await sync.processWebhook(payload, signature);

    const event = JSON.parse(payload.toString());

    switch (event.type) {
      case "customer.subscription.created":
      case "customer.subscription.updated": {
        const sub = event.data.object;
        const isActive = sub.status === "active" || sub.status === "trialing";
        const hasApprovedPrice =
          isActive &&
          Array.isArray(sub.items?.data) &&
          sub.items.data.some((item: any) => isApprovedPriceId(item.price?.id));
        await storage.updateUserTierByCustomerId(
          sub.customer,
          hasApprovedPrice ? "pro" : "free",
          hasApprovedPrice ? sub.id : undefined
        );
        logger.info(
          { customerId: sub.customer, status: sub.status, hasApprovedPrice },
          "Subscription updated"
        );
        break;
      }
      case "customer.subscription.deleted": {
        const sub = event.data.object;
        await storage.updateUserTierByCustomerId(sub.customer, "free");
        logger.info({ customerId: sub.customer }, "Subscription deleted — reverted to free");
        break;
      }
      default:
        break;
    }
  }
}

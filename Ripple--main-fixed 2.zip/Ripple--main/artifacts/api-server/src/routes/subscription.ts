import { Router } from "express";
import { requireUser } from "./users";
import { storage } from "../storage";
import { stripeService } from "../stripeService";
import { getApprovedPriceIds, isApprovedPriceId } from "../lib/priceAllowlist";

const router = Router();

router.get("/plans", async (_req, res) => {
  const approvedIds = getApprovedPriceIds();
  const rows = await storage.listProductsWithPrices();
  const plans: any[] = [];
  for (const row of rows as any[]) {
    if (row.price_id && approvedIds.has(row.price_id as string)) {
      plans.push({
        id: row.product_id,
        name: row.product_name,
        description: row.product_description ?? "",
        priceId: row.price_id,
        amount: row.unit_amount,
        currency: row.currency,
        interval: (row.recurring as any)?.interval ?? "month",
        features: [
          "Unlimited daily claims",
          "Unlimited weekly posts",
          "Zero ads",
          "Priority support",
        ],
      });
    }
  }
  res.json(plans);
});

router.get("/status", async (req, res) => {
  const user = await requireUser(req, res);
  if (!user) return;

  const subscription = user.stripeSubscriptionId
    ? await storage.getSubscription(user.stripeSubscriptionId)
    : null;

  res.json({
    tier: user.tier,
    subscription: subscription
      ? {
          id: subscription.id,
          status: subscription.status,
          currentPeriodEnd: subscription.current_period_end,
        }
      : null,
  });
});

router.post("/checkout", async (req, res) => {
  const user = await requireUser(req, res);
  if (!user) return;

  const { priceId, successUrl, cancelUrl } = req.body as {
    priceId?: string;
    successUrl?: string;
    cancelUrl?: string;
  };
  if (!priceId) {
    res.status(400).json({ error: "priceId is required" });
    return;
  }
  if (!isApprovedPriceId(priceId)) {
    res.status(400).json({ error: "Invalid priceId" });
    return;
  }

  let customerId = user.stripeCustomerId;
  if (!customerId) {
    const customer = await stripeService.createCustomer(user.email, user.id);
    await storage.updateUserStripeInfo(user.id, { stripeCustomerId: customer.id });
    customerId = customer.id;
  }

  const host = `${req.protocol}://${req.get("host")}`;
  const session = await stripeService.createCheckoutSession(
    customerId,
    priceId,
    successUrl || `${host}/checkout/success`,
    cancelUrl || `${host}/upgrade`
  );

  res.json({ url: session.url });
});

router.post("/portal", async (req, res) => {
  const user = await requireUser(req, res);
  if (!user) return;

  if (!user.stripeCustomerId) {
    res.status(400).json({ error: "No billing account found. Subscribe first." });
    return;
  }

  const { returnUrl } = req.body as { returnUrl?: string };
  const host = `${req.protocol}://${req.get("host")}`;
  const session = await stripeService.createCustomerPortalSession(
    user.stripeCustomerId,
    returnUrl ?? `${host}/upgrade`
  );

  res.json({ url: session.url });
});

export default router;

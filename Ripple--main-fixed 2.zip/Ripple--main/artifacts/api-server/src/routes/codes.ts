import { Router } from "express";
import { getAuth } from "@clerk/express";
import { db, usersTable, codesTable, claimsTable } from "@workspace/db";
import { eq, and, gte, ilike, sql, or, inArray } from "drizzle-orm";
import { requireUser } from "./users";
import { CreateCodeBody } from "@workspace/api-zod";
import { publicReadRateLimiter } from "../middlewares/rateLimit";

const router = Router();

router.get("/", publicReadRateLimiter, async (req, res) => {
  const { userId } = getAuth(req);
  const page = Math.max(1, parseInt(req.query.page as string) || 1);
  const limit = Math.min(50, parseInt(req.query.limit as string) || 20);
  const offset = (page - 1) * limit;
  const category = req.query.category as string | undefined;
  const search = req.query.search as string | undefined;

  const now = new Date();

  let query = db.select().from(codesTable).$dynamic();
  let countQuery = db.select({ count: sql<number>`count(*)::int` }).from(codesTable).$dynamic();

  const conditions = [];
  if (category) conditions.push(eq(codesTable.category, category.toLowerCase()));
  if (search) conditions.push(or(
    ilike(codesTable.title, `%${search}%`),
    ilike(codesTable.description, `%${search}%`),
  ));

  if (conditions.length > 0) {
    const combined = conditions.length === 1 ? conditions[0] : and(...conditions);
    query = query.where(combined!);
    countQuery = countQuery.where(combined!);
  }

  const [totalResult] = await countQuery;
  const codes = await query
    .limit(limit)
    .offset(offset)
    .orderBy(sql`${codesTable.createdAt} desc`);

  let claimedSet = new Set<number>();
  if (userId) {
    const claimedIds = await db
      .select({ codeId: claimsTable.codeId })
      .from(claimsTable)
      .where(eq(claimsTable.userId, userId));
    claimedSet = new Set(claimedIds.map(c => c.codeId));
  }

  const userIds = [...new Set(codes.map(c => c.userId))];
  const users = userIds.length > 0
    ? await db.select().from(usersTable).where(inArray(usersTable.id, userIds))
    : [];
  const userMap = Object.fromEntries(users.map(u => [u.id, u]));

  res.json({
    codes: codes.map(c => ({
      id: c.id,
      userId: c.userId,
      title: c.title,
      description: c.description,
      category: c.category,
      maxClaims: c.maxClaims,
      claimCount: c.claimCount,
      isExpired: c.expiresAt ? c.expiresAt < now : false,
      expiresAt: c.expiresAt?.toISOString() ?? null,
      createdAt: c.createdAt.toISOString(),
      posterName: userMap[c.userId]?.email?.split("@")[0] ?? "user",
      isClaimedByMe: claimedSet.has(c.id),
      isMine: c.userId === userId,
    })),
    total: totalResult.count,
    page,
    totalPages: Math.ceil(totalResult.count / limit),
  });
});

router.post("/", async (req, res) => {
  const user = await requireUser(req, res);
  if (!user) return;

  const parsed = CreateCodeBody.safeParse(req.body);
  if (!parsed.success) {
    const fieldMessages: Record<string, string> = {
      title: "Title is required.",
      description: "Description is required.",
      code: "Code must be 50 characters or fewer.",
      category: "Please select a category.",
      maxClaims: "Max claims must be between 1 and 100.",
    };
    const firstError = parsed.error.errors[0];
    const field = firstError?.path[0] as string | undefined;
    const error = (field && fieldMessages[field]) ?? "Validation failed.";
    res.status(400).json({ error, field });
    return;
  }

  const isPro = user.tier === "pro";

  const { title, description, code, category, maxClaims, expiresAt } = parsed.data;

  let newCode: Awaited<ReturnType<typeof db.transaction<any>>>;

  try {
    newCode = await db.transaction(async (tx) => {
      if (!isPro) {
        // Acquire a row-level lock on the user record to serialize concurrent
        // post attempts from the same free account. The weekly count is then
        // read inside the lock, so no two requests from this user can both
        // observe a sub-limit count and both proceed to insert.
        await tx.select().from(usersTable)
          .where(eq(usersTable.id, user.id))
          .for("update")
          .limit(1);

        const weekStart = new Date();
        weekStart.setDate(weekStart.getDate() - weekStart.getDay());
        weekStart.setHours(0, 0, 0, 0);

        const [weeklyPostsResult] = await tx
          .select({ count: sql<number>`count(*)::int` })
          .from(codesTable)
          .where(and(eq(codesTable.userId, user.id), gte(codesTable.createdAt, weekStart)));

        if (weeklyPostsResult.count >= 2) {
          const err: any = new Error("Weekly post limit reached. Upgrade to Pro for unlimited posts.");
          err.status = 400;
          throw err;
        }
      }

      const [inserted] = await tx.insert(codesTable).values({
        userId: user.id,
        title,
        description,
        code,
        category: category.toLowerCase(),
        maxClaims,
        expiresAt: expiresAt ? new Date(expiresAt) : undefined,
      }).returning();

      return inserted;
    });
  } catch (err: any) {
    const status = err.status ?? 500;
    res.status(status).json({ error: err.message ?? "Internal server error" });
    return;
  }

  const now = new Date();
  res.status(201).json({
    id: newCode.id,
    userId: newCode.userId,
    title: newCode.title,
    description: newCode.description,
    category: newCode.category,
    maxClaims: newCode.maxClaims,
    claimCount: newCode.claimCount,
    isExpired: newCode.expiresAt ? newCode.expiresAt < now : false,
    expiresAt: newCode.expiresAt?.toISOString() ?? null,
    createdAt: newCode.createdAt.toISOString(),
    posterName: user.email.split("@")[0],
    isClaimedByMe: false,
    isMine: true,
  });
});

router.get("/:id", async (req, res) => {
  const { userId } = getAuth(req);
  const id = parseInt(req.params.id);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }

  const [code] = await db.select().from(codesTable).where(eq(codesTable.id, id)).limit(1);
  if (!code) { res.status(404).json({ error: "Not found" }); return; }

  const [poster] = await db.select().from(usersTable).where(eq(usersTable.id, code.userId)).limit(1);
  const now = new Date();

  let isClaimedByMe = false;
  if (userId) {
    const [claim] = await db.select().from(claimsTable)
      .where(and(eq(claimsTable.codeId, id), eq(claimsTable.userId, userId))).limit(1);
    isClaimedByMe = !!claim;
  }

  res.json({
    id: code.id,
    userId: code.userId,
    title: code.title,
    description: code.description,
    category: code.category,
    maxClaims: code.maxClaims,
    claimCount: code.claimCount,
    isExpired: code.expiresAt ? code.expiresAt < now : false,
    expiresAt: code.expiresAt?.toISOString() ?? null,
    createdAt: code.createdAt.toISOString(),
    posterName: poster?.email?.split("@")[0] ?? "user",
    isClaimedByMe,
    isMine: code.userId === userId,
  });
});

router.delete("/:id", async (req, res) => {
  const user = await requireUser(req, res);
  if (!user) return;

  const id = parseInt(req.params.id);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }

  const [code] = await db.select().from(codesTable).where(eq(codesTable.id, id)).limit(1);
  if (!code) { res.status(404).json({ error: "Not found" }); return; }
  if (code.userId !== user.id) { res.status(403).json({ error: "Forbidden" }); return; }

  await db.delete(claimsTable).where(eq(claimsTable.codeId, id));
  await db.delete(codesTable).where(eq(codesTable.id, id));
  res.status(204).send();
});

export default router;

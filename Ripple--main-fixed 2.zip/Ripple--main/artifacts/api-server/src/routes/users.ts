import { Router } from "express";
import { getAuth } from "@clerk/express";
import { db, usersTable, codesTable, claimsTable } from "@workspace/db";
import { eq, and, gte, sql } from "drizzle-orm";

const router = Router();

async function getOrCreateUser(clerkId: string, email: string) {
  const existing = await db.select().from(usersTable).where(eq(usersTable.clerkId, clerkId)).limit(1);
  if (existing.length > 0) return existing[0];

  const [user] = await db.insert(usersTable).values({
    id: clerkId,
    clerkId,
    email,
    tier: "free",
  }).returning();
  return user;
}

export async function requireUser(req: any, res: any) {
  const { userId } = getAuth(req);
  if (!userId) {
    res.status(401).json({ error: "Unauthorized" });
    return null;
  }
  const email = req.auth?.sessionClaims?.email as string ?? "";
  const user = await getOrCreateUser(userId, email);
  return user;
}

router.get("/me", async (req, res) => {
  const user = await requireUser(req, res);
  if (!user) return;

  const weekStart = new Date();
  weekStart.setDate(weekStart.getDate() - weekStart.getDay());
  weekStart.setHours(0, 0, 0, 0);

  const dayStart = new Date();
  dayStart.setHours(0, 0, 0, 0);

  const [weeklyPostsResult] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(codesTable)
    .where(and(eq(codesTable.userId, user.id), gte(codesTable.createdAt, weekStart)));

  const [dailyClaimsResult] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(claimsTable)
    .where(and(eq(claimsTable.userId, user.id), gte(claimsTable.claimedAt, dayStart)));

  const isPro = user.tier === "pro";

  res.json({
    id: user.id,
    clerkId: user.clerkId,
    email: user.email,
    tier: user.tier,
    stripeCustomerId: user.stripeCustomerId ?? null,
    stripeSubscriptionId: user.stripeSubscriptionId ?? null,
    codesPostedThisWeek: weeklyPostsResult.count,
    requestsToday: dailyClaimsResult.count,
    dailyRequestLimit: isPro ? null : 5,
    weeklyPostLimit: isPro ? null : 2,
    createdAt: user.createdAt.toISOString(),
  });
});

router.get("/me/codes", async (req, res) => {
  const user = await requireUser(req, res);
  if (!user) return;

  const page = Math.max(1, parseInt(req.query.page as string) || 1);
  const limit = Math.min(50, parseInt(req.query.limit as string) || 20);
  const offset = (page - 1) * limit;

  const [totalResult] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(codesTable)
    .where(eq(codesTable.userId, user.id));

  const codes = await db
    .select()
    .from(codesTable)
    .where(eq(codesTable.userId, user.id))
    .limit(limit)
    .offset(offset)
    .orderBy(sql`${codesTable.createdAt} desc`);

  const now = new Date();
  const claimedIds = await db
    .select({ codeId: claimsTable.codeId })
    .from(claimsTable)
    .where(eq(claimsTable.userId, user.id));
  const claimedSet = new Set(claimedIds.map(c => c.codeId));

  res.json({
    codes: codes.map(c => ({
      id: c.id,
      userId: c.userId,
      title: c.title,
      description: c.description,
      category: c.category,
      maxClaims: c.maxClaims,
      claimCount: c.claimCount,
      isExpired: c.expiresAt ? c.expiresAt < now : false,
      expiresAt: c.expiresAt?.toISOString() ?? null,
      createdAt: c.createdAt.toISOString(),
      posterName: user.email.split("@")[0],
      isClaimedByMe: claimedSet.has(c.id),
      isMine: true,
    })),
    total: totalResult.count,
    page,
    totalPages: Math.ceil(totalResult.count / limit),
  });
});

router.get("/me/claims", async (req, res) => {
  const user = await requireUser(req, res);
  if (!user) return;

  const page = Math.max(1, parseInt(req.query.page as string) || 1);
  const limit = Math.min(50, parseInt(req.query.limit as string) || 20);
  const offset = (page - 1) * limit;

  const [totalResult] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(claimsTable)
    .where(eq(claimsTable.userId, user.id));

  const claims = await db
    .select({
      id: claimsTable.id,
      codeId: claimsTable.codeId,
      claimedAt: claimsTable.claimedAt,
      codeTitle: codesTable.title,
      code: codesTable.code,
      category: codesTable.category,
    })
    .from(claimsTable)
    .innerJoin(codesTable, eq(claimsTable.codeId, codesTable.id))
    .where(eq(claimsTable.userId, user.id))
    .limit(limit)
    .offset(offset)
    .orderBy(sql`${claimsTable.claimedAt} desc`);

  res.json({
    claims: claims.map(c => ({
      id: c.id,
      codeId: c.codeId,
      codeTitle: c.codeTitle,
      code: c.code,
      category: c.category,
      claimedAt: c.claimedAt.toISOString(),
    })),
    total: totalResult.count,
    page,
    totalPages: Math.ceil(totalResult.count / limit),
  });
});

export default router;

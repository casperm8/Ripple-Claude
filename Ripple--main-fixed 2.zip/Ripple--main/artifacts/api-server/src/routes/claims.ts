import { Router } from "express";
import { db, codesTable, claimsTable, usersTable } from "@workspace/db";
import { eq, and, gte, sql } from "drizzle-orm";
import { requireUser } from "./users";

const router = Router();

router.post("/:id/claim", async (req, res) => {
  const user = await requireUser(req, res);
  if (!user) return;

  const id = parseInt(req.params.id);
  if (isNaN(id)) { res.status(400).json({ error: "Invalid id" }); return; }

  const [code] = await db.select().from(codesTable).where(eq(codesTable.id, id)).limit(1);
  if (!code) { res.status(404).json({ error: "Not found" }); return; }

  const now = new Date();
  if (code.expiresAt && code.expiresAt < now) {
    res.status(410).json({ error: "This code has expired" });
    return;
  }

  try {
    const result = await db.transaction(async (tx) => {
      // Acquire a row-level lock on the user record. This serializes all
      // concurrent claim requests from the same user so that both the daily
      // quota check and the claimCount increment are seen atomically — no two
      // requests from this user can race through the critical section at once.
      await tx.select().from(usersTable)
        .where(eq(usersTable.id, user.id))
        .for("update")
        .limit(1);

      // Idempotent: return existing claim without consuming quota
      const [existingClaim] = await tx.select().from(claimsTable)
        .where(and(eq(claimsTable.codeId, id), eq(claimsTable.userId, user.id))).limit(1);

      if (existingClaim) {
        return {
          codeId: code.id,
          code: code.code,
          title: code.title,
          claimedAt: existingClaim.claimedAt.toISOString(),
        };
      }

      // Check daily quota for free users (read inside the lock — accurate)
      const isPro = user.tier === "pro";
      if (!isPro) {
        const dayStart = new Date();
        dayStart.setHours(0, 0, 0, 0);

        const [dailyResult] = await tx
          .select({ count: sql<number>`count(*)::int` })
          .from(claimsTable)
          .where(and(eq(claimsTable.userId, user.id), gte(claimsTable.claimedAt, dayStart)));

        if (dailyResult.count >= 5) {
          const err: any = new Error("Daily request limit reached. Upgrade to Pro for unlimited claims.");
          err.status = 400;
          throw err;
        }
      }

      // Atomic claim: increment claimCount only while still under maxClaims.
      // Because this runs inside the transaction, a rollback (e.g. from the
      // INSERT conflict below) will undo this increment — no slot leaks.
      const [updatedCode] = await tx.update(codesTable)
        .set({ claimCount: sql`${codesTable.claimCount} + 1` })
        .where(and(
          eq(codesTable.id, id),
          sql`${codesTable.claimCount} < ${codesTable.maxClaims}`,
        ))
        .returning();

      if (!updatedCode) {
        const err: any = new Error("This code has no remaining slots");
        err.status = 410;
        throw err;
      }

      const [claim] = await tx.insert(claimsTable).values({
        codeId: id,
        userId: user.id,
      }).returning();

      return {
        codeId: code.id,
        code: code.code,
        title: code.title,
        claimedAt: claim.claimedAt.toISOString(),
      };
    });

    res.json(result);
  } catch (err: any) {
    const status = err.status ?? 500;
    res.status(status).json({ error: err.message ?? "Internal server error" });
  }
});

export default router;

import { Router, type IRouter } from "express";
import healthRouter from "./health";
import usersRouter from "./users";
import codesRouter from "./codes";
import claimsRouter from "./claims";
import statsRouter from "./stats";
import subscriptionRouter from "./subscription";

const router: IRouter = Router();

router.use(healthRouter);
router.use("/users", usersRouter);
router.use("/codes", codesRouter);
router.use("/codes", claimsRouter);
router.use("/stats", statsRouter);
router.use("/subscription", subscriptionRouter);

export default router;

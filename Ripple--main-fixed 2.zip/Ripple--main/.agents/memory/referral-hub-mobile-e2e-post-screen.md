---
name: Referral Hub Mobile — Post screen E2E testing patterns
description: Hard-won lessons for Playwright E2E tests against the Expo mobile app (RN web mode) including auth bypass and tab-bar click interception workarounds.
---

## Clerk auth bypass for E2E tests

`@clerk/expo` v3 in web mode does NOT respond to `__clerk_testing_token` via cookie injection or URL query param. Neither approach works. Instead:
- Added `EXPO_PUBLIC_E2E_TEST=1` env var check in `post.tsx` that skips the Clerk auth gate (development only)
- Set `EXPO_PUBLIC_E2E_TEST=1` in the Replit **development** environment via `setEnvVars`
- Restarted the `artifacts/referral-hub-mobile: expo` workflow to rebundle Metro with the new env var

**Why:** `EXPO_PUBLIC_*` vars are baked into the Metro bundle at startup, not injected at runtime.

## Tab bar pointer-event interception

The Expo bottom tab bar is a fixed overlay that intercepts pointer events at the bottom of the viewport. The "Post Code" submit button sits at the end of a ScrollView — its on-screen position is under the tab bar.

- Standard `page.click()` fails: "element intercepts pointer events"
- `{ force: true }` dispatches the click at the element's screen coordinates, which lands on the tab bar — the React `onPress` does NOT fire
- **Working solution:** find the text node, walk up the DOM to the nearest `role="button"` ancestor, and call `.click()` on it via `page.evaluate`

```ts
await page.getByText("Post Code").first().evaluate((el) => {
  let node: Element | null = el;
  while (node && node !== document.body) {
    if (node.getAttribute("role") === "button") { (node as HTMLElement).click(); return; }
    node = node.parentElement;
  }
  (el as HTMLElement).click();
});
```

## Stepper button accessibility

The stepper buttons in `post.tsx` use Feather SVG icons — no text content for Playwright to target. Added `accessibilityLabel="Decrease max claims"` / `"Increase max claims"` props to the Pressable elements. On RN web, `accessibilityLabel` maps to `aria-label`, enabling `page.getByRole("button", { name: "Decrease max claims" })`.

## `toBeVisible()` in RN web ScrollView

Elements scrolled out of view inside a RN web ScrollView ARE considered visible by Playwright (they're in the DOM, not CSS-hidden). The validation error messages can be asserted with `toBeVisible()` without scrolling back to the top after submitting.

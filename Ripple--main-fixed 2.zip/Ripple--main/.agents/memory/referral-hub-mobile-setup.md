---
name: Referral Hub Mobile Setup
description: Key decisions and quirks for the Clerk-authenticated Expo mobile app in this project
---

## Clerk Expo Dependencies
`@clerk/clerk-expo` requires two peer deps that must be installed separately:
- `expo-auth-session` — pin to `~7.0.11` (the version compatible with Expo SDK 54)
- `expo-secure-store` — pin to `~15.0.8`

Installing the wrong version of `expo-auth-session` (e.g. v56) causes Metro to fail resolving `@clerk/clerk-expo`.

**Why:** pnpm's hoisting changes when you change versions; always run workspace-root `pnpm install` after changing mobile deps.

## EXPO_PUBLIC_CLERK_PUBLISHABLE_KEY
The dev script references `$CLERK_PUBLISHABLE_KEY` (NOT `$VITE_CLERK_PUBLISHABLE_KEY`) since both are set in the Replit environment and both have the same value. The env var is passed as `EXPO_PUBLIC_CLERK_PUBLISHABLE_KEY=$CLERK_PUBLISHABLE_KEY` in the dev script.

## Workflow Name
The Expo mobile workflow is `artifacts/referral-hub-mobile: expo` (not `web`).

## Architecture
- ClerkProvider wraps everything in `_layout.tsx`
- `AuthTokenSetter` component (inside ClerkProvider) calls `setAuthTokenGetter` via useEffect when auth state changes
- `setBaseUrl` is called at module-top-level (outside components) in `_layout.tsx`
- Protected screens (Post, Activity, Profile) show inline "Sign In" prompts instead of redirects — better UX
- tokenCache uses expo-secure-store on native, undefined (memory) on web

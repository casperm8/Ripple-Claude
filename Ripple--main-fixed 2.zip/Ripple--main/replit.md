# Ripple

A referral/promo-code sharing platform: users post codes with a claim limit, other users browse and claim them, and a free/Pro tier (via Stripe) lifts per-user posting and claiming quotas.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/Ripple` — public web app (React + Vite + shadcn/ui): browse, post, my-codes, my-claims, upgrade, settings
- `artifacts/Ripple-Mobile` — Expo/React Native app, same product surface, Clerk auth
- `artifacts/api-server` — Express 5 API: routes for codes, claims, users, subscription, stats; Stripe webhook handling
- `artifacts/Ripple-pitch-deck`, `artifacts/mockup-sandbox` — dev/presentation artifacts, not production-reachable (see `threat_model.md`)
- `lib/db` — source of truth for the DB schema (Drizzle, Postgres): `users`, `codes`, `claims` tables
- `lib/api-spec/openapi.yaml` — source of truth for the API contract; run the api-spec `codegen` script to regenerate `lib/api-zod` and `lib/api-client-react` after changing it
- `threat_model.md` — security scan anchors and trust boundaries; update it when routes or entry points move

## Architecture decisions

- Claim/post quotas are enforced with a `SELECT ... FOR UPDATE` lock on the user row inside a transaction, so concurrent requests from the same user can't both pass a stale quota check — see `routes/claims.ts` and `routes/codes.ts`.
- Claim-slot consumption is a single conditional `UPDATE ... WHERE claimCount < maxClaims` inside that same transaction, so slots can never be oversold under concurrency.
- Pro access is only ever granted for Stripe price IDs in `STRIPE_PRO_PRICE_IDS` (checked in both `/subscription/checkout` and the webhook handler) — an attacker can't buy an arbitrary price and self-upgrade.
- React Query caches are cleared on every sign-in/sign-out/account-switch on both web (`ClerkQueryClientCacheInvalidator`) and mobile (`AuthTokenSetter`), so one user's cached `/api/users/me*` data is never shown to the next user on a shared device.
- The Clerk Frontend API proxy (`clerkProxyMiddleware.ts`) only runs in production; dev instances talk to Clerk directly.

## Product

- Browse and search posted codes by category/keyword; see remaining claim slots and expiry
- Post a code (title, description, category, max claims, optional expiry) — free tier: 2 posts/week, Pro: unlimited
- Claim a code — free tier: 5 claims/day, Pro: unlimited; claiming is idempotent (re-claiming your own already-claimed code just returns it, without burning quota)
- "My Codes" / "My Claims" activity views
- Upgrade to Pro via Stripe Checkout; manage billing via the Stripe customer portal

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

- `@clerk/clerk-expo` needs `expo-auth-session` pinned to `~7.0.11` and `expo-secure-store` pinned to `~15.0.8` for Expo SDK 54 — a wrong `expo-auth-session` version breaks Metro's resolution of `@clerk/clerk-expo`. Always run a workspace-root `pnpm install` after changing mobile deps (pnpm re-hoists).
- Mobile dev script passes `$CLERK_PUBLISHABLE_KEY` (not `$VITE_CLERK_PUBLISHABLE_KEY`) as `EXPO_PUBLIC_CLERK_PUBLISHABLE_KEY` — both vars hold the same value in the Replit env.
- `EXPO_PUBLIC_*` vars are baked into the Metro bundle at build time, not read at runtime — changing one requires restarting/rebundling the Expo workflow.
- The `EXPO_PUBLIC_E2E_TEST=1` Clerk-auth bypass used by Playwright must always be paired with an `__DEV__` guard (`__DEV__ && process.env.EXPO_PUBLIC_E2E_TEST === "1"`) wherever it's used, so it can never fire in a production build. Keep this consistent across screens — see `post.tsx` / `profile.tsx`.
- CORS origin checks in `api-server/src/app.ts` must be exact-match only. A prefix check (`origin.startsWith(...)`) would let a domain like `https://<yourdomain>.evil.com` pass, which matters here because `credentials: true` is set and the web app relies on the browser auto-attaching the Clerk session cookie.
- `stripe-replit-sync`'s `runMigrations`/webhook setup can fail independently of the main app; `index.ts` deliberately logs and continues rather than crashing the server on Stripe init failure — the app runs (without payments) if Stripe isn't configured yet.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details

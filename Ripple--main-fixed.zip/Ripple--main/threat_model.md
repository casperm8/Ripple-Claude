# Threat Model

## Project Overview

Ripple is a pnpm-workspace monorepo for a referral-code sharing product with three production surfaces: a public React web app (`artifacts/referral-hub`), a mobile Expo client (`artifacts/referral-hub-mobile`), and an Express API (`artifacts/api-server`) backed by PostgreSQL via Drizzle (`lib/db`). Authentication is handled by Clerk, and payments/subscription state are handled through Stripe plus `stripe-replit-sync`.

The current deployment is public. Production runs with `NODE_ENV=production`. The mockup sandbox and pitch deck are development/presentation artifacts and should be treated as out of scope unless production reachability is demonstrated.

## Assets

- **User accounts and sessions** — Clerk identities, session cookies, and bearer tokens used by the web and mobile clients. Compromise allows impersonation and access to private activity.
- **Referral data** — posted codes, claim history, per-user limits, and remaining claim slots. Tampering can deny access to offers or let users exceed entitlement limits.
- **Subscription state** — Stripe customer/subscription identifiers and the local `tier` field used to unlock Pro features. Incorrect updates can grant paid access or revoke it improperly.
- **User profile data** — email addresses and activity history stored in `users`, `codes`, and `claims`. Exposure leaks personal data and user behavior.
- **Application secrets** — database URL, Clerk secret key, and Stripe credentials fetched via Replit integrations. Exposure would allow broad compromise.

## Trust Boundaries

- **Browser / mobile client to API** — all request parameters, bodies, and headers are untrusted and must be validated server-side.
- **API to Clerk** — the API trusts Clerk middleware and Clerk proxy responses to establish identity. Auth decisions must not rely on client-only state.
- **API to PostgreSQL** — the API has direct write access to business data and Stripe-sync tables. Query construction and multi-step updates are high-risk.
- **API to Stripe / Replit integration services** — subscription state is derived from external systems and webhooks, so origin verification and product/tier mapping matter.
- **Public vs authenticated surfaces** — browse/stat/plan endpoints are public or lightly protected, while posting, claiming, settings, and billing endpoints must enforce per-user authorization.
- **Production vs dev-only artifacts** — `artifacts/mockup-sandbox`, `artifacts/ripple-pitch-deck`, most test assets, and workspace scripts are not production-reachable by default and should usually be ignored.

## Scan Anchors

- **Production entry points:** `artifacts/referral-hub/src/main.tsx`, `artifacts/referral-hub-mobile/app/_layout.tsx`, `artifacts/api-server/src/index.ts`, `artifacts/api-server/src/app.ts`.
- **Highest-risk server areas:** `artifacts/api-server/src/routes/*.ts`, `artifacts/api-server/src/middlewares/clerkProxyMiddleware.ts`, `artifacts/api-server/src/{stripeClient,stripeService,storage,webhookHandlers}.ts`, and `lib/db/src/schema/*`.
- **Highest-risk client state area:** `artifacts/referral-hub-mobile/app/_layout.tsx` plus any screen that renders `/api/users/me*` data from shared React Query caches.
- **Public surfaces:** web `/`, `/sign-in`, `/sign-up`; API `/api/healthz`, `/api/codes`, `/api/codes/:id`, `/api/stats`, `/api/subscription/plans`, Clerk proxy path, and Stripe webhook path.
- **Authenticated surfaces:** `/api/users/*`, code creation/deletion, code claims, checkout/portal, and corresponding web/mobile screens.
- **Usually out of scope:** `artifacts/mockup-sandbox`, `artifacts/ripple-pitch-deck`, root `screenshots/`, and dev/test scripts unless production exposure is shown.

## Threat Categories

### Spoofing

This project relies on Clerk for identity across both cookie-based web flows and bearer-token mobile flows. Protected API routes must require a valid Clerk-authenticated request on every call, and any middleware that forwards auth-related requests to Clerk must not let attackers forge trusted host or proxy context.

### Tampering

Referral codes, claim counts, quotas, and subscription tiers are all server-owned state. The API must calculate and enforce limits server-side, and any multi-step state transitions involving claims or billing must be atomic so attackers cannot corrupt counts or consume resources through races.

### Information Disclosure

User emails, claim history, Stripe-linked account state, and referral code contents are sensitive. API responses must only return the minimum needed for the calling user, and logs/error paths must not expose secrets, raw webhook payloads, or internal stack details to clients. Client-side caches that store `/api/users/me*` responses must also be cleared or partitioned on authentication changes so one user’s private data is not shown to another user on the same device.

### Denial of Service

Public and authenticated endpoints can be abused to consume database or third-party resources. Claiming, posting, webhook handling, and any external-service fetches must resist unbounded repeated requests and avoid state corruption that lets one user exhaust another user’s limited resources.

### Elevation of Privilege

The main privilege boundary is free vs Pro users and one user vs another user’s referral data. Server-side authorization must prevent cross-user access or modification, and billing/webhook logic must only grant Pro access for the intended paid subscription states rather than any attacker-influenced input.
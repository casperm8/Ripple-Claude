import { Router } from "express";
import { db, codesTable, claimsTable } from "@workspace/db";
import { sql, desc } from "drizzle-orm";

const router = Router();

router.get("/", async (req, res) => {
  const [totalCodesResult] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(codesTable);

  const [totalClaimsResult] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(claimsTable);

  const topCategories = await db
    .select({
      category: codesTable.category,
      count: sql<number>`count(*)::int`,
    })
    .from(codesTable)
    .groupBy(codesTable.category)
    .orderBy(desc(sql`count(*)`))
    .limit(8);

  const recentCodes = await db
    .select()
    .from(codesTable)
    .orderBy(desc(codesTable.createdAt))
    .limit(6);

  const now = new Date();

  res.json({
    totalCodes: totalCodesResult.count,
    totalClaims: totalClaimsResult.count,
    topCategories: topCategories.map(c => ({
      category: c.category,
      count: c.count,
    })),
    recentCodes: recentCodes.map(c => ({
      id: c.id,
      userId: c.userId,
      title: c.title,
      description: c.description,
      category: c.category,
      maxClaims: c.maxClaims,
      claimCount: c.claimCount,
      isExpired: c.expiresAt ? c.expiresAt < now : false,
      expiresAt: c.expiresAt?.toISOString() ?? null,
      createdAt: c.createdAt.toISOString(),
      posterName: "user",
      isClaimedByMe: false,
      isMine: false,
    })),
  });
});

export default router;
